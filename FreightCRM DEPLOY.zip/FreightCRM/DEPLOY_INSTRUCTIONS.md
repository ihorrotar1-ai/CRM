# 🚛 FreightCRM — Инструкция по деплою на Vercel

## ШАГ 1 — Загрузите проект на GitHub

1. Зайдите на **github.com** и войдите (или создайте аккаунт)
2. Нажмите **"+" → "New repository"**
3. Название: `freight-crm`
4. Нажмите **"Create repository"**
5. Нажмите **"uploading an existing file"**
6. Перетащите ВСЕ файлы из этой папки в браузер
7. Нажмите **"Commit changes"**

---

## ШАГ 2 — Деплой на Vercel

1. Зайдите на **vercel.com** (вы уже зарегистрированы!)
2. Нажмите **"Add New Project"**
3. Нажмите **"Import Git Repository"**
4. Выберите **freight-crm** из списка
5. Framework: **Create React App** (выберется автоматически)
6. Нажмите **"Deploy"**

---

## ШАГ 3 — Готово! 🎉

Через 2-3 минуты получите ссылку вида:
**https://freight-crm-xxx.vercel.app**

---

## Структура файлов

```
FreightCRM/
├── src/
│   ├── App.js          ← Весь код CRM (2790 строк)
│   └── index.js        ← Точка входа
├── public/
│   ├── index.html      ← HTML шаблон
│   └── website.html    ← Сайт компании
├── supabase/
│   └── schema.sql      ← База данных
├── package.json        ← Зависимости
├── vercel.json         ← Настройки Vercel
└── .gitignore
```

---

## Что включено в CRM

| Раздел | Описание |
|--------|----------|
| 📊 Dashboard | Обзор метрик |
| 🚛 FTL Load Board | Полные грузовики |
| 📦 LTL Board | Частичные грузы + фото |
| 🗺️ Route Maps | Маршруты → Google Maps |
| 💳 Carrier Payments | Перевозчики + факторинг |
| 📈 Sales Funnel | Воронка + скрипты |
| 📞 Call Center | Звонки + переписка |
| 💰 Accounting | AR/AP + инвойсы |
| 👥 Team | Сотрудники |
| 🛡️ Verify | Проверка контрагентов |
| 🔔 Notifications | Email уведомления |
| 📊 Reports | Экспорт CSV/PDF |
| 🗓️ Calendar | Календарь |
| 📍 Tracking | Трекинг грузов |
| 💵 Margin Calc | Калькулятор маржи |
| 🤖 AI Agents | AI агенты продаж |
