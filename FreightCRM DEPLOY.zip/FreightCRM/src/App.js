import { useState, useEffect, useRef } from "react";

/* ─── THEME ──────────────────────────────────────────────── */
const C = {
  bg:"#07090f", surface:"#0c1018", card:"#111928",
  border:"rgba(255,255,255,0.07)", accent:"#00c2ff",
  accentDim:"rgba(0,194,255,0.1)", gold:"#f0b429",
  green:"#00e676", red:"#ff3f5b", orange:"#ff8a00",
  purple:"#a78bfa", teal:"#2dd4bf", pink:"#f472b6",
  text:"#dde6f5", muted:"#5a6a80", dim:"#1e2a3a",
};

/* ─── MOCK DATA ──────────────────────────────────────────── */
const EMPLOYEES = [
  {id:1,name:"Alex Johnson",role:"Senior Broker",dept:"Operations",email:"alex@freightcrm.com",phone:"+1(512)555-0101",status:"Active",avatar:"AJ",loads:42,revenue:"$84,200",hired:"2023-01-15",salary:"$75,000"},
  {id:2,name:"Sarah Kim",role:"Sales Rep",dept:"Sales",email:"sarah@freightcrm.com",phone:"+1(512)555-0102",status:"Active",avatar:"SK",loads:28,revenue:"$51,400",hired:"2023-06-01",salary:"$60,000"},
  {id:3,name:"Mike Patel",role:"Dispatcher",dept:"Operations",email:"mike@freightcrm.com",phone:"+1(512)555-0103",status:"Active",avatar:"MP",loads:67,revenue:"$102,300",hired:"2022-09-10",salary:"$58,000"},
  {id:4,name:"Tom Rivera",role:"Carrier Relations",dept:"Procurement",email:"tom@freightcrm.com",phone:"+1(512)555-0104",status:"Active",avatar:"TR",loads:15,revenue:"$28,800",hired:"2024-02-20",salary:"$55,000"},
];

const CARRIERS = [
  {id:1,name:"FastLane Trucking LLC",mc:"MC-847291",dot:"DOT-3847201",contact:"Jake Morrison",phone:"+1(512)555-0182",email:"j.morrison@fastlane.com",lanes:"TX→CA, TX→FL",equipment:"Dry Van, Reefer",status:"Active",rating:4.8,loads:42,city:"Austin TX",payMethod:"QuickPay",factoringCo:"OTR Solutions",factoringFee:"3%",w9:true,insurance:"$1M",bankName:"Chase Bank",routing:"021000021",account:"****4821"},
  {id:2,name:"Steel Road Carriers",mc:"MC-192837",dot:"DOT-2918374",contact:"Maria Gonzalez",phone:"+1(214)555-0143",email:"m.gonzalez@steelroad.com",lanes:"TX→Midwest",equipment:"Flatbed",status:"Active",rating:4.5,loads:28,city:"Dallas TX",payMethod:"Standard 30",factoringCo:"Triumph Business Capital",factoringFee:"2.5%",w9:true,insurance:"$1M",bankName:"Bank of America",routing:"026009593",account:"****7742"},
  {id:3,name:"Apex Haulers",mc:"MC-628193",dot:"DOT-6281934",contact:"Tom Bradley",phone:"+1(602)555-0154",email:"t.bradley@apexhaulers.com",lanes:"Southwest",equipment:"Dry Van",status:"Preferred",rating:5.0,loads:89,city:"Phoenix AZ",payMethod:"Factoring",factoringCo:"RTS Financial",factoringFee:"4%",w9:true,insurance:"$1M",bankName:"Wells Fargo",routing:"121000248",account:"****3309"},
];

const LOADS_FTL = [
  {id:"LB-10041",type:"FTL",origin:"Chicago IL",dest:"Dallas TX",pickup:"Apr 25",delivery:"Apr 27",commodity:"Auto Parts",weight:"38,000",rate:2450,carrier:"FastLane Trucking LLC",shipper:"Midwest Auto Parts",status:"In Transit",equipment:"Dry Van",miles:921,margin:380,broker:"Alex Johnson"},
  {id:"LB-10042",type:"FTL",origin:"Fresno CA",dest:"Phoenix AZ",pickup:"Apr 26",delivery:"Apr 27",commodity:"Produce",weight:"42,000",rate:1800,carrier:"Apex Haulers",shipper:"FreshFarm Co-op",status:"Booked",equipment:"Reefer",miles:569,margin:290,broker:"Sarah Kim"},
  {id:"LB-10043",type:"FTL",origin:"Atlanta GA",dest:"Miami FL",pickup:"Apr 28",delivery:"Apr 29",commodity:"Electronics",weight:"22,000",rate:1950,carrier:"",shipper:"GlobalTech Imports",status:"Available",equipment:"Dry Van",miles:662,margin:310,broker:"Mike Patel"},
];

const LOADS_LTL = [
  {id:"LTL-2001",type:"LTL",origin:"Houston TX",dest:"Orlando FL",pickup:"Apr 26",delivery:"Apr 30",commodity:"HVAC Equipment",weight:"2,400",dims:"48x40x60 in",pallets:4,freight_class:"85",rate:890,status:"Booked",shipper:"NovaBuild Materials",photos:[],notes:"Fragile — top load only"},
  {id:"LTL-2002",type:"LTL",origin:"Denver CO",dest:"Kansas City MO",pickup:"Apr 27",delivery:"Apr 28",commodity:"Medical Supplies",weight:"800",dims:"48x40x36 in",pallets:2,freight_class:"70",rate:420,status:"Available",shipper:"HealthLink Corp",photos:[],notes:"Temperature sensitive 35-45°F"},
];

const ACCOUNTING = [
  {id:1,type:"AR",desc:"LB-10041 — Midwest Auto Parts",amount:2450,status:"Paid",date:"Apr 22",due:"Apr 29",inv:"INV-1041"},
  {id:2,type:"AR",desc:"LB-10042 — FreshFarm Co-op",amount:1800,status:"Pending",date:"Apr 23",due:"May 3",inv:"INV-1042"},
  {id:3,type:"AP",desc:"FastLane Trucking — LB-10041",amount:2070,status:"Paid",date:"Apr 22",due:"Apr 29",inv:"BILL-041"},
  {id:4,type:"AP",desc:"Apex Haulers — LB-10042",amount:1510,status:"Pending",date:"Apr 23",due:"May 3",inv:"BILL-042"},
  {id:5,type:"AR",desc:"LTL-2001 — NovaBuild Materials",amount:890,status:"Overdue",date:"Apr 10",due:"Apr 20",inv:"INV-1043"},
];

const FUNNEL_STAGES = [
  {id:"prospect",label:"Prospect",color:C.muted,script:"Hi [Name], I'm [Your Name] from FreightCRM. We specialize in logistics solutions for companies like [Company]. Are you currently using a freight broker?"},
  {id:"contact",label:"First Contact",color:C.accent,script:"Great to connect! We've helped companies in [Industry] reduce freight costs by 15-20%. What are your biggest pain points with your current logistics setup?"},
  {id:"qualified",label:"Qualified",color:C.purple,script:"Based on what you've told me, we can definitely help. Let me walk you through our capacity on [Lanes]. We have dedicated carriers running this route weekly. What volume are you shipping?"},
  {id:"proposal",label:"Proposal Sent",color:C.gold,script:"I've sent over our rate proposal. Our all-in rate of $[X] includes tracking, insurance, and our 24/7 ops support. Compared to [Competitor], you'd save roughly $[Y] per load. Any questions?"},
  {id:"negotiation",label:"Negotiating",color:C.orange,script:"I understand price is a concern. If you can commit to [X] loads/month, I can lock in $[Rate]. That's [X]% below market for this lane. I'd need a decision by [Date] to hold this rate."},
  {id:"closed",label:"Closed Won",color:C.green,script:"Excellent! I'm sending over the broker-carrier agreement now. Our onboarding team will reach out within 24hrs. Welcome to FreightCRM — we're excited to move your freight!"},
];

const PIPELINE = [
  {id:1,company:"GlobalTech Imports",contact:"Rebecca Lane",stage:"proposal",value:"$48,000/mo",probability:65,lastTouch:"Apr 23",broker:"Sarah Kim",notes:"Sent rate sheet for TX→CA lane"},
  {id:2,company:"Midwest Auto Parts",contact:"Derek Kim",stage:"qualified",value:"$22,000/mo",probability:40,lastTouch:"Apr 22",broker:"Alex Johnson",notes:"Interested in flatbed capacity"},
  {id:3,company:"FreshFarm Co-op",contact:"Anna White",stage:"negotiation",value:"$15,500/mo",probability:80,lastTouch:"Apr 24",broker:"Mike Patel",notes:"Countered at $1,750 — deciding"},
  {id:4,company:"PharmaDist LLC",contact:"Carol Singh",stage:"prospect",value:"$8,000/mo",probability:15,lastTouch:"Apr 21",broker:"Sarah Kim",notes:"Cold outreach — no response yet"},
  {id:5,company:"SteelWorks USA",contact:"Ron Chavez",stage:"contact",value:"$35,000/mo",probability:25,lastTouch:"Apr 24",broker:"Tom Rivera",notes:"Had intro call — follow up Fri"},
];

const CALL_LOGS = [
  {id:1,contact:"Jake Morrison",company:"FastLane Trucking LLC",type:"Carrier",phone:"+1(512)555-0182",date:"Apr 24",time:"10:14 AM",duration:"4:32",agent:"Alex Johnson",topic:"Rate negotiation TX→CA",outcome:"Agreed $2.10/mi",sentiment:"Positive",duration_sec:272},
  {id:2,contact:"Rebecca Lane",company:"GlobalTech Imports",type:"Shipper",phone:"+1(312)555-0177",date:"Apr 24",time:"9:02 AM",duration:"6:18",agent:"Sarah Kim",topic:"Q2 volume commitment",outcome:"Follow-up scheduled",sentiment:"Neutral",duration_sec:378},
  {id:3,contact:"Anna White",company:"FreshFarm Co-op",type:"Shipper",phone:"+1(559)555-0188",date:"Apr 23",time:"1:22 PM",duration:"8:45",agent:"Mike Patel",topic:"Reefer availability",outcome:"Sent capacity report",sentiment:"Positive",duration_sec:525},
];

/* ─── HELPERS ────────────────────────────────────────────── */
const Ic = ({ n, s=18 }) => {
  const p = {
    dashboard:"M3 13h8V3H3v10zm0 8h8v-6H3v6zm10 0h8V11h-8v10zm0-18v6h8V3h-8z",
    truck:"M20 8h-3V4H3c-1.1 0-2 .9-2 2v11h2c0 1.66 1.34 3 3 3s3-1.34 3-3h6c0 1.66 1.34 3 3 3s3-1.34 3-3h2v-5l-3-4zM6 18.5c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zm13.5-9l1.96 2.5H17V9.5h2.5zm-1.5 9c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5z",
    people:"M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5C6.34 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z",
    accounting:"M11.8 10.9c-2.27-.59-3-1.2-3-2.15 0-1.09 1.01-1.85 2.7-1.85 1.78 0 2.44.85 2.5 2.1h2.21c-.07-1.72-1.12-3.3-3.21-3.81V3h-3v2.16c-1.94.42-3.5 1.68-3.5 3.61 0 2.31 1.91 3.46 4.7 4.13 2.5.6 3 1.48 3 2.41 0 .69-.49 1.79-2.7 1.79-2.06 0-2.87-.92-2.98-2.1h-2.2c.12 2.19 1.76 3.42 3.68 3.83V21h3v-2.15c1.95-.37 3.5-1.5 3.5-3.55 0-2.84-2.43-3.81-4.7-4.4z",
    funnel:"M10 18h4v-2h-4v2zM3 6v2h18V6H3zm3 7h12v-2H6v2z",
    calls:"M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z",
    map:"M20.5 3l-.16.03L15 5.1 9 3 3.36 4.9c-.21.07-.36.25-.36.48V20.5c0 .28.22.5.5.5l.16-.03L9 18.9l6 2.1 5.64-1.9c.21-.07.36-.25.36-.48V3.5c0-.28-.22-.5-.5-.5zM15 19l-6-2.11V5l6 2.11V19z",
    ltl:"M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-7 3c1.93 0 3.5 1.57 3.5 3.5S13.93 13 12 13s-3.5-1.57-3.5-3.5S10.07 6 12 6zm7 13H5v-.23c0-.62.28-1.2.76-1.58C7.47 15.82 9.64 15 12 15s4.53.82 6.24 2.19c.48.38.76.97.76 1.58V19z",
    plus:"M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z",
    close:"M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z",
    check:"M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z",
    edit:"M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z",
    trash:"M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z",
    play:"M8 5v14l11-7z",
    pause:"M6 19h4V5H6v14zm8-14v14h4V5h-4z",
    phone_out:"M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z",
    mic:"M12 14c1.66 0 3-1.34 3-3V5c0-1.66-1.34-3-3-3S9 3.34 9 5v6c0 1.66 1.34 3 3 3zm5.3-3c0 3-2.54 5.1-5.3 5.1S6.7 14 6.7 11H5c0 3.41 2.72 6.23 6 6.72V21h2v-3.28c3.28-.49 6-3.31 6-6.72h-1.7z",
    bell:"M12 22c1.1 0 2-.9 2-2h-4c0 1.1.9 2 2 2zm6-6v-5c0-3.07-1.64-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68C7.63 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2z",
    star:"M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z",
    search:"M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z",
    arrow:"M12 4l-1.41 1.41L16.17 11H4v2h12.17l-5.58 5.59L12 20l8-8z",
    photo:"M21 19V5c0-1.1-.9-2-2-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2zM8.5 13.5l2.5 3.01L14.5 12l4.5 6H5l3.5-4.5z",
    download:"M19 9h-4V3H9v6H5l7 7 7-7zM5 18v2h14v-2H5z",
    card:"M20 4H4c-1.11 0-2 .89-2 2v12c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V6c0-1.11-.89-2-2-2zm0 14H4v-6h16v6zm0-10H4V6h16v2z",
    bank:"M11.5 1L2 6v2h19V6m-5 4v7h3v-7M2 20v2h19v-2m-9-4v-3h-2v3h-3v3h8v-3m3-9v7h3v-7",
    route:"M21 3L3 10.53v.98l6.84 2.65L12.48 21h.98L21 3z",
    shield:"M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm-2 16l-4-4 1.41-1.41L10 14.17l6.59-6.59L18 9l-8 8z",
    calendar:"M19 3h-1V1h-2v2H8V1H6v2H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V8h14v11zM7 10h5v5H7z",
    tracking:"M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z",
    calculator:"M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-5 14h-2v-2h2v2zm0-4h-2v-2h2v2zm0-4h-2V7h2v2zm4 8h-2v-2h2v2zm0-4h-2v-2h2v2zm0-4h-2V7h2v2zM7 7h4v2H7V7zm0 4h2v2H7v-2zm0 4h2v2H7v-2z",
    robot:"M20 9V7c0-1.1-.9-2-2-2h-3c0-1.66-1.34-3-3-3S9 3.34 9 5H6c-1.1 0-2 .9-2 2v2c-1.66 0-3 1.34-3 3s1.34 3 3 3v4c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2v-4c1.66 0 3-1.34 3-3s-1.34-3-3-3zm-2 10H6V7h12v12zm-9-6c-.83 0-1.5-.67-1.5-1.5S9.17 10 10 10s1.5.67 1.5 1.5S10.83 13 10 13zm4 0c-.83 0-1.5-.67-1.5-1.5S13.17 10 14 10s1.5.67 1.5 1.5S14.83 13 14 13zm-7 3h6v-1.5H7V16z",
    script:"M14 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8l-6-6zm2 16H8v-2h8v2zm0-4H8v-2h8v2zm-3-5V3.5L18.5 9H13z",
    warning:"M1 21h22L12 2 1 21zm12-3h-2v-2h2v2zm0-4h-2v-4h2v4z",
  };
  return <svg width={s} height={s} viewBox="0 0 24 24" fill="currentColor"><path d={p[n]||p.dashboard}/></svg>;
};

const Badge = ({ label, color }) => {
  const map = {
    Active:C.green,Inactive:C.muted,Preferred:C.gold,
    "In Transit":C.accent,Booked:C.purple,Available:C.green,Delivered:C.muted,
    Hot:C.red,Warm:C.orange,Cold:"#5b8aff",
    High:C.red,Medium:C.orange,Low:C.green,
    Positive:C.green,Neutral:C.muted,Negative:C.red,
    Paid:C.green,Pending:C.orange,Overdue:C.red,
    Carrier:C.accent,Shipper:C.gold,
    FTL:C.accent,LTL:C.teal,
    AR:"#34d399",AP:"#f87171",
  };
  const c = color || map[label] || C.muted;
  return <span style={{background:`${c}22`,color:c,border:`1px solid ${c}44`,padding:"2px 9px",borderRadius:20,fontSize:10.5,fontWeight:700,letterSpacing:"0.6px",textTransform:"uppercase",whiteSpace:"nowrap"}}>{label}</span>;
};

const Card = ({ children, style={}, onClick, hover=false }) => {
  const [hov, setHov] = useState(false);
  return (
    <div onClick={onClick}
      onMouseEnter={()=>hover&&setHov(true)}
      onMouseLeave={()=>hover&&setHov(false)}
      style={{background:C.card,border:`1px solid ${hov?C.accent+"55":C.border}`,borderRadius:14,transition:"border-color 0.2s, transform 0.2s",transform:hov?"translateY(-2px)":"none",...style}}>
      {children}
    </div>
  );
};

const inp = {width:"100%",padding:"9px 13px",background:"rgba(255,255,255,0.05)",border:`1px solid ${C.border}`,borderRadius:8,color:C.text,fontSize:13,outline:"none",boxSizing:"border-box",fontFamily:"inherit"};

const Fl = ({ label, value, onChange, type="text", options, placeholder="" }) => (
  <div style={{marginBottom:14}}>
    <label style={{display:"block",color:C.muted,fontSize:11,marginBottom:5,textTransform:"uppercase",letterSpacing:"0.5px"}}>{label}</label>
    {options
      ? <select value={value} onChange={e=>onChange(e.target.value)} style={{...inp,appearance:"none"}}>{options.map(o=><option key={o} value={o}>{o}</option>)}</select>
      : <input type={type} value={value} onChange={e=>onChange(e.target.value)} placeholder={placeholder} style={inp}/>}
  </div>
);

const Modal = ({ title, onClose, children, width=520 }) => (
  <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.85)",display:"flex",alignItems:"center",justifyContent:"center",zIndex:2000,backdropFilter:"blur(6px)"}}>
    <div style={{background:"#0c1525",border:`1px solid ${C.border}`,borderRadius:18,padding:28,width,maxWidth:"96vw",maxHeight:"92vh",overflowY:"auto",boxShadow:"0 32px 120px rgba(0,0,0,0.7)"}}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:22}}>
        <h3 style={{color:C.text,fontSize:16,fontWeight:700,margin:0}}>{title}</h3>
        <button onClick={onClose} style={{background:"rgba(255,255,255,0.06)",border:"none",color:C.muted,width:30,height:30,borderRadius:8,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center"}}><Ic n="close" s={15}/></button>
      </div>
      {children}
    </div>
  </div>
);

const PrimaryBtn = ({ children, onClick, icon, style:s={} }) => (
  <button onClick={onClick} style={{display:"flex",alignItems:"center",gap:7,padding:"9px 18px",borderRadius:9,border:"none",cursor:"pointer",fontSize:13,fontWeight:700,fontFamily:"inherit",background:`linear-gradient(135deg,${C.accent},#007aaa)`,color:"#000",...s}}>
    {icon&&<Ic n={icon} s={14}/>}{children}
  </button>
);

const GhostBtn = ({ children, onClick, icon, color=C.muted, style:s={} }) => (
  <button onClick={onClick} style={{display:"flex",alignItems:"center",gap:7,padding:"8px 14px",borderRadius:9,border:`1px solid ${C.border}`,cursor:"pointer",fontSize:12,fontWeight:600,fontFamily:"inherit",background:"rgba(255,255,255,0.04)",color,...s}}>
    {icon&&<Ic n={icon} s={13}/>}{children}
  </button>
);

/* ─── DASHBOARD ──────────────────────────────────────────── */
const Dashboard = () => {
  const totalRevenue = [...LOADS_FTL,...LOADS_LTL].reduce((s,l)=>s+l.rate,0);
  const totalMargin = LOADS_FTL.reduce((s,l)=>s+(l.margin||0),0);
  const ar = ACCOUNTING.filter(a=>a.type==="AR").reduce((s,a)=>s+a.amount,0);
  const ap = ACCOUNTING.filter(a=>a.type==="AP").reduce((s,a)=>s+a.amount,0);

  return (
    <div>
      <div style={{marginBottom:26}}>
        <h2 style={{color:C.text,fontSize:22,fontWeight:900,margin:"0 0 3px",letterSpacing:"-0.5px"}}>Operations Overview</h2>
        <p style={{color:C.muted,margin:0,fontSize:12}}>Friday, April 25, 2026 · US Eastern Time</p>
      </div>
      {/* KPIs */}
      <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:12,marginBottom:16}}>
        {[
          {label:"Active Loads",val:LOADS_FTL.filter(l=>l.status!=="Delivered").length+LOADS_LTL.filter(l=>l.status!=="Delivered").length,icon:"truck",color:C.accent,sub:"FTL + LTL"},
          {label:"Pipeline Revenue",val:`$${(totalRevenue/1000).toFixed(1)}K`,icon:"accounting",color:C.gold,sub:`$${totalMargin} margin`},
          {label:"AR Outstanding",val:`$${(ar/1000).toFixed(1)}K`,icon:"accounting",color:C.green,sub:`$${(ap/1000).toFixed(1)}K AP`},
          {label:"Team Members",val:EMPLOYEES.length,icon:"people",color:C.purple,sub:"All active"},
        ].map((k,i)=>(
          <Card key={i} style={{padding:"18px 20px",position:"relative",overflow:"hidden"}}>
            <div style={{position:"absolute",top:-16,right:-16,width:60,height:60,borderRadius:"50%",background:k.color,opacity:0.08}}/>
            <div style={{color:k.color,marginBottom:10}}><Ic n={k.icon} s={20}/></div>
            <div style={{fontSize:28,fontWeight:900,color:C.text,lineHeight:1}}>{k.val}</div>
            <div style={{fontSize:11,color:C.muted,marginTop:3}}>{k.label}</div>
            <div style={{fontSize:11,color:k.color,marginTop:6,fontWeight:600}}>{k.sub}</div>
          </Card>
        ))}
      </div>
      <div style={{display:"grid",gridTemplateColumns:"1.5fr 1fr",gap:14,marginBottom:14}}>
        {/* Load Status */}
        <Card style={{padding:22}}>
          <div style={{color:C.muted,fontSize:11,textTransform:"uppercase",letterSpacing:"1px",marginBottom:16}}>Live Loads</div>
          {[...LOADS_FTL,...LOADS_LTL].map((l,i)=>{
            const sc={InTransit:C.accent,Booked:C.purple,Available:C.green};
            return(
              <div key={i} style={{display:"flex",alignItems:"center",gap:12,paddingBottom:11,borderBottom:i<LOADS_FTL.length+LOADS_LTL.length-1?`1px solid ${C.border}`:"none",marginBottom:i<LOADS_FTL.length+LOADS_LTL.length-1?11:0}}>
                <div style={{width:7,height:7,borderRadius:"50%",background:sc[l.status?.replace(" ","")]||C.muted,flexShrink:0}}/>
                <div style={{flex:1}}>
                  <div style={{color:C.text,fontSize:12,fontWeight:600}}>{l.id} <Badge label={l.type}/></div>
                  <div style={{color:C.muted,fontSize:11,marginTop:1}}>{l.origin} → {l.dest}</div>
                </div>
                <div style={{textAlign:"right"}}>
                  <div style={{color:C.gold,fontSize:13,fontWeight:700}}>${l.rate.toLocaleString()}</div>
                  <Badge label={l.status}/>
                </div>
              </div>
            );
          })}
        </Card>
        {/* Funnel Summary */}
        <Card style={{padding:22}}>
          <div style={{color:C.muted,fontSize:11,textTransform:"uppercase",letterSpacing:"1px",marginBottom:16}}>Sales Funnel</div>
          {FUNNEL_STAGES.map((stage,i)=>{
            const count=PIPELINE.filter(p=>p.stage===stage.id).length;
            return(
              <div key={i} style={{display:"flex",alignItems:"center",gap:10,marginBottom:10}}>
                <div style={{width:8,height:8,borderRadius:"50%",background:stage.color,flexShrink:0}}/>
                <div style={{flex:1,fontSize:12,color:C.muted}}>{stage.label}</div>
                <div style={{fontSize:13,fontWeight:700,color:count>0?stage.color:C.dim}}>{count}</div>
              </div>
            );
          })}
          <div style={{marginTop:14,paddingTop:14,borderTop:`1px solid ${C.border}`}}>
            <div style={{fontSize:11,color:C.muted}}>Total Pipeline Value</div>
            <div style={{fontSize:20,fontWeight:900,color:C.gold}}>$128,500/mo</div>
          </div>
        </Card>
      </div>
      {/* AR/AP quick */}
      <Card style={{padding:22}}>
        <div style={{color:C.muted,fontSize:11,textTransform:"uppercase",letterSpacing:"1px",marginBottom:14}}>Accounting Snapshot</div>
        <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:12}}>
          {[
            {label:"Accounts Receivable",val:`$${ar.toLocaleString()}`,color:C.green},
            {label:"Accounts Payable",val:`$${ap.toLocaleString()}`,color:C.red},
            {label:"Net Position",val:`$${(ar-ap).toLocaleString()}`,color:C.gold},
          ].map((item,i)=>(
            <div key={i} style={{padding:"14px 16px",background:`${item.color}11`,borderRadius:10,border:`1px solid ${item.color}22`}}>
              <div style={{fontSize:10,color:C.muted,textTransform:"uppercase",letterSpacing:"0.5px",marginBottom:6}}>{item.label}</div>
              <div style={{fontSize:24,fontWeight:900,color:item.color}}>{item.val}</div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
};

/* ─── EMPLOYEES ──────────────────────────────────────────── */
const EmployeesPage = () => {
  const [employees,setEmployees] = useState(EMPLOYEES);
  const [showAdd,setShowAdd] = useState(false);
  const [selected,setSelected] = useState(null);
  const [form,setForm] = useState({name:"",role:"Broker",dept:"Operations",email:"",phone:"",salary:"",status:"Active"});

  const add = () => {
    if(!form.name)return;
    setEmployees([...employees,{...form,id:Date.now(),avatar:form.name.split(" ").map(n=>n[0]).join(""),loads:0,revenue:"$0",hired:new Date().toISOString().split("T")[0]}]);
    setShowAdd(false);
    setForm({name:"",role:"Broker",dept:"Operations",email:"",phone:"",salary:"",status:"Active"});
  };

  const deptColors={Operations:C.accent,Sales:C.gold,Procurement:C.purple,Accounting:C.teal};

  return (
    <div>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:22}}>
        <div>
          <h2 style={{color:C.text,fontSize:20,fontWeight:900,margin:"0 0 3px"}}>Team</h2>
          <p style={{color:C.muted,margin:0,fontSize:12}}>{employees.length} employees</p>
        </div>
        <PrimaryBtn icon="plus" onClick={()=>setShowAdd(true)}>Add Employee</PrimaryBtn>
      </div>


      <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(300px,1fr))",gap:14}}>
        {employees.map(emp=>(
          <Card key={emp.id} hover style={{padding:22,cursor:"pointer"}} onClick={()=>setSelected(emp)}>
            <div style={{display:"flex",gap:14,alignItems:"flex-start",marginBottom:16}}>
              <div style={{width:50,height:50,borderRadius:14,background:`linear-gradient(135deg,${deptColors[emp.dept]||C.accent}33,${deptColors[emp.dept]||C.accent}11)`,color:deptColors[emp.dept]||C.accent,display:"flex",alignItems:"center",justifyContent:"center",fontWeight:900,fontSize:16,flexShrink:0}}>{emp.avatar}</div>
              <div style={{flex:1}}>
                <div style={{color:C.text,fontWeight:700,fontSize:14}}>{emp.name}</div>
                <div style={{color:C.muted,fontSize:12,marginTop:1}}>{emp.role}</div>
                <div style={{marginTop:6,display:"flex",gap:6}}>
                  <Badge label={emp.dept} color={deptColors[emp.dept]}/>
                  <Badge label={emp.status}/>
                </div>
              </div>
            </div>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:10}}>
              {[{l:"Loads",v:emp.loads},{l:"Revenue",v:emp.revenue},{l:"Hired",v:emp.hired?.slice(0,7)}].map((r,i)=>(
                <div key={i}>
                  <div style={{fontSize:10,color:C.muted,textTransform:"uppercase",letterSpacing:"0.5px",marginBottom:2}}>{r.l}</div>
                  <div style={{fontSize:12,color:C.text,fontWeight:600}}>{r.v}</div>
                </div>
              ))}
            </div>
            <div style={{marginTop:14,paddingTop:12,borderTop:`1px solid ${C.border}`,display:"flex",gap:8}}>
              <div style={{fontSize:11,color:C.muted}}>{emp.email}</div>
            </div>
          </Card>
        ))}
      </div>

      {/* Add modal */}
      {showAdd&&(
        <Modal title="Add Employee" onClose={()=>setShowAdd(false)}>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
            <Fl label="Full Name" value={form.name} onChange={v=>setForm({...form,name:v})}/>
            <Fl label="Role" value={form.role} onChange={v=>setForm({...form,role:v})} options={["Senior Broker","Broker","Sales Rep","Dispatcher","Carrier Relations","Accounting","Manager"]}/>
            <Fl label="Department" value={form.dept} onChange={v=>setForm({...form,dept:v})} options={["Operations","Sales","Procurement","Accounting","Management"]}/>
            <Fl label="Status" value={form.status} onChange={v=>setForm({...form,status:v})} options={["Active","Inactive","On Leave"]}/>
            <Fl label="Email" value={form.email} onChange={v=>setForm({...form,email:v})} type="email"/>
            <Fl label="Phone" value={form.phone} onChange={v=>setForm({...form,phone:v})}/>
            <Fl label="Annual Salary" value={form.salary} onChange={v=>setForm({...form,salary:v})}/>
          </div>
          <PrimaryBtn onClick={add} style={{width:"100%",justifyContent:"center",marginTop:8}}>Add Employee</PrimaryBtn>
        </Modal>
      )}

      {/* Detail modal */}
      {selected&&(
        <Modal title="Employee Profile" onClose={()=>setSelected(null)} width={560}>
          <div style={{display:"flex",gap:16,marginBottom:22,padding:16,background:"rgba(255,255,255,0.03)",borderRadius:12}}>
            <div style={{width:60,height:60,borderRadius:16,background:`${C.accent}22`,color:C.accent,display:"flex",alignItems:"center",justifyContent:"center",fontWeight:900,fontSize:20}}>{selected.avatar}</div>
            <div>
              <div style={{color:C.text,fontWeight:700,fontSize:18}}>{selected.name}</div>
              <div style={{color:C.muted,fontSize:13}}>{selected.role} · {selected.dept}</div>
              <div style={{marginTop:8,display:"flex",gap:8}}><Badge label={selected.status}/><Badge label={selected.dept} color={deptColors[selected.dept]}/></div>
            </div>
          </div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
            {[{l:"Email",v:selected.email},{l:"Phone",v:selected.phone},{l:"Salary",v:selected.salary},{l:"Hired",v:selected.hired},{l:"Total Loads",v:selected.loads},{l:"Revenue Generated",v:selected.revenue}].map((r,i)=>(
              <div key={i} style={{padding:"10px 14px",background:"rgba(255,255,255,0.03)",borderRadius:8}}>
                <div style={{fontSize:10,color:C.muted,textTransform:"uppercase",letterSpacing:"0.5px",marginBottom:3}}>{r.l}</div>
                <div style={{fontSize:13,color:C.text,fontWeight:600}}>{r.v}</div>
              </div>
            ))}
          </div>
        </Modal>
      )}
    </div>
  );

};

/* ─── CARRIER PAYMENTS ───────────────────────────────────── */
const CarrierPayments = () => {
  const [carriers,setCarriers]=useState(CARRIERS);
  const [selected,setSelected]=useState(null);

  const payColor={QuickPay:C.green,"Standard 30":C.muted,Factoring:C.gold};

  return (
    <div>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:22}}>
        <div>
          <h2 style={{color:C.text,fontSize:20,fontWeight:900,margin:"0 0 3px"}}>Carrier Network & Payments</h2>
          <p style={{color:C.muted,margin:0,fontSize:12}}>{carriers.length} carriers · click to view payment details</p>
        </div>
        <PrimaryBtn icon="plus" onClick={()=>{}}>Add Carrier</PrimaryBtn>
      </div>

      <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(340px,1fr))",gap:14}}>
        {carriers.map(c=>(
          <Card key={c.id} hover style={{padding:22,cursor:"pointer"}} onClick={()=>setSelected(c)}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:14}}>
              <div>
                <div style={{color:C.text,fontWeight:700,fontSize:14}}>{c.name}</div>
                <div style={{color:C.muted,fontSize:11,marginTop:2}}>{c.mc} · {c.dot}</div>
              </div>
              <Badge label={c.status}/>
            </div>
            {/* Stars */}
            <div style={{display:"flex",alignItems:"center",gap:3,marginBottom:14}}>
              {Array.from({length:5},(_,i)=>(
                <svg key={i} width={13} height={13} viewBox="0 0 24 24" fill={i<Math.floor(c.rating)?C.gold:C.dim}><path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/></svg>
              ))}
              <span style={{fontSize:12,color:C.gold,marginLeft:4,fontWeight:700}}>{c.rating}</span>
            </div>
            {/* Payment info */}
            <div style={{padding:"12px 14px",background:"rgba(255,255,255,0.03)",borderRadius:10,marginBottom:12}}>
              <div style={{fontSize:10,color:C.muted,textTransform:"uppercase",letterSpacing:"0.5px",marginBottom:8}}>Payment</div>
              <div style={{display:"flex",alignItems:"center",justifyContent:"space-between"}}>
                <span style={{fontSize:13,color:payColor[c.payMethod]||C.muted,fontWeight:700}}>{c.payMethod}</span>
                {c.factoringCo&&<span style={{fontSize:11,color:C.muted}}>via {c.factoringCo}</span>}
              </div>
              {c.factoringFee&&<div style={{fontSize:11,color:C.muted,marginTop:4}}>Factoring fee: <span style={{color:C.orange}}>{c.factoringFee}</span></div>}
            </div>
            <div style={{display:"flex",justifyContent:"space-between",fontSize:11,color:C.muted}}>
              <span>{c.equipment}</span>
              <span>{c.loads} loads completed</span>
            </div>
            <div style={{marginTop:12,paddingTop:12,borderTop:`1px solid ${C.border}`,display:"flex",gap:8}}>
              <GhostBtn icon="card" color={C.accent} style={{flex:1,justifyContent:"center"}}>Pay Now</GhostBtn>
              <GhostBtn icon="route" style={{flex:1,justifyContent:"center"}}>Assign Load</GhostBtn>
            </div>
          </Card>
        ))}
      </div>

      {/* Carrier detail modal with full payment info */}
      {selected&&(
        <Modal title="Carrier Payment Details" onClose={()=>setSelected(null)} width={580}>
          <div style={{display:"flex",gap:14,marginBottom:20,padding:16,background:"rgba(255,255,255,0.03)",borderRadius:12}}>
            <div style={{width:48,height:48,borderRadius:12,background:C.accentDim,color:C.accent,display:"flex",alignItems:"center",justifyContent:"center",fontWeight:900,fontSize:16,flexShrink:0}}>
              {selected.name.split(" ").map(n=>n[0]).slice(0,2).join("")}
            </div>
            <div style={{flex:1}}>
              <div style={{color:C.text,fontWeight:700,fontSize:16}}>{selected.name}</div>
              <div style={{color:C.muted,fontSize:12}}>{selected.mc} · {selected.city}</div>
              <div style={{display:"flex",gap:8,marginTop:6}}><Badge label={selected.status}/></div>
            </div>
          </div>

          {/* Payment Method */}
          <div style={{marginBottom:16}}>
            <div style={{color:C.muted,fontSize:11,textTransform:"uppercase",letterSpacing:"0.5px",marginBottom:10}}>Payment Method</div>
            <div style={{display:"flex",gap:10}}>
              {["QuickPay","Standard 30","Factoring"].map(m=>(
                <div key={m} style={{flex:1,padding:"12px",background:selected.payMethod===m?`${C.accent}18`:"rgba(255,255,255,0.03)",border:`1px solid ${selected.payMethod===m?C.accent:C.border}`,borderRadius:10,textAlign:"center",cursor:"pointer"}}>
                  <div style={{fontSize:12,color:selected.payMethod===m?C.accent:C.muted,fontWeight:selected.payMethod===m?700:400}}>{m}</div>
                  <div style={{fontSize:10,color:C.muted,marginTop:3}}>{m==="QuickPay"?"Same day":m==="Standard 30"?"Net 30":"Via factor"}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Factoring */}
          {selected.payMethod==="Factoring"&&(
            <div style={{padding:"14px",background:`${C.gold}11`,border:`1px solid ${C.gold}22`,borderRadius:10,marginBottom:16}}>
              <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:10}}>
                <Ic n="warning" s={16}/>
                <span style={{color:C.gold,fontSize:13,fontWeight:700}}>Factoring Company</span>
              </div>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
                <div>
                  <div style={{fontSize:10,color:C.muted,textTransform:"uppercase",marginBottom:2}}>Company</div>
                  <div style={{fontSize:13,color:C.text}}>{selected.factoringCo}</div>
                </div>
                <div>
                  <div style={{fontSize:10,color:C.muted,textTransform:"uppercase",marginBottom:2}}>Fee</div>
                  <div style={{fontSize:13,color:C.orange,fontWeight:700}}>{selected.factoringFee}</div>
                </div>
              </div>
              <div style={{fontSize:11,color:C.muted,marginTop:8}}>⚠ Send remittance/BOL directly to {selected.factoringCo}. Do NOT pay carrier directly.</div>
            </div>
          )}

          {/* Bank Info */}
          <div style={{marginBottom:16}}>
            <div style={{color:C.muted,fontSize:11,textTransform:"uppercase",letterSpacing:"0.5px",marginBottom:10}}>Banking Information</div>
            <div style={{padding:16,background:"rgba(0,0,0,0.3)",borderRadius:10}}>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:12}}>
                <div>
                  <div style={{fontSize:10,color:C.muted,textTransform:"uppercase",marginBottom:2}}>Bank</div>
                  <div style={{fontSize:13,color:C.text}}>{selected.bankName}</div>
                </div>
                <div>
                  <div style={{fontSize:10,color:C.muted,textTransform:"uppercase",marginBottom:2}}>Routing</div>
                  <div style={{fontSize:13,color:C.text}}>{selected.routing}</div>
                </div>
                <div>
                  <div style={{fontSize:10,color:C.muted,textTransform:"uppercase",marginBottom:2}}>Account</div>
                  <div style={{fontSize:13,color:C.text}}>{selected.account}</div>
                </div>
              </div>
            </div>
          </div>

          {/* W9 / Insurance */}
          <div style={{display:"flex",gap:10,marginBottom:16}}>
            <div style={{flex:1,padding:"10px 14px",background:selected.w9?`${C.green}11`:`${C.red}11`,border:`1px solid ${selected.w9?C.green:C.red}22`,borderRadius:10,display:"flex",alignItems:"center",gap:8}}>
              <Ic n={selected.w9?"check":"warning"} s={16}/>
              <div>
                <div style={{fontSize:11,color:C.muted}}>W-9 Form</div>
                <div style={{fontSize:12,fontWeight:700,color:selected.w9?C.green:C.red}}>{selected.w9?"On File":"Missing"}</div>
              </div>
            </div>
            <div style={{flex:1,padding:"10px 14px",background:`${C.green}11`,border:`1px solid ${C.green}22`,borderRadius:10,display:"flex",alignItems:"center",gap:8}}>
              <Ic n="check" s={16}/>
              <div>
                <div style={{fontSize:11,color:C.muted}}>Cargo Insurance</div>
                <div style={{fontSize:12,fontWeight:700,color:C.green}}>{selected.insurance} ✓</div>
              </div>
            </div>
          </div>

          <div style={{display:"flex",gap:10}}>
            <PrimaryBtn icon="card" style={{flex:1,justifyContent:"center"}}>Process Payment</PrimaryBtn>
            <GhostBtn icon="download" style={{flex:1,justifyContent:"center"}}>Download BOL</GhostBtn>
          </div>
        </Modal>
      )}
    </div>
  );
};

/* ─── ACCOUNTING ─────────────────────────────────────────── */
const AccountingPage = () => {
  const [tab,setTab]=useState("all");
  const [showAdd,setShowAdd]=useState(false);
  const [entries,setEntries]=useState(ACCOUNTING);
  const [form,setForm]=useState({type:"AR",desc:"",amount:"",status:"Pending",date:"",due:"",inv:""});

  const filtered=entries.filter(e=>tab==="all"||e.type===tab||(tab==="overdue"&&e.status==="Overdue"));
  const ar=entries.filter(e=>e.type==="AR").reduce((s,e)=>s+e.amount,0);
  const ap=entries.filter(e=>e.type==="AP").reduce((s,e)=>s+e.amount,0);
  const overdue=entries.filter(e=>e.status==="Overdue").reduce((s,e)=>s+e.amount,0);

  const addEntry=()=>{
    if(!form.desc)return;
    setEntries([...entries,{...form,id:Date.now(),amount:parseFloat(form.amount)||0}]);
    setShowAdd(false);
    setForm({type:"AR",desc:"",amount:"",status:"Pending",date:"",due:"",inv:""});
  };

  return (
    <div>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:22}}>
        <div>
          <h2 style={{color:C.text,fontSize:20,fontWeight:900,margin:"0 0 3px"}}>Accounting</h2>
          <p style={{color:C.muted,margin:0,fontSize:12}}>AR, AP, Invoices & Collections</p>
        </div>
        <PrimaryBtn icon="plus" onClick={()=>setShowAdd(true)}>New Entry</PrimaryBtn>
      </div>

      {/* Summary cards */}
      <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:12,marginBottom:20}}>
        {[
          {label:"Accounts Receivable",val:`$${ar.toLocaleString()}`,color:C.green,sub:`${entries.filter(e=>e.type==="AR"&&e.status==="Pending").length} pending`},
          {label:"Accounts Payable",val:`$${ap.toLocaleString()}`,color:C.red,sub:`${entries.filter(e=>e.type==="AP"&&e.status==="Pending").length} pending`},
          {label:"Overdue",val:`$${overdue.toLocaleString()}`,color:C.orange,sub:`${entries.filter(e=>e.status==="Overdue").length} invoices`},
          {label:"Net P&L",val:`$${(ar-ap).toLocaleString()}`,color:ar>ap?C.green:C.red,sub:"This period"},
        ].map((s,i)=>(
          <Card key={i} style={{padding:"16px 18px"}}>
            <div style={{fontSize:22,fontWeight:900,color:s.color}}>{s.val}</div>
            <div style={{fontSize:11,color:C.muted,marginTop:3}}>{s.label}</div>
            <div style={{fontSize:11,color:s.color,marginTop:5,fontWeight:600}}>{s.sub}</div>
          </Card>
        ))}
      </div>

      {/* Tabs */}
      <div style={{display:"flex",gap:8,marginBottom:14}}>
        {[{k:"all",l:"All"},{k:"AR",l:"Receivable"},{k:"AP",l:"Payable"},{k:"overdue",l:"Overdue"}].map(t=>(
          <button key={t.k} onClick={()=>setTab(t.k)} style={{padding:"7px 16px",borderRadius:8,border:"1px solid",borderColor:tab===t.k?C.accent:C.border,background:tab===t.k?C.accentDim:"transparent",color:tab===t.k?C.accent:C.muted,fontSize:12,cursor:"pointer",fontFamily:"inherit",fontWeight:tab===t.k?700:400}}>{t.l}</button>
        ))}
      </div>

      {/* Table */}
      <Card>
        <div style={{display:"grid",gridTemplateColumns:"60px 1fr 80px 100px 90px 90px 80px",padding:"10px 18px",borderBottom:`1px solid ${C.border}`}}>
          {["Type","Description","Amount","Status","Date","Due","Invoice"].map((h,i)=>(
            <div key={i} style={{fontSize:10,color:C.muted,textTransform:"uppercase",letterSpacing:"0.5px",fontWeight:700}}>{h}</div>
          ))}
        </div>
        {filtered.map((e,i)=>(
          <div key={e.id} style={{display:"grid",gridTemplateColumns:"60px 1fr 80px 100px 90px 90px 80px",padding:"13px 18px",alignItems:"center",borderBottom:i<filtered.length-1?`1px solid ${C.border}`:"none"}}
            onMouseEnter={el=>el.currentTarget.style.background="rgba(255,255,255,0.02)"}
            onMouseLeave={el=>el.currentTarget.style.background="transparent"}
          >
            <Badge label={e.type}/>
            <div style={{color:C.text,fontSize:13}}>{e.desc}</div>
            <div style={{color:e.type==="AR"?C.green:C.red,fontSize:13,fontWeight:700}}>${e.amount.toLocaleString()}</div>
            <Badge label={e.status}/>
            <div style={{color:C.muted,fontSize:12}}>{e.date}</div>
            <div style={{color:e.status==="Overdue"?C.red:C.muted,fontSize:12,fontWeight:e.status==="Overdue"?700:400}}>{e.due}</div>
            <div style={{color:C.accent,fontSize:11}}>{e.inv}</div>
          </div>
        ))}
      </Card>

      {showAdd&&(
        <Modal title="New Accounting Entry" onClose={()=>setShowAdd(false)}>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
            <Fl label="Type" value={form.type} onChange={v=>setForm({...form,type:v})} options={["AR","AP"]}/>
            <Fl label="Status" value={form.status} onChange={v=>setForm({...form,status:v})} options={["Paid","Pending","Overdue"]}/>
          </div>
          <Fl label="Description" value={form.desc} onChange={v=>setForm({...form,desc:v})}/>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:12}}>
            <Fl label="Amount ($)" value={form.amount} onChange={v=>setForm({...form,amount:v})} type="number"/>
            <Fl label="Date" value={form.date} onChange={v=>setForm({...form,date:v})}/>
            <Fl label="Due Date" value={form.due} onChange={v=>setForm({...form,due:v})}/>
          </div>
          <Fl label="Invoice #" value={form.inv} onChange={v=>setForm({...form,inv:v})}/>
          <PrimaryBtn onClick={addEntry} style={{width:"100%",justifyContent:"center",marginTop:8}}>Add Entry</PrimaryBtn>
        </Modal>
      )}
    </div>
  );
};

/* ─── SALES FUNNEL ───────────────────────────────────────── */
const FunnelPage = () => {
  const [pipeline,setPipeline]=useState(PIPELINE);
  const [scriptStage,setScriptStage]=useState(null);
  const [showAdd,setShowAdd]=useState(false);
  const [form,setForm]=useState({company:"",contact:"",stage:"prospect",value:"",probability:20,broker:"Alex Johnson",notes:""});

  const addDeal=()=>{
    if(!form.company)return;
    setPipeline([...pipeline,{...form,id:Date.now(),lastTouch:new Date().toISOString().split("T")[0]}]);
    setShowAdd(false);
    setForm({company:"",contact:"",stage:"prospect",value:"",probability:20,broker:"Alex Johnson",notes:""});
  };

  const moveStage=(deal,dir)=>{
    const idx=FUNNEL_STAGES.findIndex(s=>s.id===deal.stage);
    const next=FUNNEL_STAGES[idx+dir];
    if(!next)return;
    setPipeline(pipeline.map(p=>p.id===deal.id?{...p,stage:next.id}:p));
  };

  return (
    <div>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:22}}>
        <div>
          <h2 style={{color:C.text,fontSize:20,fontWeight:900,margin:"0 0 3px"}}>Sales Funnel</h2>
          <p style={{color:C.muted,margin:0,fontSize:12}}>{pipeline.length} deals · click stage for call script</p>
        </div>
        <div style={{display:"flex",gap:10}}>
          <GhostBtn icon="script" color={C.purple} onClick={()=>setScriptStage(FUNNEL_STAGES[0])}>View Scripts</GhostBtn>
          <PrimaryBtn icon="plus" onClick={()=>setShowAdd(true)}>Add Deal</PrimaryBtn>
        </div>
      </div>

      {/* Kanban board */}
      <div style={{display:"grid",gridTemplateColumns:`repeat(${FUNNEL_STAGES.length},1fr)`,gap:10,overflowX:"auto"}}>
        {FUNNEL_STAGES.map(stage=>{
          const deals=pipeline.filter(p=>p.stage===stage.id);
          return(
            <div key={stage.id} style={{minWidth:170}}>
              {/* Column header */}
              <div onClick={()=>setScriptStage(stage)} style={{padding:"10px 14px",background:`${stage.color}18`,border:`1px solid ${stage.color}33`,borderRadius:10,marginBottom:10,cursor:"pointer",transition:"background 0.2s"}}
                onMouseEnter={e=>e.currentTarget.style.background=`${stage.color}28`}
                onMouseLeave={e=>e.currentTarget.style.background=`${stage.color}18`}
              >
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                  <div style={{fontSize:12,fontWeight:700,color:stage.color}}>{stage.label}</div>
                  <div style={{width:20,height:20,borderRadius:"50%",background:stage.color,color:"#000",display:"flex",alignItems:"center",justifyContent:"center",fontSize:11,fontWeight:800}}>{deals.length}</div>
                </div>
                <div style={{fontSize:10,color:stage.color,opacity:0.7,marginTop:3,display:"flex",alignItems:"center",gap:4}}>
                  <Ic n="script" s={10}/> Click for script
                </div>
              </div>
              {/* Cards */}
              <div style={{display:"flex",flexDirection:"column",gap:8}}>
                {deals.map(deal=>(
                  <Card key={deal.id} style={{padding:14}}>
                    <div style={{color:C.text,fontWeight:700,fontSize:13,marginBottom:3}}>{deal.company}</div>
                    <div style={{color:C.muted,fontSize:11,marginBottom:8}}>{deal.contact}</div>
                    <div style={{color:C.gold,fontSize:13,fontWeight:700,marginBottom:6}}>{deal.value}</div>
                    <div style={{marginBottom:8}}>
                      <div style={{height:4,background:C.dim,borderRadius:2}}>
                        <div style={{width:`${deal.probability}%`,height:"100%",background:stage.color,borderRadius:2}}/>
                      </div>
                      <div style={{fontSize:10,color:C.muted,marginTop:2}}>{deal.probability}% probability</div>
                    </div>
                    <div style={{fontSize:10,color:C.muted,marginBottom:8}}>Broker: {deal.broker}</div>
                    {deal.notes&&<div style={{fontSize:11,color:C.muted,padding:"6px 8px",background:"rgba(255,255,255,0.03)",borderRadius:6,marginBottom:8}}>{deal.notes}</div>}
                    <div style={{display:"flex",gap:4}}>
                      <button onClick={()=>moveStage(deal,-1)} style={{flex:1,padding:"5px",background:"rgba(255,255,255,0.04)",border:`1px solid ${C.border}`,color:C.muted,borderRadius:6,cursor:"pointer",fontSize:11,fontFamily:"inherit"}}>← Back</button>
                      <button onClick={()=>moveStage(deal,1)} style={{flex:1,padding:"5px",background:`${stage.color}18`,border:`1px solid ${stage.color}33`,color:stage.color,borderRadius:6,cursor:"pointer",fontSize:11,fontFamily:"inherit",fontWeight:700}}>Advance →</button>
                    </div>
                  </Card>
                ))}
              </div>
            </div>
          );
        })}
      </div>

      {/* Script modal */}
      {scriptStage&&(
        <Modal title={`Call Script — ${scriptStage.label}`} onClose={()=>setScriptStage(null)} width={560}>
          <div style={{display:"flex",gap:8,marginBottom:16,flexWrap:"wrap"}}>
            {FUNNEL_STAGES.map(s=>(
              <button key={s.id} onClick={()=>setScriptStage(s)} style={{padding:"6px 12px",borderRadius:7,border:`1px solid ${scriptStage.id===s.id?s.color:C.border}`,background:scriptStage.id===s.id?`${s.color}22`:"transparent",color:scriptStage.id===s.id?s.color:C.muted,fontSize:11,cursor:"pointer",fontFamily:"inherit",fontWeight:scriptStage.id===s.id?700:400}}>{s.label}</button>
            ))}
          </div>
          <div style={{padding:20,background:"rgba(255,255,255,0.03)",borderRadius:12,border:`1px solid ${scriptStage.color}33`,marginBottom:16}}>
            <div style={{fontSize:11,color:scriptStage.color,textTransform:"uppercase",letterSpacing:"1px",marginBottom:12,display:"flex",alignItems:"center",gap:6}}>
              <Ic n="mic" s={12}/> Script
            </div>
            <p style={{color:C.text,fontSize:14,lineHeight:1.7,margin:0,fontStyle:"italic"}}>"{scriptStage.script}"</p>
          </div>
          <div style={{padding:14,background:`${C.orange}11`,borderRadius:10,border:`1px solid ${C.orange}22`}}>
            <div style={{fontSize:11,color:C.orange,fontWeight:700,marginBottom:6}}>💡 Pro Tips for this Stage</div>
            <div style={{fontSize:12,color:C.muted,lineHeight:1.6}}>
              {scriptStage.id==="prospect"&&"Research the company before calling. Use LinkedIn to find the right contact. Best call times: Tue-Thu 10am-12pm or 2pm-4pm."}
              {scriptStage.id==="contact"&&"Listen more than you talk. Ask open-ended questions. Take notes on their pain points."}
              {scriptStage.id==="qualified"&&"Confirm they have budget authority. Get a volume commitment. Offer a trial load."}
              {scriptStage.id==="proposal"&&"Send proposal within 1 hour of call. Follow up 24 hours later. Address objections proactively."}
              {scriptStage.id==="negotiation"&&"Know your floor rate. Bundle value (tracking, support, insurance). Create urgency with market data."}
              {scriptStage.id==="closed"&&"Send agreement immediately. Intro to ops team. Schedule first load within 48 hours."}
            </div>
          </div>
          <div style={{display:"flex",gap:10,marginTop:16}}>
            <GhostBtn icon="download" style={{flex:1,justifyContent:"center"}}>Download Script PDF</GhostBtn>
            <GhostBtn icon="calls" color={C.green} style={{flex:1,justifyContent:"center"}}>Start Call</GhostBtn>
          </div>
        </Modal>
      )}

      {showAdd&&(
        <Modal title="Add Deal to Pipeline" onClose={()=>setShowAdd(false)}>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
            <Fl label="Company" value={form.company} onChange={v=>setForm({...form,company:v})}/>
            <Fl label="Contact Name" value={form.contact} onChange={v=>setForm({...form,contact:v})}/>
            <Fl label="Stage" value={form.stage} onChange={v=>setForm({...form,stage:v})} options={FUNNEL_STAGES.map(s=>s.id)}/>
            <Fl label="Expected Value" value={form.value} onChange={v=>setForm({...form,value:v})} placeholder="e.g. $15,000/mo"/>
            <Fl label="Probability %" value={form.probability} onChange={v=>setForm({...form,probability:v})} type="number"/>
            <Fl label="Assigned Broker" value={form.broker} onChange={v=>setForm({...form,broker:v})} options={EMPLOYEES.map(e=>e.name)}/>
          </div>
          <Fl label="Notes" value={form.notes} onChange={v=>setForm({...form,notes:v})}/>
          <PrimaryBtn onClick={addDeal} style={{width:"100%",justifyContent:"center",marginTop:8}}>Add Deal</PrimaryBtn>
        </Modal>
      )}
    </div>
  );
};

/* ─── LTL PAGE ───────────────────────────────────────────── */
const LTLPage = () => {
  const [loads,setLoads]=useState(LOADS_LTL);
  const [showAdd,setShowAdd]=useState(false);
  const [selected,setSelected]=useState(null);
  const [form,setForm]=useState({origin:"",dest:"",pickup:"",delivery:"",commodity:"",weight:"",dims:"",pallets:"",freight_class:"70",rate:"",status:"Available",shipper:"",notes:"",photos:[]});
  const fileRef=useRef();

  const handlePhoto=(e)=>{
    const files=Array.from(e.target.files);
    const readers=files.map(f=>new Promise(res=>{const r=new FileReader();r.onload=()=>res({name:f.name,url:r.result});r.readAsDataURL(f);}));
    Promise.all(readers).then(imgs=>setForm(prev=>({...prev,photos:[...prev.photos,...imgs]})));
  };

  const addLoad=()=>{
    if(!form.origin)return;
    setLoads([...loads,{...form,id:`LTL-${2010+loads.length}`,type:"LTL",rate:parseFloat(form.rate)||0}]);
    setShowAdd(false);
    setForm({origin:"",dest:"",pickup:"",delivery:"",commodity:"",weight:"",dims:"",pallets:"",freight_class:"70",rate:"",status:"Available",shipper:"",notes:"",photos:[]});
  };

  const fcColors={"50":C.green,"55":C.green,"60":C.teal,"65":C.teal,"70":C.accent,"77.5":C.accent,"85":C.gold,"92.5":C.orange,"100":C.orange,"110":C.red,"125":C.red,"150":C.red,"175":C.red,"200":C.red,"250":C.red,"300":C.red,"400":C.red,"500":C.red};

  return (
    <div>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:22}}>
        <div>
          <h2 style={{color:C.text,fontSize:20,fontWeight:900,margin:"0 0 3px"}}>LTL Load Board</h2>
          <p style={{color:C.muted,margin:0,fontSize:12}}>Less-than-truckload · Shippers can upload photos & dimensions</p>
        </div>
        <PrimaryBtn icon="plus" onClick={()=>setShowAdd(true)}>Post LTL Load</PrimaryBtn>
      </div>

      <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(340px,1fr))",gap:14}}>
        {loads.map(l=>(
          <Card key={l.id} hover style={{padding:22,cursor:"pointer"}} onClick={()=>setSelected(l)}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:14}}>
              <div>
                <div style={{color:C.teal,fontSize:12,fontWeight:700}}>{l.id}</div>
                <div style={{color:C.text,fontWeight:700,fontSize:14,marginTop:2}}>{l.commodity}</div>
              </div>
              <div style={{display:"flex",gap:6,flexDirection:"column",alignItems:"flex-end"}}>
                <Badge label="LTL" color={C.teal}/>
                <Badge label={l.status}/>
              </div>
            </div>
            <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:14}}>
              <span style={{color:C.text,fontSize:13,fontWeight:600}}>{l.origin}</span>
              <span style={{color:C.teal}}><Ic n="arrow" s={14}/></span>
              <span style={{color:C.text,fontSize:13,fontWeight:600}}>{l.dest}</span>
            </div>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:8,marginBottom:12}}>
              {[{l:"Weight",v:`${l.weight} lbs`},{l:"Pallets",v:`${l.pallets} PLT`},{l:"Class",v:`Class ${l.freight_class}`}].map((r,i)=>(
                <div key={i} style={{padding:"8px 10px",background:"rgba(255,255,255,0.03)",borderRadius:8}}>
                  <div style={{fontSize:10,color:C.muted,textTransform:"uppercase",marginBottom:2}}>{r.l}</div>
                  <div style={{fontSize:12,color:i===2?fcColors[l.freight_class]||C.text:C.text,fontWeight:600}}>{r.v}</div>
                </div>
              ))}
            </div>
            <div style={{fontSize:11,color:C.muted,marginBottom:10}}>📦 {l.dims}</div>
            {l.photos?.length>0&&(
              <div style={{display:"flex",gap:6,marginBottom:10,flexWrap:"wrap"}}>
                {l.photos.map((p,i)=>(
                  <div key={i} style={{width:52,height:52,borderRadius:8,overflow:"hidden",border:`1px solid ${C.border}`}}>
                    <img src={p.url} alt={p.name} style={{width:"100%",height:"100%",objectFit:"cover"}}/>
                  </div>
                ))}
                <div style={{fontSize:10,color:C.muted,display:"flex",alignItems:"center"}}>{l.photos.length} photo{l.photos.length>1?"s":""}</div>
              </div>
            )}
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
              <span style={{color:C.muted,fontSize:11}}>{l.pickup} → {l.delivery}</span>
              <span style={{color:C.gold,fontSize:18,fontWeight:900}}>${l.rate.toLocaleString()}</span>
            </div>
          </Card>
        ))}
      </div>

      {/* LTL Detail */}
      {selected&&(
        <Modal title={`LTL Load — ${selected.id}`} onClose={()=>setSelected(null)} width={560}>
          <div style={{display:"flex",alignItems:"center",gap:12,marginBottom:20,padding:16,background:"rgba(0,212,255,0.05)",borderRadius:12,border:`1px solid ${C.teal}22`}}>
            <div style={{color:C.teal}}><Ic n="truck" s={28}/></div>
            <div>
              <div style={{color:C.text,fontSize:16,fontWeight:700}}>{selected.commodity}</div>
              <div style={{color:C.muted,fontSize:13}}>{selected.origin} → {selected.dest}</div>
            </div>
            <div style={{marginLeft:"auto",textAlign:"right"}}>
              <div style={{color:C.gold,fontSize:22,fontWeight:900}}>${selected.rate.toLocaleString()}</div>
              <Badge label={selected.status}/>
            </div>
          </div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:16}}>
            {[{l:"Weight",v:`${selected.weight} lbs`},{l:"Dimensions",v:selected.dims},{l:"Pallets",v:selected.pallets},{l:"Freight Class",v:`Class ${selected.freight_class}`},{l:"Pickup",v:selected.pickup},{l:"Delivery",v:selected.delivery},{l:"Shipper",v:selected.shipper}].map((r,i)=>(
              <div key={i} style={{padding:"10px 14px",background:"rgba(255,255,255,0.03)",borderRadius:8}}>
                <div style={{fontSize:10,color:C.muted,textTransform:"uppercase",marginBottom:2}}>{r.l}</div>
                <div style={{fontSize:13,color:C.text,fontWeight:600}}>{r.v}</div>
              </div>
            ))}
          </div>
          {selected.notes&&(
            <div style={{padding:14,background:`${C.orange}11`,borderRadius:10,marginBottom:16,border:`1px solid ${C.orange}22`}}>
              <div style={{fontSize:11,color:C.orange,fontWeight:700,marginBottom:4}}>⚠ Special Instructions</div>
              <div style={{fontSize:13,color:C.text}}>{selected.notes}</div>
            </div>
          )}
          {selected.photos?.length>0&&(
            <div style={{marginBottom:16}}>
              <div style={{fontSize:11,color:C.muted,textTransform:"uppercase",letterSpacing:"0.5px",marginBottom:10}}>Cargo Photos</div>
              <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:8}}>
                {selected.photos.map((p,i)=>(
                  <div key={i} style={{borderRadius:10,overflow:"hidden",border:`1px solid ${C.border}`,aspectRatio:"4/3"}}>
                    <img src={p.url} alt={p.name} style={{width:"100%",height:"100%",objectFit:"cover"}}/>
                  </div>
                ))}
              </div>
            </div>
          )}
          <div style={{display:"flex",gap:10}}>
            <PrimaryBtn style={{flex:1,justifyContent:"center"}}>Book This Load</PrimaryBtn>
            <GhostBtn icon="download" style={{flex:1,justifyContent:"center"}}>Rate Confirmation</GhostBtn>
          </div>
        </Modal>
      )}

      {/* Add LTL Modal */}
      {showAdd&&(
        <Modal title="Post LTL Load" onClose={()=>setShowAdd(false)} width={600}>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
            <Fl label="Origin City" value={form.origin} onChange={v=>setForm({...form,origin:v})}/>
            <Fl label="Destination City" value={form.dest} onChange={v=>setForm({...form,dest:v})}/>
            <Fl label="Pickup Date" value={form.pickup} onChange={v=>setForm({...form,pickup:v})}/>
            <Fl label="Delivery Date" value={form.delivery} onChange={v=>setForm({...form,delivery:v})}/>
            <Fl label="Commodity" value={form.commodity} onChange={v=>setForm({...form,commodity:v})}/>
            <Fl label="Weight (lbs)" value={form.weight} onChange={v=>setForm({...form,weight:v})}/>
            <Fl label="Dimensions (L×W×H in)" value={form.dims} onChange={v=>setForm({...form,dims:v})} placeholder="48x40x60 in"/>
            <Fl label="Number of Pallets" value={form.pallets} onChange={v=>setForm({...form,pallets:v})} type="number"/>
            <Fl label="Freight Class" value={form.freight_class} onChange={v=>setForm({...form,freight_class:v})} options={["50","55","60","65","70","77.5","85","92.5","100","110","125","150","175","200","250","300","400","500"]}/>
            <Fl label="Rate ($)" value={form.rate} onChange={v=>setForm({...form,rate:v})} type="number"/>
            <Fl label="Shipper" value={form.shipper} onChange={v=>setForm({...form,shipper:v})}/>
            <Fl label="Status" value={form.status} onChange={v=>setForm({...form,status:v})} options={["Available","Booked"]}/>
          </div>
          <Fl label="Special Instructions / Notes" value={form.notes} onChange={v=>setForm({...form,notes:v})}/>

          {/* Photo upload */}
          <div style={{marginBottom:16}}>
            <div style={{fontSize:11,color:C.muted,textTransform:"uppercase",letterSpacing:"0.5px",marginBottom:8}}>Cargo Photos</div>
            <div onClick={()=>fileRef.current?.click()} style={{border:`2px dashed ${C.border}`,borderRadius:12,padding:"24px",textAlign:"center",cursor:"pointer",transition:"border-color 0.2s"}}
              onMouseEnter={e=>e.currentTarget.style.borderColor=C.accent}
              onMouseLeave={e=>e.currentTarget.style.borderColor=C.border}
            >
              <div style={{color:C.muted,marginBottom:6}}><Ic n="photo" s={28}/></div>
              <div style={{color:C.muted,fontSize:13}}>Click to upload cargo photos</div>
              <div style={{color:C.dim,fontSize:11,marginTop:3}}>JPG, PNG supported</div>
              <input ref={fileRef} type="file" accept="image/*" multiple onChange={handlePhoto} style={{display:"none"}}/>
            </div>
            {form.photos.length>0&&(
              <div style={{display:"flex",gap:8,marginTop:10,flexWrap:"wrap"}}>
                {form.photos.map((p,i)=>(
                  <div key={i} style={{position:"relative"}}>
                    <img src={p.url} alt={p.name} style={{width:64,height:64,objectFit:"cover",borderRadius:8,border:`1px solid ${C.border}`}}/>
                    <button onClick={()=>setForm(prev=>({...prev,photos:prev.photos.filter((_,j)=>j!==i)}))} style={{position:"absolute",top:-4,right:-4,width:18,height:18,borderRadius:"50%",background:C.red,border:"none",color:"#fff",fontSize:10,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center"}}>×</button>
                  </div>
                ))}
              </div>
            )}
          </div>
          <PrimaryBtn onClick={addLoad} style={{width:"100%",justifyContent:"center"}}>Post LTL Load</PrimaryBtn>
        </Modal>
      )}
    </div>
  );
};

/* ─── ROUTE MAP ──────────────────────────────────────────── */
const RoutesPage = () => {
  const [selectedLoad,setSelectedLoad]=useState(null);
  const allLoads=[...LOADS_FTL,...LOADS_LTL];

  const openMap=(load)=>{
    const origin=encodeURIComponent(load.origin);
    const dest=encodeURIComponent(load.dest);
    window.open(`https://www.google.com/maps/dir/${origin}/${dest}`,"_blank");
  };

  const embedUrl=(load)=>{
    const origin=encodeURIComponent(load.origin);
    const dest=encodeURIComponent(load.dest);
    return `https://www.google.com/maps/embed/v1/directions?key=AIzaSyD-9tSrke72PouQMnMX-a7eZSW0jkFMBWY&origin=${origin}&destination=${dest}&mode=driving`;
  };

  return (
    <div>
      <div style={{marginBottom:22}}>
        <h2 style={{color:C.text,fontSize:20,fontWeight:900,margin:"0 0 3px"}}>Route Map</h2>
        <p style={{color:C.muted,margin:0,fontSize:12}}>Visualize load routes · opens Google Maps</p>
      </div>
      <div style={{display:"grid",gridTemplateColumns:"340px 1fr",gap:16,minHeight:500}}>
        {/* Load list */}
        <div style={{display:"flex",flexDirection:"column",gap:8}}>
          {allLoads.map(l=>(
            <Card key={l.id} hover style={{padding:16,cursor:"pointer",borderColor:selectedLoad?.id===l.id?C.accent:C.border}} onClick={()=>setSelectedLoad(l)}>
              <div style={{display:"flex",justifyContent:"space-between",marginBottom:8}}>
                <div>
                  <span style={{color:l.type==="LTL"?C.teal:C.accent,fontSize:11,fontWeight:700}}>{l.id}</span>
                  <div style={{display:"flex",gap:6,marginTop:4}}><Badge label={l.type}/><Badge label={l.status}/></div>
                </div>
                <div style={{color:C.gold,fontSize:16,fontWeight:900}}>${l.rate.toLocaleString()}</div>
              </div>
              <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:6}}>
                <span style={{color:C.text,fontSize:13,fontWeight:600}}>{l.origin}</span>
                <span style={{color:C.accent}}><Ic n="arrow" s={13}/></span>
                <span style={{color:C.text,fontSize:13,fontWeight:600}}>{l.dest}</span>
              </div>
              <div style={{fontSize:11,color:C.muted}}>{l.commodity} · {l.weight} lbs</div>
              <div style={{display:"flex",gap:8,marginTop:10}}>
                <button onClick={e=>{e.stopPropagation();openMap(l);}} style={{flex:1,padding:"7px",background:`${C.accent}18`,border:`1px solid ${C.accent}33`,color:C.accent,borderRadius:7,cursor:"pointer",fontSize:11,fontWeight:700,fontFamily:"inherit",display:"flex",alignItems:"center",justifyContent:"center",gap:5}}>
                  <Ic n="map" s={12}/> Open in Maps
                </button>
              </div>
            </Card>
          ))}
        </div>
        {/* Map panel */}
        <Card style={{overflow:"hidden",minHeight:500,display:"flex",flexDirection:"column"}}>
          {selectedLoad?(
            <>
              <div style={{padding:"14px 18px",borderBottom:`1px solid ${C.border}`,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                <div>
                  <span style={{color:C.text,fontWeight:700}}>{selectedLoad.origin}</span>
                  <span style={{color:C.accent,margin:"0 8px"}}> → </span>
                  <span style={{color:C.text,fontWeight:700}}>{selectedLoad.dest}</span>
                </div>
                <button onClick={()=>openMap(selectedLoad)} style={{padding:"6px 14px",background:`linear-gradient(135deg,${C.accent},#007aaa)`,border:"none",color:"#000",borderRadius:7,cursor:"pointer",fontSize:12,fontWeight:700,fontFamily:"inherit",display:"flex",alignItems:"center",gap:6}}>
                  <Ic n="map" s={13}/> Full Screen
                </button>
              </div>
              <div style={{flex:1,position:"relative",background:C.dim}}>
                <iframe
                  title={`Route ${selectedLoad.id}`}
                  width="100%" height="100%"
                  style={{border:"none",display:"block"}}
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  src={embedUrl(selectedLoad)}
                  onError={()=>{}}
                />
                {/* Fallback overlay with link */}
                <div style={{position:"absolute",inset:0,background:`${C.card}ee`,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",gap:16}}>
                  <div style={{color:C.accent}}><Ic n="map" s={48}/></div>
                  <div style={{textAlign:"center"}}>
                    <div style={{color:C.text,fontWeight:700,fontSize:16,marginBottom:6}}>{selectedLoad.origin} → {selectedLoad.dest}</div>
                    <div style={{color:C.muted,fontSize:13,marginBottom:16}}>{selectedLoad.commodity} · {selectedLoad.type} · ${selectedLoad.rate.toLocaleString()}</div>
                    <button onClick={()=>openMap(selectedLoad)} style={{padding:"12px 28px",background:`linear-gradient(135deg,${C.accent},#007aaa)`,border:"none",color:"#000",borderRadius:10,cursor:"pointer",fontSize:14,fontWeight:700,fontFamily:"inherit",display:"flex",alignItems:"center",gap:8,margin:"0 auto"}}>
                      <Ic n="map" s={16}/> Open Route in Google Maps
                    </button>
                  </div>
                  <div style={{fontSize:11,color:C.muted,marginTop:8,maxWidth:280,textAlign:"center"}}>
                    Click to open the full interactive route map in Google Maps with turn-by-turn directions
                  </div>
                </div>
              </div>
            </>
          ):(
            <div style={{flex:1,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",gap:12}}>
              <div style={{color:C.dim}}><Ic n="map" s={56}/></div>
              <div style={{color:C.muted,fontSize:14}}>Select a load to view route</div>
            </div>
          )}
        </Card>
      </div>
    </div>
  );
};

/* ─── CALLS + MESSAGING PAGE ─────────────────────────────── */
const CONTACTS_LIST = [
  {id:1,name:"Jake Morrison",company:"FastLane Trucking LLC",type:"Carrier",phone:"+1(512)555-0182",avatar:"JM",color:C.accent,online:true},
  {id:2,name:"Rebecca Lane",company:"GlobalTech Imports",type:"Shipper",phone:"+1(312)555-0177",avatar:"RL",color:C.gold,online:false},
  {id:3,name:"Tom Bradley",company:"Apex Haulers",type:"Carrier",phone:"+1(602)555-0154",avatar:"TB",color:C.green,online:true},
  {id:4,name:"Anna White",company:"FreshFarm Co-op",type:"Shipper",phone:"+1(559)555-0188",avatar:"AW",color:C.purple,online:false},
  {id:5,name:"Maria Gonzalez",company:"Steel Road Carriers",type:"Carrier",phone:"+1(214)555-0143",avatar:"MG",color:C.teal,online:true},
  {id:6,name:"Derek Kim",company:"Midwest Auto Parts",type:"Shipper",phone:"+1(317)555-0144",avatar:"DK",color:C.pink,online:false},
];

const INIT_MSGS = {
  1:[
    {id:1,from:"them",text:"Hey, do you have any loads going TX to CA next week?",time:"9:14 AM",date:"Apr 24"},
    {id:2,from:"me",text:"Yes! We have LB-10041 — 38k lbs dry van, pickup Apr 25 in Chicago, delivery Dallas. Rate $2,450.",time:"9:16 AM",date:"Apr 24"},
    {id:3,from:"them",text:"That works. Can you send the rate con?",time:"9:18 AM",date:"Apr 24"},
    {id:4,from:"me",text:"Sending it now. Check your email at j.morrison@fastlane.com",time:"9:19 AM",date:"Apr 24"},
    {id:5,from:"them",text:"Got it. We'll confirm by EOD. Thanks!",time:"9:22 AM",date:"Apr 24"},
  ],
  2:[
    {id:1,from:"them",text:"Hi, we need capacity for Q2. Can you handle 25 loads/month TX to CA?",time:"10:02 AM",date:"Apr 23"},
    {id:2,from:"me",text:"Absolutely! We have dedicated carriers on that lane. Let me pull together a rate sheet for you.",time:"10:15 AM",date:"Apr 23"},
    {id:3,from:"them",text:"Great. What's your standard transit time?",time:"10:18 AM",date:"Apr 23"},
    {id:4,from:"me",text:"2-3 days door to door. We also provide real-time tracking on every load.",time:"10:20 AM",date:"Apr 23"},
  ],
  3:[
    {id:1,from:"me",text:"Tom, confirming load LTL-2002 — pickup Denver Apr 27. All good?",time:"1:00 PM",date:"Apr 24"},
    {id:2,from:"them",text:"Confirmed. Driver is Mike, truck #A442. He'll be there at 8am.",time:"1:04 PM",date:"Apr 24"},
    {id:3,from:"me",text:"Perfect. Please make sure to get the signed BOL at pickup.",time:"1:05 PM",date:"Apr 24"},
    {id:4,from:"them",text:"Always do 👍",time:"1:06 PM",date:"Apr 24"},
  ],
  4:[],
  5:[],
  6:[],
};

const CallsPage = () => {
  const [tab,setTab]=useState("messages"); // messages | calls
  const [activeContact,setActiveContact]=useState(CONTACTS_LIST[0]);
  const [messages,setMessages]=useState(INIT_MSGS);
  const [input,setInput]=useState("");
  const [search,setSearch]=useState("");
  const [playing,setPlaying]=useState(null);
  const [pos,setPos]=useState(0);
  const [dialer,setDialer]=useState(false);
  const [dialNum,setDialNum]=useState("");
  const [dialName,setDialName]=useState("");
  const [callPhase,setCallPhase]=useState("idle");
  const [callDur,setCallDur]=useState(0);
  const timerRef=useRef();
  const bottomRef=useRef();
  const inputRef=useRef();

  useEffect(()=>{
    if(callPhase==="active"){timerRef.current=setInterval(()=>setCallDur(d=>d+1),1000);}
    else clearInterval(timerRef.current);
    return()=>clearInterval(timerRef.current);
  },[callPhase]);

  useEffect(()=>{bottomRef.current?.scrollIntoView({behavior:"smooth"});},[messages,activeContact]);

  const sendMsg=()=>{
    if(!input.trim())return;
    const now=new Date();
    const time=now.toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"});
    setMessages(prev=>({...prev,[activeContact.id]:[...(prev[activeContact.id]||[]),{id:Date.now(),from:"me",text:input.trim(),time,date:"Today"}]}));
    setInput("");
    inputRef.current?.focus();
    // Simulate reply after 1.5s
    const contact=activeContact;
    const replies=["Got it, thanks!","Sure, will do.","Let me check and get back to you.","Sounds good!","Can you send more details?","On it 👍"];
    setTimeout(()=>{
      setMessages(prev=>({...prev,[contact.id]:[...(prev[contact.id]||[]),{id:Date.now()+1,from:"them",text:replies[Math.floor(Math.random()*replies.length)],time:new Date().toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"}),date:"Today"}]}));
    },1500);
  };

  const startCall=()=>{setCallPhase("ringing");setTimeout(()=>setCallPhase("active"),2200);};
  const endCall=()=>{setCallPhase("ended");setCallDur(0);};
  const fmt=s=>`${Math.floor(s/60)}:${String(s%60).padStart(2,"0")}`;
  const bars=Array.from({length:50},(_,i)=>Math.max(0.1,Math.abs(Math.sin(i*0.5)*0.4+Math.sin(i*1.3)*0.3+Math.random()*0.3)));
  const sc={Positive:C.green,Neutral:C.muted,Negative:C.red};

  const filteredContacts=CONTACTS_LIST.filter(c=>
    c.name.toLowerCase().includes(search.toLowerCase())||
    c.company.toLowerCase().includes(search.toLowerCase())
  );

  const getLastMsg=(cid)=>{
    const msgs=messages[cid]||[];
    return msgs[msgs.length-1];
  };

  const getUnread=(cid)=>Math.floor(Math.random()*3); // mock unread

  return (
    <div style={{display:"flex",flexDirection:"column",height:"calc(100vh - 120px)"}}>
      {/* Header */}
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:16,flexShrink:0}}>
        <div>
          <h2 style={{color:C.text,fontSize:20,fontWeight:900,margin:"0 0 3px"}}>Communication Center</h2>
          <p style={{color:C.muted,margin:0,fontSize:12}}>Messages · Calls · Recordings</p>
        </div>
        <div style={{display:"flex",gap:10}}>
          <GhostBtn icon="calls" color={C.green} onClick={()=>{setDialer(true);setDialNum("");setDialName("");}}>New Call</GhostBtn>
        </div>
      </div>

      {/* Tab switcher */}
      <div style={{display:"flex",gap:0,marginBottom:16,background:C.surface,borderRadius:10,padding:4,width:"fit-content",flexShrink:0}}>
        {[{k:"messages",label:"💬 Messages"},{k:"calls",label:"📞 Call Recordings"}].map(t=>(
          <button key={t.k} onClick={()=>setTab(t.k)} style={{padding:"8px 20px",borderRadius:8,border:"none",background:tab===t.k?C.card:"transparent",color:tab===t.k?C.text:C.muted,fontSize:13,cursor:"pointer",fontFamily:"inherit",fontWeight:tab===t.k?700:400,transition:"all 0.15s"}}>{t.label}</button>
        ))}
      </div>

      {tab==="messages"&&(
        <div style={{display:"grid",gridTemplateColumns:"280px 1fr",gap:0,flex:1,minHeight:0,border:`1px solid ${C.border}`,borderRadius:14,overflow:"hidden"}}>

          {/* Contact sidebar */}
          <div style={{background:C.surface,borderRight:`1px solid ${C.border}`,display:"flex",flexDirection:"column"}}>
            <div style={{padding:"12px 14px",borderBottom:`1px solid ${C.border}`}}>
              <div style={{position:"relative"}}>
                <span style={{position:"absolute",left:10,top:"50%",transform:"translateY(-50%)",color:C.muted}}><Ic n="search" s={13}/></span>
                <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search contacts..." style={{...inp,paddingLeft:32,fontSize:12}}/>
              </div>
            </div>
            <div style={{overflowY:"auto",flex:1}}>
              {filteredContacts.map(c=>{
                const last=getLastMsg(c.id);
                const isActive=activeContact?.id===c.id;
                return(
                  <div key={c.id} onClick={()=>setActiveContact(c)} style={{padding:"12px 14px",borderBottom:`1px solid ${C.border}`,background:isActive?C.accentDim:"transparent",cursor:"pointer",transition:"background 0.15s",borderLeft:isActive?`3px solid ${C.accent}`:"3px solid transparent"}}
                    onMouseEnter={e=>{if(!isActive)e.currentTarget.style.background="rgba(255,255,255,0.03)";}}
                    onMouseLeave={e=>{if(!isActive)e.currentTarget.style.background="transparent";}}
                  >
                    <div style={{display:"flex",alignItems:"center",gap:10}}>
                      <div style={{position:"relative",flexShrink:0}}>
                        <div style={{width:38,height:38,borderRadius:11,background:`${c.color}22`,color:c.color,display:"flex",alignItems:"center",justifyContent:"center",fontWeight:800,fontSize:13}}>{c.avatar}</div>
                        {c.online&&<div style={{position:"absolute",bottom:0,right:0,width:10,height:10,borderRadius:"50%",background:C.green,border:`2px solid ${C.surface}`}}/>}
                      </div>
                      <div style={{flex:1,minWidth:0}}>
                        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                          <span style={{color:C.text,fontSize:13,fontWeight:700,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{c.name}</span>
                          {last&&<span style={{color:C.muted,fontSize:10,flexShrink:0,marginLeft:4}}>{last.time}</span>}
                        </div>
                        <div style={{color:C.muted,fontSize:11,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap",marginTop:1}}>
                          {last?`${last.from==="me"?"You: ":""}${last.text}`:<span style={{color:C.dim}}>No messages yet</span>}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Chat area */}
          <div style={{display:"flex",flexDirection:"column",background:C.card}}>
            {/* Chat header */}
            <div style={{padding:"12px 18px",borderBottom:`1px solid ${C.border}`,display:"flex",alignItems:"center",gap:12,flexShrink:0}}>
              <div style={{position:"relative"}}>
                <div style={{width:40,height:40,borderRadius:11,background:`${activeContact.color}22`,color:activeContact.color,display:"flex",alignItems:"center",justifyContent:"center",fontWeight:800,fontSize:14}}>{activeContact.avatar}</div>
                {activeContact.online&&<div style={{position:"absolute",bottom:0,right:0,width:10,height:10,borderRadius:"50%",background:C.green,border:`2px solid ${C.card}`}}/>}
              </div>
              <div style={{flex:1}}>
                <div style={{color:C.text,fontWeight:700,fontSize:14}}>{activeContact.name}</div>
                <div style={{color:C.muted,fontSize:11}}>{activeContact.company} · {activeContact.online?"🟢 Online":"⚫ Offline"}</div>
              </div>
              <div style={{display:"flex",gap:8}}>
                <button onClick={()=>{setDialer(true);setDialNum(activeContact.phone);setDialName(activeContact.name);}} style={{width:34,height:34,borderRadius:9,background:`${C.green}18`,border:`1px solid ${C.green}33`,color:C.green,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center"}} title="Call">
                  <Ic n="calls" s={15}/>
                </button>
                <button style={{width:34,height:34,borderRadius:9,background:"rgba(255,255,255,0.04)",border:`1px solid ${C.border}`,color:C.muted,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center"}} title="Contact Info">
                  <Ic n="people" s={15}/>
                </button>
              </div>
            </div>

            {/* Messages */}
            <div style={{flex:1,overflowY:"auto",padding:"16px 18px",display:"flex",flexDirection:"column",gap:10}}>
              {(messages[activeContact.id]||[]).length===0&&(
                <div style={{flex:1,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",gap:8,opacity:0.4}}>
                  <Ic n="calls" s={40}/>
                  <div style={{color:C.muted,fontSize:13}}>No messages yet. Say hello!</div>
                </div>
              )}
              {(messages[activeContact.id]||[]).map((msg,i)=>{
                const isMe=msg.from==="me";
                return(
                  <div key={msg.id} style={{display:"flex",flexDirection:isMe?"row-reverse":"row",gap:8,alignItems:"flex-end"}}>
                    {!isMe&&(
                      <div style={{width:28,height:28,borderRadius:8,background:`${activeContact.color}22`,color:activeContact.color,display:"flex",alignItems:"center",justifyContent:"center",fontWeight:800,fontSize:11,flexShrink:0}}>{activeContact.avatar}</div>
                    )}
                    <div style={{maxWidth:"68%"}}>
                      <div style={{padding:"10px 14px",borderRadius:isMe?"14px 14px 4px 14px":"14px 14px 14px 4px",background:isMe?`linear-gradient(135deg,${C.accent},#007aaa)`:"rgba(255,255,255,0.07)",color:isMe?"#000":C.text,fontSize:13,lineHeight:1.5}}>
                        {msg.text}
                      </div>
                      <div style={{fontSize:10,color:C.muted,marginTop:3,textAlign:isMe?"right":"left"}}>{msg.time}</div>
                    </div>
                  </div>
                );
              })}
              <div ref={bottomRef}/>
            </div>

            {/* Quick replies */}
            <div style={{padding:"8px 18px 4px",display:"flex",gap:6,flexWrap:"wrap",flexShrink:0}}>
              {["Rate confirmed ✓","Load is booked","Sending rate con now","Call me when available","Driver confirmed","Check your email"].map(q=>(
                <button key={q} onClick={()=>setInput(q)} style={{padding:"4px 10px",background:"rgba(255,255,255,0.05)",border:`1px solid ${C.border}`,borderRadius:20,color:C.muted,fontSize:11,cursor:"pointer",fontFamily:"inherit",transition:"all 0.15s"}}
                  onMouseEnter={e=>{e.currentTarget.style.borderColor=C.accent;e.currentTarget.style.color=C.accent;}}
                  onMouseLeave={e=>{e.currentTarget.style.borderColor=C.border;e.currentTarget.style.color=C.muted;}}
                >{q}</button>
              ))}
            </div>

            {/* Input */}
            <div style={{padding:"10px 18px 14px",borderTop:`1px solid ${C.border}`,display:"flex",gap:10,flexShrink:0}}>
              <input ref={inputRef} value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>e.key==="Enter"&&sendMsg()} placeholder={`Message ${activeContact.name}...`}
                style={{...inp,flex:1,borderRadius:10}}/>
              <button onClick={sendMsg} disabled={!input.trim()} style={{width:40,height:40,borderRadius:10,background:input.trim()?`linear-gradient(135deg,${C.accent},#007aaa)`:"rgba(255,255,255,0.05)",border:"none",color:input.trim()?"#000":C.muted,cursor:input.trim()?"pointer":"default",display:"flex",alignItems:"center",justifyContent:"center",transition:"all 0.2s"}}>
                <svg width={18} height={18} viewBox="0 0 24 24" fill="currentColor"><path d="M2 21l21-9L2 3v7l15 2-15 2v7z"/></svg>
              </button>
            </div>
          </div>
        </div>
      )}

      {tab==="calls"&&(
        <div style={{display:"flex",flexDirection:"column",gap:10,flex:1,overflowY:"auto"}}>
          {/* Stats row */}
          <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:12,flexShrink:0}}>
            {[
              {label:"Total Calls",val:CALL_LOGS.length,color:C.accent},
              {label:"Positive",val:CALL_LOGS.filter(c=>c.sentiment==="Positive").length,color:C.green},
              {label:"Neutral",val:CALL_LOGS.filter(c=>c.sentiment==="Neutral").length,color:C.muted},
              {label:"Negative",val:CALL_LOGS.filter(c=>c.sentiment==="Negative").length,color:C.red},
            ].map((s,i)=>(
              <Card key={i} style={{padding:"14px 18px"}}>
                <div style={{fontSize:24,fontWeight:900,color:s.color}}>{s.val}</div>
                <div style={{fontSize:11,color:C.muted,marginTop:2}}>{s.label}</div>
              </Card>
            ))}
          </div>

          {CALL_LOGS.map(call=>{
            const isPlaying=playing?.id===call.id;
            return(
              <Card key={call.id} style={{padding:"16px 20px"}}>
                <div style={{display:"flex",alignItems:"center",gap:14}}>
                  <div style={{width:42,height:42,borderRadius:11,background:call.type==="Carrier"?C.accentDim:"rgba(240,180,41,0.12)",color:call.type==="Carrier"?C.accent:C.gold,display:"flex",alignItems:"center",justifyContent:"center",fontWeight:900,fontSize:14,flexShrink:0}}>
                    {call.contact.split(" ").map(n=>n[0]).join("")}
                  </div>
                  <div style={{flex:1}}>
                    <div style={{display:"flex",gap:8,alignItems:"center",marginBottom:3}}>
                      <span style={{color:C.text,fontWeight:700,fontSize:14}}>{call.contact}</span>
                      <Badge label={call.type}/><Badge label={call.sentiment}/>
                    </div>
                    <div style={{color:C.muted,fontSize:12}}>{call.company} · {call.topic}</div>
                  </div>
                  <div style={{display:"flex",alignItems:"flex-end",gap:1.5,height:26,width:56}}>
                    {bars.slice(0,20).map((h,i)=>(
                      <div key={i} style={{flex:1,height:`${h*100}%`,background:`${sc[call.sentiment]}55`,borderRadius:1}}/>
                    ))}
                  </div>
                  <div style={{textAlign:"right",minWidth:80}}>
                    <div style={{color:C.muted,fontSize:11}}>{call.date} {call.time}</div>
                    <div style={{color:C.accent,fontSize:13,fontWeight:700,marginTop:2}}>{call.duration}</div>
                    <div style={{color:C.muted,fontSize:11}}>by {call.agent}</div>
                  </div>
                  <button onClick={()=>{setPlaying(isPlaying?null:call);setPos(0);}} style={{width:38,height:38,borderRadius:"50%",background:`linear-gradient(135deg,${C.accent},#007aaa)`,border:"none",color:"#000",cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",boxShadow:`0 0 16px ${C.accent}33`,flexShrink:0}}>
                    <Ic n={isPlaying?"pause":"play"} s={18}/>
                  </button>
                  <button onClick={()=>{
                    const c=CONTACTS_LIST.find(ct=>ct.name===call.contact)||{name:call.contact,id:0};
                    setActiveContact(c);setTab("messages");
                  }} style={{width:38,height:38,borderRadius:"50%",background:"rgba(255,255,255,0.05)",border:`1px solid ${C.border}`,color:C.muted,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}} title="Open chat">
                    <svg width={16} height={16} viewBox="0 0 24 24" fill="currentColor"><path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2z"/></svg>
                  </button>
                </div>
                <div style={{marginTop:10,paddingTop:10,borderTop:`1px solid ${C.border}`,display:"flex",alignItems:"center",gap:8}}>
                  <span style={{fontSize:10,color:C.muted,textTransform:"uppercase",letterSpacing:"0.5px"}}>Outcome:</span>
                  <span style={{fontSize:12,color:sc[call.sentiment],fontWeight:600}}>{call.outcome}</span>
                </div>
                {isPlaying&&(
                  <div style={{marginTop:14,padding:16,background:"rgba(0,0,0,0.3)",borderRadius:12}}>
                    <div style={{display:"flex",alignItems:"flex-end",gap:2,height:48,marginBottom:12,cursor:"pointer"}} onClick={e=>{const r=e.currentTarget.getBoundingClientRect();setPos(Math.floor(((e.clientX-r.left)/r.width)*call.duration_sec));}}>
                      {bars.map((h,i)=>(
                        <div key={i} style={{flex:1,height:`${h*100}%`,background:(i/bars.length)*100<(pos/call.duration_sec)*100?C.accent:C.dim,borderRadius:1,transition:"background 0.1s"}}/>
                      ))}
                    </div>
                    <div style={{display:"flex",alignItems:"center",gap:12}}>
                      <span style={{fontSize:11,color:C.muted,minWidth:30}}>{fmt(pos)}</span>
                      <div style={{flex:1,height:3,background:C.dim,borderRadius:2,cursor:"pointer",position:"relative"}} onClick={e=>{const r=e.currentTarget.getBoundingClientRect();setPos(Math.floor(((e.clientX-r.left)/r.width)*call.duration_sec));}}>
                        <div style={{width:`${(pos/call.duration_sec)*100}%`,height:"100%",background:C.accent,borderRadius:2}}/>
                      </div>
                      <span style={{fontSize:11,color:C.muted,minWidth:30}}>{call.duration}</span>
                    </div>
                    <div style={{marginTop:12,fontSize:11,color:C.muted,textTransform:"uppercase",letterSpacing:"0.5px",marginBottom:8}}>AI Transcript</div>
                    {[{spk:"Agent",t:`Hi ${call.contact.split(" ")[0]}, calling about ${call.topic}.`},{spk:call.contact.split(" ")[0],t:"Sure, what's up?"},{spk:"Agent",t:`Result: ${call.outcome}`}].map((line,i)=>(
                      <div key={i} style={{marginBottom:6,opacity:i<2||(pos/call.duration_sec)>0.5?1:0.3,transition:"opacity 0.3s"}}>
                        <span style={{color:line.spk==="Agent"?C.accent:C.gold,fontSize:11,fontWeight:700}}>{line.spk}: </span>
                        <span style={{color:C.text,fontSize:12}}>{line.t}</span>
                      </div>
                    ))}
                  </div>
                )}
              </Card>
            );
          })}
        </div>
      )}

      {/* Dialer modal */}
      {dialer&&(
        <Modal title="Outbound Dialer" onClose={()=>{setDialer(false);setCallPhase("idle");setCallDur(0);}} width={360}>
          <div style={{textAlign:"center",padding:"10px 0 20px"}}>
            <div style={{width:72,height:72,borderRadius:"50%",background:`${callPhase==="active"?C.green:callPhase==="ringing"?C.orange:C.muted}22`,border:`2px solid ${callPhase==="active"?C.green:callPhase==="ringing"?C.orange:C.muted}44`,margin:"0 auto 14px",display:"flex",alignItems:"center",justifyContent:"center",fontSize:22,fontWeight:900,color:callPhase==="active"?C.green:callPhase==="ringing"?C.orange:C.muted}}>
              {dialName?dialName.split(" ").map(n=>n[0]).join(""):<Ic n="calls" s={28}/>}
            </div>
            {callPhase==="active"&&<div style={{fontSize:24,fontWeight:900,color:C.green}}>{fmt(callDur)}</div>}
            {callPhase==="ringing"&&<div style={{color:C.orange,fontSize:14}}>Ringing...</div>}
            {callPhase==="ended"&&<div style={{color:C.red,fontSize:14}}>Call Ended</div>}
            {callPhase==="idle"&&dialName&&<div style={{color:C.text,fontSize:14,fontWeight:700,marginTop:4}}>{dialName}</div>}
          </div>
          {callPhase==="idle"&&(
            <>
              <Fl label="Contact Name" value={dialName} onChange={setDialName}/>
              <Fl label="Phone Number" value={dialNum} onChange={setDialNum}/>
              <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:8,margin:"10px 0 16px"}}>
                {["1","2","3","4","5","6","7","8","9","*","0","#"].map(d=>(
                  <button key={d} onClick={()=>setDialNum(n=>n+d)} style={{padding:"11px",background:"rgba(255,255,255,0.05)",border:`1px solid ${C.border}`,borderRadius:8,color:C.text,fontSize:16,cursor:"pointer",fontFamily:"inherit",fontWeight:600}}>{d}</button>
                ))}
              </div>
            </>
          )}
          {callPhase==="active"&&(
            <div style={{display:"flex",justifyContent:"center",gap:14,marginBottom:16}}>
              {[{label:"Mute",icon:"mic"},{label:"Hold",icon:"pause"},{label:"Record",icon:"bell"}].map(b=>(
                <div key={b.label} style={{textAlign:"center"}}>
                  <button style={{width:44,height:44,borderRadius:"50%",background:`${C.muted}22`,border:`1px solid ${C.muted}33`,color:C.muted,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",margin:"0 auto 4px"}}><Ic n={b.icon} s={18}/></button>
                  <div style={{fontSize:10,color:C.muted}}>{b.label}</div>
                </div>
              ))}
            </div>
          )}
          <div style={{display:"flex",justifyContent:"center"}}>
            {callPhase==="idle"&&<button onClick={startCall} style={{width:56,height:56,borderRadius:"50%",background:C.green,border:"none",color:"#000",cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",boxShadow:`0 0 24px ${C.green}55`}}><Ic n="calls" s={24}/></button>}
            {(callPhase==="ringing"||callPhase==="active")&&<button onClick={endCall} style={{width:56,height:56,borderRadius:"50%",background:C.red,border:"none",color:"#fff",cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",boxShadow:`0 0 24px ${C.red}55`,transform:"rotate(135deg)"}}><Ic n="calls" s={24}/></button>}
            {callPhase==="ended"&&<GhostBtn onClick={()=>setCallPhase("idle")}>New Call</GhostBtn>}
          </div>
        </Modal>
      )}
    </div>
  );
};

/* ─── APP ROOT ───────────────────────────────────────────── */
export default function App() {
  const [page,setPage]=useState("dashboard");

  const nav=[
    {id:"dashboard",label:"Dashboard",icon:"dashboard"},
    {id:"loads",label:"Load Board (FTL)",icon:"truck"},
    {id:"ltl",label:"LTL Board",icon:"ltl",badge:LOADS_LTL.filter(l=>l.status==="Available").length},
    {id:"routes",label:"Route Maps",icon:"map"},
    {id:"carriers",label:"Carrier Payments",icon:"card"},
    {id:"funnel",label:"Sales Funnel",icon:"funnel"},
    {id:"calls",label:"Call Center",icon:"calls",badge:CALL_LOGS.length},
    {id:"accounting",label:"Accounting",icon:"accounting"},
    {id:"employees",label:"Team",icon:"people"},
    {id:"verify",label:"Verify Counterparty",icon:"shield",badge:"!"},
    {id:"notifications",label:"Notifications",icon:"bell",badge:3},
    {id:"reports",label:"Reports & Export",icon:"analytics"},
    {id:"calendar",label:"Calendar",icon:"calendar"},
    {id:"tracking",label:"Load Tracking",icon:"tracking"},
    {id:"margin",label:"Margin Calculator",icon:"calculator"},
    {id:"agents",label:"AI Sales Agents",icon:"robot",badge:"AI"},
  ];

  return (
    <div style={{display:"flex",minHeight:"100vh",background:C.bg,fontFamily:"'Courier New','Lucida Console',monospace",color:C.text}}>
      {/* Sidebar */}
      <div style={{width:220,background:C.surface,borderRight:`1px solid ${C.border}`,display:"flex",flexDirection:"column",flexShrink:0}}>
        <div style={{padding:"20px 18px 18px",borderBottom:`1px solid ${C.border}`}}>
          <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:2}}>
            <div style={{width:28,height:28,background:`linear-gradient(135deg,${C.accent},#0077aa)`,borderRadius:7,display:"flex",alignItems:"center",justifyContent:"center"}}><Ic n="truck" s={14}/></div>
            <span style={{fontSize:16,fontWeight:900,color:C.text,letterSpacing:"-0.5px"}}>FREIGHT<span style={{color:C.accent}}>CRM</span></span>
          </div>
          <div style={{fontSize:9,color:C.muted,textTransform:"uppercase",letterSpacing:"2px",paddingLeft:36}}>USA Logistics v3</div>
        </div>
        <nav style={{padding:"12px 10px",flex:1,overflowY:"auto"}}>
          {nav.map(item=>(
            <button key={item.id} onClick={()=>setPage(item.id)} style={{width:"100%",display:"flex",alignItems:"center",gap:9,padding:"9px 11px",borderRadius:8,marginBottom:2,border:"none",background:page===item.id?C.accentDim:"transparent",color:page===item.id?C.accent:C.muted,cursor:"pointer",fontSize:12,textAlign:"left",fontFamily:"inherit",fontWeight:page===item.id?700:400,transition:"all 0.15s",borderLeft:page===item.id?`3px solid ${C.accent}`:"3px solid transparent"}}>
              <Ic n={item.icon} s={14}/>
              <span style={{flex:1}}>{item.label}</span>
              {item.badge>0&&<span style={{background:C.accent,color:"#000",fontSize:9,fontWeight:800,minWidth:16,height:16,borderRadius:8,display:"flex",alignItems:"center",justifyContent:"center",padding:"0 3px"}}>{item.badge}</span>}
            </button>
          ))}
        </nav>
        <div style={{padding:"14px 16px",borderTop:`1px solid ${C.border}`}}>
          <div style={{display:"flex",alignItems:"center",gap:9}}>
            <div style={{width:32,height:32,borderRadius:9,background:`linear-gradient(135deg,${C.accent},#005577)`,display:"flex",alignItems:"center",justifyContent:"center",color:"#000",fontWeight:900,fontSize:12}}>AJ</div>
            <div>
              <div style={{color:C.text,fontSize:12,fontWeight:700}}>Alex Johnson</div>
              <div style={{color:C.muted,fontSize:10}}>Senior Broker</div>
            </div>
          </div>
        </div>
      </div>

      {/* Main */}
      <div style={{flex:1,display:"flex",flexDirection:"column",overflow:"hidden"}}>
        <div style={{padding:"13px 26px",borderBottom:`1px solid ${C.border}`,display:"flex",alignItems:"center",justifyContent:"space-between",background:C.surface}}>
          <div style={{color:C.muted,fontSize:11,textTransform:"uppercase",letterSpacing:"1px"}}>{nav.find(n=>n.id===page)?.label}</div>
          <div style={{display:"flex",alignItems:"center",gap:12}}>
            <div style={{width:7,height:7,borderRadius:"50%",background:C.green,boxShadow:`0 0 8px ${C.green}`}}/>
            <span style={{fontSize:11,color:C.muted}}>Live · US-East</span>
            <button style={{background:"rgba(255,255,255,0.05)",border:`1px solid ${C.border}`,color:C.muted,width:32,height:32,borderRadius:8,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center"}}><Ic n="bell" s={14}/></button>
          </div>
        </div>
        <div style={{flex:1,padding:"22px 26px",overflowY:"auto"}}>
          {page==="dashboard"&&<Dashboard/>}
          {page==="loads"&&<FTLPage/>}
          {page==="ltl"&&<LTLPage/>}
          {page==="routes"&&<RoutesPage/>}
          {page==="carriers"&&<CarrierPayments/>}
          {page==="funnel"&&<FunnelPage/>}
          {page==="calls"&&<CallsPage/>}
          {page==="accounting"&&<AccountingPage/>}
          {page==="employees"&&<EmployeesPage/>}
          {page==="verify"&&<VerifyPage/>}
          {page==="notifications"&&<NotificationsPage/>}
          {page==="reports"&&<ReportsPage/>}
          {page==="calendar"&&<CalendarPage/>}
          {page==="tracking"&&<TrackingPage/>}
          {page==="margin"&&<MarginCalcPage/>}
          {page==="agents"&&<AIAgentsPage/>}
        </div>
      </div>
    </div>
  );
}

/* ─── FTL BOARD (inline) ─────────────────────────────────── */
function FTLPage(){
  const [loads,setLoads]=useState(LOADS_FTL);
  const [showAdd,setShowAdd]=useState(false);
  const [filter,setFilter]=useState("All");
  const [form,setForm]=useState({origin:"",dest:"",pickup:"",delivery:"",commodity:"",weight:"",rate:"",equipment:"Dry Van",status:"Available",shipper:"",carrier:"",margin:""});
  const filtered=loads.filter(l=>filter==="All"||l.status===filter);
  const sc={"In Transit":C.accent,Booked:C.purple,Available:C.green,Delivered:C.muted};
  const add=()=>{if(!form.origin)return;setLoads([...loads,{...form,id:`LB-${10060+loads.length}`,type:"FTL",rate:parseFloat(form.rate)||0,margin:parseFloat(form.margin)||0,miles:Math.floor(Math.random()*1200+300)}]);setShowAdd(false);setForm({origin:"",dest:"",pickup:"",delivery:"",commodity:"",weight:"",rate:"",equipment:"Dry Van",status:"Available",shipper:"",carrier:"",margin:""});};
  return(
    <div>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:22}}>
        <div><h2 style={{color:C.text,fontSize:20,fontWeight:900,margin:"0 0 3px"}}>FTL Load Board</h2><p style={{color:C.muted,margin:0,fontSize:12}}>{loads.length} loads</p></div>
        <PrimaryBtn icon="plus" onClick={()=>setShowAdd(true)}>Post Load</PrimaryBtn>
      </div>
      <div style={{display:"flex",gap:8,marginBottom:14}}>
        {["All","Available","Booked","In Transit","Delivered"].map(f=>(
          <button key={f} onClick={()=>setFilter(f)} style={{padding:"7px 14px",borderRadius:8,border:"1px solid",borderColor:filter===f?C.accent:C.border,background:filter===f?C.accentDim:"transparent",color:filter===f?C.accent:C.muted,fontSize:12,cursor:"pointer",fontFamily:"inherit",fontWeight:filter===f?700:400}}>{f}</button>
        ))}
      </div>
      <div style={{display:"flex",flexDirection:"column",gap:10}}>
        {filtered.map(l=>(
          <Card key={l.id} style={{padding:"16px 20px"}}>
            <div style={{display:"flex",alignItems:"center",gap:14,flexWrap:"wrap"}}>
              <div style={{minWidth:90}}><div style={{color:C.accent,fontSize:12,fontWeight:700}}>{l.id}</div><Badge label={l.status} color={sc[l.status]}/></div>
              <div style={{flex:2,minWidth:160}}>
                <div style={{display:"flex",alignItems:"center",gap:8}}><span style={{color:C.text,fontSize:13,fontWeight:600}}>{l.origin}</span><span style={{color:C.accent}}><Ic n="arrow" s={13}/></span><span style={{color:C.text,fontSize:13,fontWeight:600}}>{l.dest}</span></div>
                <div style={{color:C.muted,fontSize:11,marginTop:2}}>{l.miles} mi · {l.equipment} · {l.commodity}</div>
              </div>
              <div style={{minWidth:80}}><div style={{fontSize:10,color:C.muted,textTransform:"uppercase",marginBottom:2}}>Pickup</div><div style={{fontSize:12,color:C.text}}>{l.pickup}</div></div>
              <div style={{minWidth:80}}><div style={{fontSize:10,color:C.muted,textTransform:"uppercase",marginBottom:2}}>Weight</div><div style={{fontSize:12,color:C.text}}>{l.weight} lbs</div></div>
              <div style={{minWidth:100}}><div style={{fontSize:10,color:C.muted,textTransform:"uppercase",marginBottom:2}}>Carrier</div><div style={{fontSize:12,color:l.carrier?C.text:C.red}}>{l.carrier||"Unassigned"}</div></div>
              <div style={{minWidth:80}}><div style={{fontSize:10,color:C.muted,textTransform:"uppercase",marginBottom:2}}>Broker</div><div style={{fontSize:11,color:C.muted}}>{l.broker}</div></div>
              <div style={{textAlign:"right"}}>
                <div style={{fontSize:20,fontWeight:900,color:C.gold}}>${l.rate.toLocaleString()}</div>
                <div style={{fontSize:10,color:C.muted}}>${(l.rate/l.miles).toFixed(2)}/mi</div>
                {l.margin&&<div style={{fontSize:11,color:C.green,fontWeight:700}}>+${l.margin} margin</div>}
              </div>
            </div>
          </Card>
        ))}
      </div>
      {showAdd&&(
        <Modal title="Post FTL Load" onClose={()=>setShowAdd(false)} width={560}>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
            <Fl label="Origin" value={form.origin} onChange={v=>setForm({...form,origin:v})}/>
            <Fl label="Destination" value={form.dest} onChange={v=>setForm({...form,dest:v})}/>
            <Fl label="Pickup Date" value={form.pickup} onChange={v=>setForm({...form,pickup:v})}/>
            <Fl label="Delivery Date" value={form.delivery} onChange={v=>setForm({...form,delivery:v})}/>
            <Fl label="Commodity" value={form.commodity} onChange={v=>setForm({...form,commodity:v})}/>
            <Fl label="Weight (lbs)" value={form.weight} onChange={v=>setForm({...form,weight:v})}/>
            <Fl label="Rate ($)" value={form.rate} onChange={v=>setForm({...form,rate:v})} type="number"/>
            <Fl label="Margin ($)" value={form.margin} onChange={v=>setForm({...form,margin:v})} type="number"/>
            <Fl label="Equipment" value={form.equipment} onChange={v=>setForm({...form,equipment:v})} options={["Dry Van","Reefer","Flatbed","Step Deck","RGN","Power Only"]}/>
            <Fl label="Status" value={form.status} onChange={v=>setForm({...form,status:v})} options={["Available","Booked"]}/>
          </div>
          <Fl label="Shipper" value={form.shipper} onChange={v=>setForm({...form,shipper:v})}/>
          <Fl label="Carrier (if booked)" value={form.carrier} onChange={v=>setForm({...form,carrier:v})}/>
          <PrimaryBtn onClick={add} style={{width:"100%",justifyContent:"center",marginTop:8}}>Post Load</PrimaryBtn>
        </Modal>
      )}
    </div>
  );
}

/* ─── VERIFY PAGE ────────────────────────────────────────── */
const FRAUD_DB = [
  {mc:"MC-999001",name:"Ghost Freight LLC",dot:"DOT-0000001",status:"FRAUDULENT",reason:"Identity theft — impersonating real carrier",reported:"Jan 2026",source:"FMCSA Alert"},
  {mc:"MC-888501",name:"FastMove Transport",dot:"DOT-8885011",status:"FRAUDULENT",reason:"Double brokering — load never delivered",reported:"Feb 2026",source:"DAT Fraud Report"},
  {mc:"MC-777302",name:"Reliable Haulers Inc",dot:"DOT-7773020",status:"SUSPENDED",reason:"Operating authority revoked by FMCSA",reported:"Mar 2026",source:"FMCSA"},
  {mc:"MC-666100",name:"Premier Logistics Co",dot:"DOT-6661001",status:"WARNING",reason:"Multiple cargo claims unresolved",reported:"Apr 2026",source:"Carrier411"},
];

const VERIFIED_DB = [
  {mc:"MC-847291",name:"FastLane Trucking LLC",dot:"DOT-3847201",status:"VERIFIED",insurance:"Active $1M",authority:"Active",safety:"Satisfactory",years:8},
  {mc:"MC-628193",name:"Apex Haulers",dot:"DOT-6281934",status:"VERIFIED",insurance:"Active $1M",authority:"Active",safety:"Satisfactory",years:12},
  {mc:"MC-192837",name:"Steel Road Carriers",dot:"DOT-2918374",status:"VERIFIED",insurance:"Active $1M",authority:"Active",safety:"Satisfactory",years:5},
];

const CHECKED_HISTORY = [
  {id:1,name:"FastLane Trucking LLC",mc:"MC-847291",type:"Carrier",result:"VERIFIED",date:"Apr 24",agent:"Alex J."},
  {id:2,name:"Ghost Freight LLC",mc:"MC-999001",type:"Carrier",result:"FRAUDULENT",date:"Apr 23",agent:"Sarah K."},
  {id:3,name:"GlobalTech Imports",mc:"EIN-82-1234567",type:"Shipper",result:"VERIFIED",date:"Apr 22",agent:"Mike P."},
];

function VerifyPage() {
  const [query,setQuery]=useState("");
  const [type,setType]=useState("Carrier");
  const [result,setResult]=useState(null);
  const [loading,setLoading]=useState(false);
  const [history,setHistory]=useState(CHECKED_HISTORY);
  const [tab,setTab]=useState("check");

  const check = () => {
    if(!query.trim()) return;
    setLoading(true);
    setResult(null);
    setTimeout(()=>{
      const q=query.trim().toLowerCase();
      const fraud=FRAUD_DB.find(f=>f.mc.toLowerCase().includes(q)||f.name.toLowerCase().includes(q));
      const verified=VERIFIED_DB.find(v=>v.mc.toLowerCase().includes(q)||v.name.toLowerCase().includes(q));
      let res;
      if(fraud) res={...fraud,type};
      else if(verified) res={...verified,type};
      else res={
        name:query,mc:query,type,
        status: Math.random()>0.3?"VERIFIED":"WARNING",
        insurance:Math.random()>0.3?"Active $1M":"Expired",
        authority:Math.random()>0.2?"Active":"Inactive",
        safety:Math.random()>0.3?"Satisfactory":"Conditional",
        years:Math.floor(Math.random()*10+1),
        reason:Math.random()>0.3?null:"Operating with conditional safety rating",
      };
      setResult(res);
      setHistory(prev=>[{id:Date.now(),name:res.name,mc:res.mc||query,type,result:res.status,date:"Today",agent:"You"},...prev.slice(0,9)]);
      setLoading(false);
    },1800);
  };

  const statusConfig={
    VERIFIED:{color:C.green,icon:"✅",label:"Verified — Safe to work with",bg:`${C.green}12`},
    FRAUDULENT:{color:C.red,icon:"🚨",label:"FRAUD ALERT — Do NOT engage!",bg:`${C.red}12`},
    SUSPENDED:{color:C.red,icon:"⛔",label:"SUSPENDED — Authority revoked",bg:`${C.red}12`},
    WARNING:{color:C.orange,icon:"⚠️",label:"Warning — Proceed with caution",bg:`${C.orange}12`},
  };

  return (
    <div>
      <div style={{marginBottom:22}}>
        <h2 style={{color:C.text,fontSize:20,fontWeight:900,margin:"0 0 3px"}}>🛡️ Counterparty Verification</h2>
        <p style={{color:C.muted,margin:0,fontSize:12}}>Check carriers & shippers against FMCSA, fraud databases and blacklists</p>
      </div>

      {/* Tabs */}
      <div style={{display:"flex",gap:0,marginBottom:20,background:C.surface,borderRadius:10,padding:4,width:"fit-content"}}>
        {[{k:"check",l:"🔍 Run Check"},{k:"history",l:"📋 History"},{k:"blacklist",l:"🚨 Fraud Database"}].map(t=>(
          <button key={t.k} onClick={()=>setTab(t.k)} style={{padding:"8px 18px",borderRadius:8,border:"none",background:tab===t.k?C.card:"transparent",color:tab===t.k?C.text:C.muted,fontSize:13,cursor:"pointer",fontFamily:"inherit",fontWeight:tab===t.k?700:400}}>{t.l}</button>
        ))}
      </div>

      {tab==="check"&&(
        <div>
          {/* Search box */}
          <Card style={{padding:24,marginBottom:16}}>
            <div style={{color:C.muted,fontSize:11,textTransform:"uppercase",letterSpacing:"0.5px",marginBottom:14}}>Enter MC#, DOT#, Company Name, or EIN</div>
            <div style={{display:"flex",gap:10,marginBottom:14,flexWrap:"wrap"}}>
              <div style={{flex:1,minWidth:240,position:"relative"}}>
                <span style={{position:"absolute",left:12,top:"50%",transform:"translateY(-50%)",color:C.muted}}>
                  <svg width={16} height={16} viewBox="0 0 24 24" fill="currentColor"><path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/></svg>
                </span>
                <input value={query} onChange={e=>setQuery(e.target.value)} onKeyDown={e=>e.key==="Enter"&&check()}
                  placeholder="e.g. MC-847291 or FastLane Trucking..."
                  style={{...inp,paddingLeft:38,fontSize:14}}/>
              </div>
              <select value={type} onChange={e=>setType(e.target.value)} style={{...inp,width:140,appearance:"none"}}>
                <option>Carrier</option><option>Shipper</option><option>Broker</option>
              </select>
              <button onClick={check} disabled={loading||!query.trim()} style={{padding:"9px 24px",background:loading?C.dim:`linear-gradient(135deg,${C.accent},#007aaa)`,border:"none",borderRadius:9,color:loading?"#666":"#000",fontSize:14,fontWeight:700,cursor:loading||!query.trim()?"default":"pointer",fontFamily:"inherit",minWidth:120}}>
                {loading?"Checking...":"Run Check →"}
              </button>
            </div>
            <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
              {["MC-847291","MC-999001","Ghost Freight LLC","Apex Haulers"].map(s=>(
                <button key={s} onClick={()=>setQuery(s)} style={{padding:"4px 10px",background:"rgba(255,255,255,0.05)",border:`1px solid ${C.border}`,borderRadius:20,color:C.muted,fontSize:11,cursor:"pointer",fontFamily:"inherit"}}>Try: {s}</button>
              ))}
            </div>
          </Card>

          {/* Loading */}
          {loading&&(
            <Card style={{padding:40,textAlign:"center"}}>
              <div style={{fontSize:32,marginBottom:12}}>🔍</div>
              <div style={{color:C.text,fontSize:15,fontWeight:700,marginBottom:8}}>Checking databases...</div>
              <div style={{color:C.muted,fontSize:12,marginBottom:20}}>FMCSA · SaferSys · Carrier411 · Fraud Blacklist</div>
              <div style={{display:"flex",justifyContent:"center",gap:20}}>
                {["FMCSA","DAT","Carrier411","Blacklist"].map((src,i)=>(
                  <div key={src} style={{textAlign:"center"}}>
                    <div style={{width:36,height:36,borderRadius:"50%",background:C.accentDim,border:`2px solid ${C.accent}`,display:"flex",alignItems:"center",justifyContent:"center",margin:"0 auto 6px",animation:`spin${i} 1s linear infinite`}}>
                      <div style={{width:8,height:8,borderRadius:"50%",background:C.accent}}/>
                    </div>
                    <div style={{fontSize:10,color:C.muted}}>{src}</div>
                  </div>
                ))}
              </div>
              <style>{`@keyframes spin0{to{transform:rotate(360deg)}} @keyframes spin1{to{transform:rotate(-360deg)}} @keyframes spin2{to{transform:rotate(360deg)}} @keyframes spin3{to{transform:rotate(-360deg)}}`}</style>
            </Card>
          )}

          {/* Result */}
          {result&&!loading&&(()=>{
            const cfg=statusConfig[result.status]||statusConfig.WARNING;
            return(
              <div>
                {/* Status banner */}
                <div style={{padding:"18px 24px",background:cfg.bg,border:`2px solid ${cfg.color}44`,borderRadius:14,marginBottom:16,display:"flex",alignItems:"center",gap:16}}>
                  <div style={{fontSize:40}}>{cfg.icon}</div>
                  <div>
                    <div style={{fontSize:20,fontWeight:900,color:cfg.color}}>{cfg.label}</div>
                    <div style={{color:C.text,fontSize:15,fontWeight:700,marginTop:3}}>{result.name}</div>
                    {result.reason&&<div style={{color:C.muted,fontSize:13,marginTop:3}}>Reason: {result.reason}</div>}
                  </div>
                </div>

                <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:14}}>
                  {/* Details */}
                  <Card style={{padding:20}}>
                    <div style={{color:C.muted,fontSize:11,textTransform:"uppercase",letterSpacing:"0.5px",marginBottom:14}}>Company Details</div>
                    {[
                      {l:"Company",v:result.name},
                      {l:"MC Number",v:result.mc},
                      {l:"DOT Number",v:result.dot||"N/A"},
                      {l:"Type",v:result.type},
                      {l:"Years in Business",v:result.years?`${result.years} years`:"Unknown"},
                    ].map((r,i)=>(
                      <div key={i} style={{display:"flex",justifyContent:"space-between",padding:"8px 0",borderBottom:i<4?`1px solid ${C.border}`:"none"}}>
                        <span style={{fontSize:12,color:C.muted}}>{r.l}</span>
                        <span style={{fontSize:12,color:C.text,fontWeight:600}}>{r.v}</span>
                      </div>
                    ))}
                  </Card>

                  {/* Compliance */}
                  <Card style={{padding:20}}>
                    <div style={{color:C.muted,fontSize:11,textTransform:"uppercase",letterSpacing:"0.5px",marginBottom:14}}>Compliance Check</div>
                    {[
                      {l:"Operating Authority",v:result.authority||"Active",good:result.authority!=="Inactive"},
                      {l:"Cargo Insurance",v:result.insurance||"$1M",good:!result.insurance?.includes("Expired")},
                      {l:"Safety Rating",v:result.safety||"Satisfactory",good:result.safety!=="Unsatisfactory"},
                      {l:"Fraud Blacklist",v:result.status==="FRAUDULENT"?"⚠ LISTED":"✅ Clear",good:result.status!=="FRAUDULENT"},
                      {l:"FMCSA Status",v:result.status==="SUSPENDED"?"⛔ Suspended":"✅ Active",good:result.status!=="SUSPENDED"},
                    ].map((r,i)=>(
                      <div key={i} style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"8px 0",borderBottom:i<4?`1px solid ${C.border}`:"none"}}>
                        <span style={{fontSize:12,color:C.muted}}>{r.l}</span>
                        <span style={{fontSize:12,color:r.good?C.green:C.red,fontWeight:700}}>{r.v}</span>
                      </div>
                    ))}
                  </Card>
                </div>

                {/* Sources */}
                <Card style={{padding:18,marginTop:14}}>
                  <div style={{color:C.muted,fontSize:11,textTransform:"uppercase",letterSpacing:"0.5px",marginBottom:12}}>Data Sources Checked</div>
                  <div style={{display:"flex",gap:10,flexWrap:"wrap"}}>
                    {[
                      {name:"FMCSA SaferSys",url:"safer.fmcsa.dot.gov",ok:true},
                      {name:"Carrier411",url:"carrier411.com",ok:true},
                      {name:"DAT Fraud Center",url:"dat.com",ok:true},
                      {name:"Internal Blacklist",url:"FreightCRM DB",ok:true},
                      {name:"USDOT",url:"usdot.gov",ok:true},
                    ].map((src,i)=>(
                      <div key={i} style={{padding:"6px 12px",background:`${C.green}11`,border:`1px solid ${C.green}22`,borderRadius:8,display:"flex",alignItems:"center",gap:6}}>
                        <span style={{color:C.green,fontSize:11}}>✓</span>
                        <span style={{fontSize:11,color:C.muted}}>{src.name}</span>
                      </div>
                    ))}
                  </div>
                </Card>

                {/* Actions */}
                <div style={{display:"flex",gap:10,marginTop:14}}>
                  {result.status==="VERIFIED"&&(
                    <button style={{flex:1,padding:"11px",background:`${C.green}18`,border:`1px solid ${C.green}33`,color:C.green,borderRadius:10,cursor:"pointer",fontSize:13,fontWeight:700,fontFamily:"inherit"}}>
                      ✅ Add to Approved Carriers
                    </button>
                  )}
                  {(result.status==="FRAUDULENT"||result.status==="SUSPENDED")&&(
                    <button style={{flex:1,padding:"11px",background:`${C.red}18`,border:`1px solid ${C.red}33`,color:C.red,borderRadius:10,cursor:"pointer",fontSize:13,fontWeight:700,fontFamily:"inherit"}}>
                      🚨 Add to Blacklist & Alert Team
                    </button>
                  )}
                  {result.status==="WARNING"&&(
                    <button style={{flex:1,padding:"11px",background:`${C.orange}18`,border:`1px solid ${C.orange}33`,color:C.orange,borderRadius:10,cursor:"pointer",fontSize:13,fontWeight:700,fontFamily:"inherit"}}>
                      ⚠️ Flag for Review
                    </button>
                  )}
                  <button onClick={()=>{const txt=`FreightCRM Verification Report\n${result.name}\nMC: ${result.mc}\nStatus: ${result.status}\nInsurance: ${result.insurance||"N/A"}\nAuthority: ${result.authority||"N/A"}\nSafety: ${result.safety||"N/A"}`;navigator.clipboard?.writeText(txt);}} style={{padding:"11px 18px",background:"rgba(255,255,255,0.05)",border:`1px solid ${C.border}`,color:C.muted,borderRadius:10,cursor:"pointer",fontSize:12,fontFamily:"inherit"}}>
                    📋 Copy Report
                  </button>
                </div>
              </div>
            );
          })()}

          {/* Tips */}
          {!result&&!loading&&(
            <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:12,marginTop:8}}>
              {[
                {icon:"🔴",title:"Red Flags",items:["MC number doesn't match company name","No cargo insurance or expired","Recently activated authority (< 3 months)","Requests payment via Zelle/Venmo","Phone number doesn't match FMCSA records"]},
                {icon:"✅",title:"Good Signs",items:["Active authority 2+ years","$1M+ cargo insurance","Satisfactory safety rating","Matches FMCSA database exactly","Has Carrier411 profile with reviews"]},
                {icon:"⚡",title:"Quick Tips",items:["Always verify MC# on safer.fmcsa.dot.gov","Call the number on FMCSA — not the one they give","Check insurance certificate directly with insurer","Never pay carrier before delivery confirmation","Use CarrierWatch or Carrier411 for reviews"]},
              ].map((box,i)=>(
                <Card key={i} style={{padding:18}}>
                  <div style={{fontSize:20,marginBottom:10}}>{box.icon}</div>
                  <div style={{color:C.text,fontSize:13,fontWeight:700,marginBottom:10}}>{box.title}</div>
                  {box.items.map((item,j)=>(
                    <div key={j} style={{fontSize:12,color:C.muted,marginBottom:6,paddingLeft:12,position:"relative"}}>
                      <span style={{position:"absolute",left:0,color:i===0?C.red:i===1?C.green:C.accent}}>•</span>
                      {item}
                    </div>
                  ))}
                </Card>
              ))}
            </div>
          )}
        </div>
      )}

      {tab==="history"&&(
        <div>
          <Card>
            <div style={{display:"grid",gridTemplateColumns:"1.5fr 1fr 80px 100px 90px 80px",padding:"10px 18px",borderBottom:`1px solid ${C.border}`}}>
              {["Company","MC / EIN","Type","Result","Date","Agent"].map((h,i)=>(
                <div key={i} style={{fontSize:10,color:C.muted,textTransform:"uppercase",letterSpacing:"0.5px",fontWeight:700}}>{h}</div>
              ))}
            </div>
            {history.map((h,i)=>{
              const cfg=statusConfig[h.result]||statusConfig.WARNING;
              return(
                <div key={h.id} style={{display:"grid",gridTemplateColumns:"1.5fr 1fr 80px 100px 90px 80px",padding:"13px 18px",alignItems:"center",borderBottom:i<history.length-1?`1px solid ${C.border}`:"none"}}>
                  <div style={{color:C.text,fontSize:13,fontWeight:600}}>{h.name}</div>
                  <div style={{color:C.muted,fontSize:12}}>{h.mc}</div>
                  <div><Badge label={h.type} color={h.type==="Carrier"?C.accent:C.gold}/></div>
                  <div><span style={{color:cfg.color,fontSize:12,fontWeight:700}}>{cfg.icon} {h.result}</span></div>
                  <div style={{color:C.muted,fontSize:12}}>{h.date}</div>
                  <div style={{color:C.muted,fontSize:12}}>{h.agent}</div>
                </div>
              );
            })}
          </Card>
        </div>
      )}

      {tab==="blacklist"&&(
        <div>
          <div style={{padding:"12px 16px",background:`${C.red}11`,border:`1px solid ${C.red}22`,borderRadius:10,marginBottom:16,display:"flex",gap:10,alignItems:"center"}}>
            <span style={{fontSize:20}}>🚨</span>
            <div>
              <div style={{color:C.red,fontWeight:700,fontSize:13}}>Internal Fraud Database</div>
              <div style={{color:C.muted,fontSize:12}}>Do NOT work with any company listed below. Report new fraud to your compliance team.</div>
            </div>
          </div>
          <div style={{display:"flex",flexDirection:"column",gap:10}}>
            {FRAUD_DB.map((f,i)=>{
              const cfg=statusConfig[f.status]||statusConfig.WARNING;
              return(
                <Card key={i} style={{padding:20,border:`1px solid ${cfg.color}33`}}>
                  <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:12}}>
                    <div>
                      <div style={{color:C.text,fontWeight:700,fontSize:15}}>{f.name}</div>
                      <div style={{color:C.muted,fontSize:12,marginTop:2}}>{f.mc} · {f.dot}</div>
                    </div>
                    <span style={{background:`${cfg.color}22`,color:cfg.color,border:`1px solid ${cfg.color}44`,padding:"4px 12px",borderRadius:20,fontSize:11,fontWeight:700}}>{cfg.icon} {f.status}</span>
                  </div>
                  <div style={{padding:"10px 14px",background:`${cfg.color}0d`,borderRadius:8,marginBottom:10}}>
                    <div style={{fontSize:12,color:cfg.color,fontWeight:700,marginBottom:3}}>⚠ Reason</div>
                    <div style={{fontSize:13,color:C.text}}>{f.reason}</div>
                  </div>
                  <div style={{display:"flex",gap:16,fontSize:11,color:C.muted}}>
                    <span>Reported: {f.reported}</span>
                    <span>Source: {f.source}</span>
                  </div>
                </Card>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}


/* ══════════════════════════════════════════════════════════
   NOTIFICATIONS PAGE
══════════════════════════════════════════════════════════ */
const NOTIF_DATA=[
  {id:1,icon:"🚛",title:"LB-10041 is now In Transit",body:"Auto Parts Chicago→Dallas. Driver: Marcus Webb. ETA: Apr 27.",time:"2 min ago",read:false,priority:"High"},
  {id:2,icon:"💰",title:"Payment overdue — INV-1043",body:"NovaBuild Materials $890 is 5 days overdue.",time:"1 hr ago",read:false,priority:"High"},
  {id:3,icon:"🚨",title:"FRAUD ALERT — Ghost Freight LLC",body:"MC-999001 flagged as fraudulent. Do NOT assign loads.",time:"3 hrs ago",read:false,priority:"High"},
  {id:4,icon:"✅",title:"Apex Haulers verified",body:"MC-628193 passed all compliance checks.",time:"5 hrs ago",read:true,priority:"Low"},
  {id:5,icon:"📦",title:"LTL-2002 ready for pickup",body:"Medical Supplies Denver→Kansas City. $420.",time:"Yesterday",read:true,priority:"Medium"},
  {id:6,icon:"🏁",title:"LB-10042 delivered",body:"Produce Fresno→Phoenix delivered. Invoice ready.",time:"Yesterday",read:true,priority:"Low"},
];
const EMAIL_RULES=[
  {id:1,event:"Load status change",recipients:"Shipper + Broker",enabled:true},
  {id:2,event:"Payment overdue",recipients:"Accounting + Manager",enabled:true},
  {id:3,event:"Fraud alert",recipients:"All team",enabled:true},
  {id:4,event:"New load posted",recipients:"Dispatchers",enabled:false},
  {id:5,event:"Load delivered",recipients:"Shipper + Accounting",enabled:true},
];
function NotificationsPage(){
  const [notifs,setNotifs]=useState(NOTIF_DATA);
  const [rules,setRules]=useState(EMAIL_RULES);
  const [tab,setTab]=useState("inbox");
  const [testEmail,setTestEmail]=useState("");
  const [sent,setSent]=useState(false);
  const unread=notifs.filter(n=>!n.read).length;
  const pColor={High:C.red,Medium:C.orange,Low:C.green};
  return(
    <div>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:22}}>
        <div><h2 style={{color:C.text,fontSize:20,fontWeight:900,margin:"0 0 3px"}}>🔔 Notifications & Email Alerts</h2><p style={{color:C.muted,margin:0,fontSize:12}}>{unread} unread</p></div>
        {unread>0&&<PrimaryBtn onClick={()=>setNotifs(notifs.map(n=>({...n,read:true})))}>Mark All Read</PrimaryBtn>}
      </div>
      <div style={{display:"flex",gap:0,marginBottom:20,background:C.surface,borderRadius:10,padding:4,width:"fit-content"}}>
        {[{k:"inbox",l:`📬 Inbox (${unread})`},{k:"rules",l:"⚙️ Email Rules"},{k:"test",l:"📧 Test"}].map(t=>(
          <button key={t.k} onClick={()=>setTab(t.k)} style={{padding:"8px 18px",borderRadius:8,border:"none",background:tab===t.k?C.card:"transparent",color:tab===t.k?C.text:C.muted,fontSize:13,cursor:"pointer",fontFamily:"inherit",fontWeight:tab===t.k?700:400}}>{t.l}</button>
        ))}
      </div>
      {tab==="inbox"&&(
        <div style={{display:"flex",flexDirection:"column",gap:8}}>
          {notifs.map(n=>(
            <Card key={n.id} style={{padding:"14px 18px",opacity:n.read?0.55:1,borderLeft:`3px solid ${n.read?C.border:pColor[n.priority]}`}}>
              <div style={{display:"flex",alignItems:"flex-start",gap:12}}>
                <div style={{fontSize:22,flexShrink:0}}>{n.icon}</div>
                <div style={{flex:1}}>
                  <div style={{display:"flex",justifyContent:"space-between",marginBottom:4}}>
                    <div style={{color:n.read?C.muted:C.text,fontWeight:n.read?400:700,fontSize:14}}>{n.title}</div>
                    <div style={{display:"flex",gap:6,alignItems:"center",marginLeft:12,flexShrink:0}}>
                      <Badge label={n.priority}/><span style={{fontSize:11,color:C.muted}}>{n.time}</span>
                    </div>
                  </div>
                  <div style={{color:C.muted,fontSize:12}}>{n.body}</div>
                </div>
                <div style={{display:"flex",gap:6}}>
                  {!n.read&&<button onClick={()=>setNotifs(notifs.map(x=>x.id===n.id?{...x,read:true}:x))} style={{width:28,height:28,borderRadius:7,background:`${C.green}18`,border:`1px solid ${C.green}33`,color:C.green,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",fontFamily:"inherit"}}>✓</button>}
                  <button onClick={()=>setNotifs(notifs.filter(x=>x.id!==n.id))} style={{width:28,height:28,borderRadius:7,background:`${C.red}18`,border:`1px solid ${C.red}33`,color:C.red,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center"}}>×</button>
                </div>
              </div>
            </Card>
          ))}
          {notifs.length===0&&<div style={{textAlign:"center",padding:60,color:C.muted}}>📭 All caught up!</div>}
        </div>
      )}
      {tab==="rules"&&(
        <Card>
          {rules.map((r,i)=>(
            <div key={r.id} style={{display:"flex",alignItems:"center",gap:16,padding:"16px 20px",borderBottom:i<rules.length-1?`1px solid ${C.border}`:"none"}}>
              <div style={{flex:1}}>
                <div style={{color:C.text,fontSize:14,fontWeight:600}}>{r.event}</div>
                <div style={{color:C.muted,fontSize:12,marginTop:2}}>→ {r.recipients}</div>
              </div>
              <span style={{fontSize:12,color:r.enabled?C.green:C.muted,marginRight:8}}>{r.enabled?"Active":"Off"}</span>
              <div onClick={()=>setRules(rules.map(x=>x.id===r.id?{...x,enabled:!x.enabled}:x))} style={{width:44,height:24,borderRadius:12,background:r.enabled?C.green:C.dim,cursor:"pointer",position:"relative",flexShrink:0}}>
                <div style={{position:"absolute",top:2,left:r.enabled?20:2,width:20,height:20,borderRadius:"50%",background:"#fff",transition:"left 0.2s"}}/>
              </div>
            </div>
          ))}
        </Card>
      )}
      {tab==="test"&&(
        <Card style={{padding:28,maxWidth:440}}>
          <div style={{color:C.text,fontWeight:700,fontSize:15,marginBottom:16}}>Send Test Notification Email</div>
          <Fl label="Email Address" value={testEmail} onChange={setTestEmail} type="email" placeholder="you@company.com"/>
          <Fl label="Type" value="Load status change" onChange={()=>{}} options={["Load status change","Payment overdue","Fraud alert","Load delivered"]}/>
          {sent&&<div style={{padding:"10px 14px",background:`${C.green}15`,border:`1px solid ${C.green}33`,borderRadius:8,color:C.green,fontSize:13,marginBottom:14}}>✅ Test email sent to {testEmail}!</div>}
          <PrimaryBtn onClick={()=>{if(testEmail){setSent(true);setTimeout(()=>setSent(false),3000);}}} style={{width:"100%",justifyContent:"center"}}>Send Test Email</PrimaryBtn>
        </Card>
      )}
    </div>
  );
}

/* ══════════════════════════════════════════════════════════
   REPORTS PAGE
══════════════════════════════════════════════════════════ */
const RPT_LOADS=[
  {id:"LB-10041",type:"FTL",origin:"Chicago IL",dest:"Dallas TX",rate:2450,margin:380,status:"In Transit",broker:"Alex Johnson",date:"Apr 25"},
  {id:"LB-10042",type:"FTL",origin:"Fresno CA",dest:"Phoenix AZ",rate:1800,margin:290,status:"Booked",broker:"Sarah Kim",date:"Apr 26"},
  {id:"LB-10043",type:"FTL",origin:"Atlanta GA",dest:"Miami FL",rate:1950,margin:310,status:"Available",broker:"Mike Patel",date:"Apr 28"},
  {id:"LTL-2001",type:"LTL",origin:"Houston TX",dest:"Orlando FL",rate:890,margin:180,status:"Booked",broker:"Mike Patel",date:"Apr 26"},
];
const RPT_BROKERS=[
  {name:"Alex Johnson",loads:42,revenue:84200,margin:14800,conv:"78%"},
  {name:"Sarah Kim",loads:28,revenue:51400,margin:9200,conv:"65%"},
  {name:"Mike Patel",loads:67,revenue:102300,margin:18900,conv:"82%"},
  {name:"Tom Rivera",loads:15,revenue:28800,margin:4100,conv:"55%"},
];
function ReportsPage(){
  const [period,setPeriod]=useState("This Month");
  const [format,setFormat]=useState("CSV");
  const [dl,setDl]=useState(false);
  const [done,setDone]=useState("");
  const totalRev=RPT_LOADS.reduce((s,l)=>s+l.rate,0);
  const totalMgn=RPT_LOADS.reduce((s,l)=>s+l.margin,0);
  const barMax=Math.max(...RPT_BROKERS.map(b=>b.revenue));
  const colors=[C.accent,C.gold,C.green,C.purple];

  const download=()=>{
    setDl(true);
    setTimeout(()=>{
      const csv=["ID,Type,Origin,Destination,Rate,Margin,Status,Broker,Date",...RPT_LOADS.map(l=>`${l.id},${l.type},${l.origin},${l.dest},$${l.rate},$${l.margin},${l.status},${l.broker},${l.date}`)].join("\n");
      const blob=new Blob([csv],{type:"text/csv"});
      const a=document.createElement("a");
      a.href=URL.createObjectURL(blob);
      a.download=`freightcrm-report.csv`;
      a.click();
      setDl(false);
      setDone("freightcrm-report.csv");
      setTimeout(()=>setDone(""),4000);
    },1200);
  };

  return(
    <div>
      <div style={{marginBottom:22}}><h2 style={{color:C.text,fontSize:20,fontWeight:900,margin:"0 0 3px"}}>📊 Reports & Export</h2><p style={{color:C.muted,margin:0,fontSize:12}}>CSV · PDF · Excel</p></div>
      <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:12,marginBottom:20}}>
        {[{label:"Total Revenue",val:`$${totalRev.toLocaleString()}`,color:C.gold},{label:"Total Margin",val:`$${totalMgn.toLocaleString()}`,color:C.green},{label:"Margin %",val:`${((totalMgn/totalRev)*100).toFixed(1)}%`,color:C.accent},{label:"Loads",val:RPT_LOADS.length,color:C.purple}].map((k,i)=>(
          <Card key={i} style={{padding:"16px 20px"}}><div style={{fontSize:26,fontWeight:900,color:k.color}}>{k.val}</div><div style={{fontSize:11,color:C.muted,marginTop:3}}>{k.label}</div></Card>
        ))}
      </div>
      <div style={{display:"grid",gridTemplateColumns:"1fr 320px",gap:16,marginBottom:16}}>
        <Card style={{padding:22}}>
          <div style={{color:C.muted,fontSize:11,textTransform:"uppercase",letterSpacing:"0.5px",marginBottom:18}}>Broker Revenue</div>
          {RPT_BROKERS.map((b,i)=>(
            <div key={i} style={{marginBottom:16}}>
              <div style={{display:"flex",justifyContent:"space-between",marginBottom:5}}>
                <span style={{fontSize:13,color:C.text,fontWeight:600}}>{b.name}</span>
                <div style={{display:"flex",gap:12,fontSize:12}}>
                  <span style={{color:colors[i],fontWeight:700}}>${b.revenue.toLocaleString()}</span>
                  <span style={{color:C.muted}}>{b.loads} loads</span>
                  <span style={{color:C.green}}>{b.conv}</span>
                </div>
              </div>
              <div style={{height:10,background:C.dim,borderRadius:5}}>
                <div style={{width:`${(b.revenue/barMax)*100}%`,height:"100%",background:colors[i],borderRadius:5}}/>
              </div>
            </div>
          ))}
        </Card>
        <Card style={{padding:22}}>
          <div style={{color:C.muted,fontSize:11,textTransform:"uppercase",letterSpacing:"0.5px",marginBottom:16}}>Export</div>
          <Fl label="Period" value={period} onChange={setPeriod} options={["This Week","This Month","Last Month","Q1 2026","Q2 2026","All Time"]}/>
          <Fl label="Format" value={format} onChange={setFormat} options={["CSV","PDF","Excel"]}/>
          {done&&<div style={{padding:"8px 12px",background:`${C.green}15`,border:`1px solid ${C.green}33`,borderRadius:8,color:C.green,fontSize:12,marginBottom:12}}>✅ {done} downloaded!</div>}
          <PrimaryBtn onClick={download} style={{width:"100%",justifyContent:"center",marginBottom:10}}>{dl?"Generating...":"⬇ Download Report"}</PrimaryBtn>
          <div style={{display:"flex",flexDirection:"column",gap:6}}>
            {["📋 Loads CSV","👥 Brokers CSV","💰 AR/AP CSV"].map((q,i)=>(
              <button key={i} onClick={download} style={{padding:"8px 12px",background:"rgba(255,255,255,0.04)",border:`1px solid ${C.border}`,borderRadius:7,color:C.muted,fontSize:12,cursor:"pointer",textAlign:"left",fontFamily:"inherit"}}>{q}</button>
            ))}
          </div>
        </Card>
      </div>
      <Card>
        <div style={{padding:"10px 18px",borderBottom:`1px solid ${C.border}`,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
          <div style={{color:C.muted,fontSize:11,textTransform:"uppercase",letterSpacing:"0.5px"}}>Load Details — {period}</div>
          <button onClick={download} style={{padding:"5px 12px",background:C.accentDim,border:`1px solid ${C.accent}33`,borderRadius:7,color:C.accent,fontSize:11,cursor:"pointer",fontFamily:"inherit",fontWeight:700}}>⬇ Export</button>
        </div>
        <div style={{display:"grid",gridTemplateColumns:"100px 55px 1fr 1fr 80px 80px 90px 100px",padding:"9px 18px",borderBottom:`1px solid ${C.border}`}}>
          {["Load ID","Type","Origin","Dest","Rate","Margin","Status","Broker"].map((h,i)=><div key={i} style={{fontSize:10,color:C.muted,textTransform:"uppercase",letterSpacing:"0.5px",fontWeight:700}}>{h}</div>)}
        </div>
        {RPT_LOADS.map((l,i)=>(
          <div key={l.id} style={{display:"grid",gridTemplateColumns:"100px 55px 1fr 1fr 80px 80px 90px 100px",padding:"12px 18px",alignItems:"center",borderBottom:i<RPT_LOADS.length-1?`1px solid ${C.border}`:"none"}}>
            <div style={{color:C.accent,fontSize:12,fontWeight:700}}>{l.id}</div>
            <Badge label={l.type} color={l.type==="LTL"?C.teal:C.accent}/>
            <div style={{color:C.text,fontSize:12}}>{l.origin}</div>
            <div style={{color:C.text,fontSize:12}}>{l.dest}</div>
            <div style={{color:C.gold,fontSize:13,fontWeight:700}}>${l.rate.toLocaleString()}</div>
            <div style={{color:C.green,fontSize:13,fontWeight:700}}>+${l.margin}</div>
            <Badge label={l.status}/>
            <div style={{color:C.muted,fontSize:11}}>{l.broker.split(" ")[0]}</div>
          </div>
        ))}
      </Card>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════
   CALENDAR PAGE
══════════════════════════════════════════════════════════ */
const CAL_EVENTS_INIT=[
  {id:1,date:25,title:"LB-10041 Pickup",type:"pickup",color:C.accent},
  {id:2,date:25,title:"Call — Jake Morrison",type:"call",color:C.purple},
  {id:3,date:26,title:"LB-10042 Pickup",type:"pickup",color:C.accent},
  {id:4,date:26,title:"LTL-2001 Pickup",type:"pickup",color:C.teal},
  {id:5,date:27,title:"LB-10041 Delivery",type:"delivery",color:C.green},
  {id:6,date:28,title:"LB-10043 Pickup",type:"pickup",color:C.accent},
  {id:7,date:28,title:"Team Meeting",type:"meeting",color:C.gold},
  {id:8,date:29,title:"INV-1042 Due",type:"payment",color:C.red},
  {id:9,date:30,title:"LTL-2001 Delivery",type:"delivery",color:C.green},
];
function CalendarPage(){
  const [sel,setSel]=useState(25);
  const [events,setEvents]=useState(CAL_EVENTS_INIT);
  const [showAdd,setShowAdd]=useState(false);
  const [form,setForm]=useState({title:"",date:"",type:"meeting"});
  const typeIcon={pickup:"📦",delivery:"🏁",call:"📞",meeting:"👥",payment:"💵"};
  const typeColor={pickup:C.accent,delivery:C.green,call:C.purple,meeting:C.gold,payment:C.red};
  const days=Array.from({length:35},(_,i)=>i<3?null:i-2);
  const dayEvs=events.filter(e=>e.date===sel);

  return(
    <div>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:22}}>
        <div><h2 style={{color:C.text,fontSize:20,fontWeight:900,margin:"0 0 3px"}}>🗓️ Calendar</h2><p style={{color:C.muted,margin:0,fontSize:12}}>Pickups · Deliveries · Calls · Payments</p></div>
        <PrimaryBtn icon="plus" onClick={()=>setShowAdd(true)}>Add Event</PrimaryBtn>
      </div>
      <div style={{display:"grid",gridTemplateColumns:"1fr 280px",gap:16}}>
        <Card style={{padding:22}}>
          <div style={{color:C.text,fontSize:15,fontWeight:700,marginBottom:16}}>April 2026</div>
          <div style={{display:"grid",gridTemplateColumns:"repeat(7,1fr)",gap:2,marginBottom:6}}>
            {["Sun","Mon","Tue","Wed","Thu","Fri","Sat"].map(d=><div key={d} style={{textAlign:"center",fontSize:10,color:C.muted,fontWeight:700,padding:"4px 0"}}>{d}</div>)}
          </div>
          <div style={{display:"grid",gridTemplateColumns:"repeat(7,1fr)",gap:2}}>
            {days.map((day,i)=>{
              const ev=day?events.filter(e=>e.date===day):[];
              const isSel=day===sel;
              const isToday=day===25;
              return(
                <div key={i} onClick={()=>day&&setSel(day)} style={{minHeight:72,borderRadius:9,padding:"5px 6px",background:isSel?C.accentDim:"transparent",border:`1px solid ${isSel?C.accent:C.border}`,cursor:day?"pointer":"default"}}>
                  {day&&(
                    <>
                      <div style={{fontSize:12,fontWeight:isToday||isSel?700:400,color:isToday||isSel?C.accent:C.text,marginBottom:3}}>{day}</div>
                      {ev.slice(0,2).map((e,j)=>(
                        <div key={j} style={{fontSize:9,color:e.color,background:`${e.color}22`,borderRadius:3,padding:"1px 4px",marginBottom:2,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{typeIcon[e.type]} {e.title}</div>
                      ))}
                      {ev.length>2&&<div style={{fontSize:9,color:C.muted}}>+{ev.length-2}</div>}
                    </>
                  )}
                </div>
              );
            })}
          </div>
          <div style={{display:"flex",gap:12,marginTop:14,flexWrap:"wrap"}}>
            {Object.entries(typeColor).map(([t,c])=>(
              <div key={t} style={{display:"flex",alignItems:"center",gap:5}}>
                <div style={{width:7,height:7,borderRadius:"50%",background:c}}/>
                <span style={{fontSize:10,color:C.muted,textTransform:"capitalize"}}>{typeIcon[t]} {t}</span>
              </div>
            ))}
          </div>
        </Card>
        <div style={{display:"flex",flexDirection:"column",gap:12}}>
          <Card style={{padding:18}}>
            <div style={{color:C.text,fontWeight:700,fontSize:14,marginBottom:4}}>April {sel}, 2026</div>
            <div style={{color:C.muted,fontSize:12,marginBottom:12}}>{dayEvs.length} events</div>
            {dayEvs.length===0&&<div style={{color:C.muted,fontSize:13,textAlign:"center",padding:16}}>No events</div>}
            {dayEvs.map(e=>(
              <div key={e.id} style={{display:"flex",gap:10,alignItems:"center",padding:"10px 12px",background:`${e.color}11`,border:`1px solid ${e.color}22`,borderRadius:9,marginBottom:8}}>
                <div style={{fontSize:18}}>{typeIcon[e.type]}</div>
                <div style={{flex:1}}>
                  <div style={{color:C.text,fontSize:13,fontWeight:600}}>{e.title}</div>
                  <div style={{color:C.muted,fontSize:11,textTransform:"capitalize"}}>{e.type}</div>
                </div>
                <button onClick={()=>setEvents(events.filter(x=>x.id!==e.id))} style={{background:"none",border:"none",color:C.muted,cursor:"pointer",fontSize:14}}>×</button>
              </div>
            ))}
          </Card>
          <Card style={{padding:18}}>
            <div style={{color:C.muted,fontSize:11,textTransform:"uppercase",letterSpacing:"0.5px",marginBottom:12}}>Upcoming</div>
            {events.filter(e=>e.date>=25).sort((a,b)=>a.date-b.date).slice(0,5).map((e,i)=>(
              <div key={i} style={{display:"flex",gap:10,alignItems:"center",paddingBottom:9,borderBottom:i<4?`1px solid ${C.border}`:"none",marginBottom:i<4?9:0}}>
                <div style={{width:30,height:30,borderRadius:8,background:`${e.color}22`,color:e.color,display:"flex",alignItems:"center",justifyContent:"center",fontSize:14,flexShrink:0}}>{typeIcon[e.type]}</div>
                <div style={{flex:1}}>
                  <div style={{color:C.text,fontSize:12,fontWeight:600}}>{e.title}</div>
                  <div style={{color:C.muted,fontSize:11}}>Apr {e.date}</div>
                </div>
              </div>
            ))}
          </Card>
        </div>
      </div>
      {showAdd&&(
        <Modal title="Add Calendar Event" onClose={()=>setShowAdd(false)} width={400}>
          <Fl label="Event Title" value={form.title} onChange={v=>setForm({...form,title:v})} placeholder="e.g. LB-10050 Pickup"/>
          <Fl label="Day (1-30)" value={form.date} onChange={v=>setForm({...form,date:v})} type="number"/>
          <Fl label="Type" value={form.type} onChange={v=>setForm({...form,type:v})} options={["pickup","delivery","call","meeting","payment"]}/>
          <PrimaryBtn onClick={()=>{if(!form.title||!form.date)return;setEvents([...events,{id:Date.now(),date:parseInt(form.date),title:form.title,type:form.type,color:{pickup:C.accent,delivery:C.green,call:C.purple,meeting:C.gold,payment:C.red}[form.type]}]);setShowAdd(false);setForm({title:"",date:"",type:"meeting"});}} style={{width:"100%",justifyContent:"center",marginTop:8}}>Add Event</PrimaryBtn>
        </Modal>
      )}
    </div>
  );
}

/* ══════════════════════════════════════════════════════════
   TRACKING PAGE
══════════════════════════════════════════════════════════ */
const TRACK_DATA={
  "LB-10041":{id:"LB-10041",origin:"Chicago IL",dest:"Dallas TX",status:"In Transit",driver:"Marcus Webb",truck:"TX-4421",phone:"+1(512)555-0199",currentCity:"Springfield MO",progress:58,eta:"Apr 27, 6:00 PM",miles:921,milesLeft:387,updates:[{time:"Apr 25, 8:00 AM",city:"Chicago IL",event:"Picked up",icon:"📦",done:true},{time:"Apr 25, 4:30 PM",city:"Indianapolis IN",event:"Checkpoint",icon:"✅",done:true},{time:"Apr 26, 9:15 AM",city:"Springfield MO",event:"Currently here",icon:"📍",done:true},{time:"Apr 26, 6:00 PM",city:"Oklahoma City OK",event:"Expected",icon:"⏳",done:false},{time:"Apr 27, 6:00 PM",city:"Dallas TX",event:"Expected delivery",icon:"🏁",done:false}]},
  "LB-10042":{id:"LB-10042",origin:"Fresno CA",dest:"Phoenix AZ",status:"Booked",driver:"Dana Cruz",truck:"AZ-8812",phone:"+1(602)555-0177",currentCity:"Fresno CA",progress:0,eta:"Apr 27, 2:00 PM",miles:569,milesLeft:569,updates:[{time:"Apr 26, 7:00 AM",city:"Fresno CA",event:"Scheduled pickup",icon:"📦",done:false},{time:"Apr 27, 2:00 PM",city:"Phoenix AZ",event:"Expected delivery",icon:"🏁",done:false}]},
  "LTL-2001":{id:"LTL-2001",origin:"Houston TX",dest:"Orlando FL",status:"Booked",driver:"Pending",truck:"N/A",phone:"N/A",currentCity:"Houston TX",progress:0,eta:"Apr 30, 5:00 PM",miles:1095,milesLeft:1095,updates:[{time:"Apr 26, 9:00 AM",city:"Houston TX",event:"Scheduled pickup",icon:"📦",done:false},{time:"Apr 30, 5:00 PM",city:"Orlando FL",event:"Expected delivery",icon:"🏁",done:false}]},
};
function TrackingPage(){
  const [sel,setSel]=useState("LB-10041");
  const loads=Object.values(TRACK_DATA);
  const L=TRACK_DATA[sel];
  const sc={"In Transit":C.accent,Booked:C.purple,Available:C.green};
  return(
    <div>
      <div style={{marginBottom:22}}><h2 style={{color:C.text,fontSize:20,fontWeight:900,margin:"0 0 3px"}}>📍 Load Tracking</h2><p style={{color:C.muted,margin:0,fontSize:12}}>Real-time status for all active loads</p></div>
      <div style={{display:"grid",gridTemplateColumns:"260px 1fr",gap:16}}>
        <div style={{display:"flex",flexDirection:"column",gap:8}}>
          {loads.map(l=>(
            <Card key={l.id} style={{padding:16,cursor:"pointer",borderColor:sel===l.id?C.accent:C.border,transition:"border-color 0.2s"}} onClick={()=>setSel(l.id)}>
              <div style={{display:"flex",justifyContent:"space-between",marginBottom:8}}>
                <div style={{color:C.accent,fontSize:12,fontWeight:700}}>{l.id}</div>
                <Badge label={l.status} color={sc[l.status]}/>
              </div>
              <div style={{color:C.text,fontSize:13,fontWeight:600,marginBottom:6}}>{l.origin} → {l.dest}</div>
              <div style={{height:6,background:C.dim,borderRadius:3,marginBottom:4}}>
                <div style={{width:`${l.progress}%`,height:"100%",background:`linear-gradient(90deg,${C.accent},${C.green})`,borderRadius:3}}/>
              </div>
              <div style={{fontSize:11,color:C.muted}}>{l.progress}% · 📍 {l.currentCity}</div>
            </Card>
          ))}
        </div>
        <div style={{display:"flex",flexDirection:"column",gap:14}}>
          <Card style={{padding:22}}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:18}}>
              <div>
                <div style={{color:C.accent,fontSize:12,fontWeight:700,marginBottom:4}}>{L.id}</div>
                <div style={{color:C.text,fontSize:18,fontWeight:900}}>{L.origin} → {L.dest}</div>
                <div style={{color:C.muted,fontSize:12,marginTop:4}}>ETA: <span style={{color:C.gold,fontWeight:700}}>{L.eta}</span></div>
              </div>
              <Badge label={L.status} color={sc[L.status]}/>
            </div>
            <div style={{marginBottom:18}}>
              <div style={{display:"flex",justifyContent:"space-between",marginBottom:6}}>
                <span style={{fontSize:12,color:C.muted}}>{L.origin}</span>
                <span style={{fontSize:12,color:C.accent,fontWeight:700}}>{L.progress}%</span>
                <span style={{fontSize:12,color:C.muted}}>{L.dest}</span>
              </div>
              <div style={{height:14,background:C.dim,borderRadius:7,position:"relative"}}>
                <div style={{width:`${L.progress}%`,height:"100%",background:`linear-gradient(90deg,${C.accent},${C.green})`,borderRadius:7}}/>
                {L.progress>5&&L.progress<95&&<div style={{position:"absolute",top:-4,left:`${L.progress}%`,transform:"translateX(-50%)",fontSize:22}}>🚛</div>}
              </div>
              <div style={{display:"flex",justifyContent:"space-between",marginTop:5}}>
                <span style={{fontSize:11,color:C.muted}}>{L.miles-L.milesLeft} mi done</span>
                <span style={{fontSize:11,color:C.muted}}>{L.milesLeft} mi left</span>
              </div>
            </div>
            <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:10}}>
              {[{l:"Driver",v:L.driver},{l:"Truck",v:L.truck},{l:"Phone",v:L.phone}].map((r,i)=>(
                <div key={i} style={{padding:"10px 12px",background:"rgba(255,255,255,0.03)",borderRadius:8}}>
                  <div style={{fontSize:10,color:C.muted,textTransform:"uppercase",marginBottom:2}}>{r.l}</div>
                  <div style={{fontSize:12,color:C.text,fontWeight:600}}>{r.v}</div>
                </div>
              ))}
            </div>
          </Card>
          <Card style={{padding:22}}>
            <div style={{color:C.muted,fontSize:11,textTransform:"uppercase",letterSpacing:"0.5px",marginBottom:18}}>Timeline</div>
            <div style={{position:"relative"}}>
              <div style={{position:"absolute",left:18,top:0,bottom:0,width:2,background:C.dim}}/>
              {L.updates.map((u,i)=>(
                <div key={i} style={{display:"flex",gap:16,marginBottom:i<L.updates.length-1?18:0,position:"relative"}}>
                  <div style={{width:36,height:36,borderRadius:"50%",background:u.done?`${C.green}22`:C.dim,border:`2px solid ${u.done?C.green:C.dim}`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:15,flexShrink:0,zIndex:1}}>{u.icon}</div>
                  <div style={{paddingTop:5,opacity:u.done?1:0.5}}>
                    <div style={{color:u.done?C.text:C.muted,fontSize:13,fontWeight:u.done?600:400}}>{u.event}</div>
                    <div style={{color:C.muted,fontSize:11,marginTop:1}}>{u.city} · {u.time}</div>
                  </div>
                </div>
              ))}
            </div>
          </Card>
          <Card style={{padding:16,display:"flex",alignItems:"center",gap:14}}>
            <div style={{fontSize:28}}>🗺️</div>
            <div style={{flex:1}}><div style={{color:C.text,fontWeight:700,fontSize:14}}>View Route in Google Maps</div><div style={{color:C.muted,fontSize:12}}>{L.origin} → {L.currentCity} → {L.dest}</div></div>
            <PrimaryBtn onClick={()=>window.open(`https://www.google.com/maps/dir/${encodeURIComponent(L.origin)}/${encodeURIComponent(L.currentCity)}/${encodeURIComponent(L.dest)}`,"_blank")}>Open Maps →</PrimaryBtn>
          </Card>
        </div>
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════
   MARGIN CALCULATOR PAGE
══════════════════════════════════════════════════════════ */
const MGN_HISTORY_INIT=[
  {id:1,load:"LB-10041",route:"Chicago→Dallas",shipper:2450,carrier:2070,gross:380,net:305,pct:"12.4%",date:"Apr 24"},
  {id:2,load:"LB-10042",route:"Fresno→Phoenix",shipper:1800,carrier:1510,gross:290,net:228,pct:"12.7%",date:"Apr 23"},
  {id:3,load:"LTL-2001",route:"Houston→Orlando",shipper:890,carrier:710,gross:180,net:144,pct:"16.2%",date:"Apr 22"},
];
function MarginCalcPage(){
  const [f,setF]=useState({origin:"Chicago IL",dest:"Dallas TX",miles:921,shipperRate:2450,carrierRate:2070,fuel:0,fee:50,ins:25,other:0,equipment:"Dry Van"});
  const [history,setHistory]=useState(MGN_HISTORY_INIT);
  const set=(k,v)=>setF(p=>({...p,[k]:v}));
  const gross=f.shipperRate-f.carrierRate;
  const exp=Number(f.fuel)+Number(f.fee)+Number(f.ins)+Number(f.other);
  const net=gross-exp;
  const pct=f.shipperRate>0?((net/f.shipperRate)*100).toFixed(1):0;
  const rpm=f.miles>0?(f.shipperRate/f.miles).toFixed(2):0;
  const crpm=f.miles>0?(f.carrierRate/f.miles).toFixed(2):0;
  const col=net>=200?C.green:net>=100?C.orange:C.red;
  const save=()=>{
    setHistory([{id:Date.now(),load:`CALC-${history.length+1}`,route:`${f.origin.split(" ")[0]}→${f.dest.split(" ")[0]}`,shipper:f.shipperRate,carrier:f.carrierRate,gross,net,pct:`${pct}%`,date:"Today"},...history]);
  };
  return(
    <div>
      <div style={{marginBottom:22}}><h2 style={{color:C.text,fontSize:20,fontWeight:900,margin:"0 0 3px"}}>💵 Margin Calculator</h2><p style={{color:C.muted,margin:0,fontSize:12}}>Calculate profitability before booking</p></div>
      <div style={{display:"grid",gridTemplateColumns:"1fr 320px",gap:16,marginBottom:16}}>
        <Card style={{padding:24}}>
          <div style={{color:C.muted,fontSize:11,textTransform:"uppercase",letterSpacing:"0.5px",marginBottom:14}}>Load Details</div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12,marginBottom:16}}>
            <Fl label="Origin" value={f.origin} onChange={v=>set("origin",v)}/>
            <Fl label="Destination" value={f.dest} onChange={v=>set("dest",v)}/>
            <Fl label="Miles" value={f.miles} onChange={v=>set("miles",Number(v))} type="number"/>
            <Fl label="Equipment" value={f.equipment} onChange={v=>set("equipment",v)} options={["Dry Van","Reefer","Flatbed","Step Deck"]}/>
          </div>
          <div style={{color:C.muted,fontSize:11,textTransform:"uppercase",letterSpacing:"0.5px",marginBottom:12}}>Revenue & Costs</div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
            <div><Fl label="Shipper Rate ($)" value={f.shipperRate} onChange={v=>set("shipperRate",Number(v))} type="number"/><div style={{fontSize:11,color:C.muted,marginTop:-10,marginBottom:14}}>${rpm}/mi customer</div></div>
            <div><Fl label="Carrier Rate ($)" value={f.carrierRate} onChange={v=>set("carrierRate",Number(v))} type="number"/><div style={{fontSize:11,color:C.muted,marginTop:-10,marginBottom:14}}>${crpm}/mi carrier</div></div>
            <Fl label="Fuel Surcharge ($)" value={f.fuel} onChange={v=>set("fuel",Number(v))} type="number"/>
            <Fl label="Broker Fee ($)" value={f.fee} onChange={v=>set("fee",Number(v))} type="number"/>
            <Fl label="Insurance ($)" value={f.ins} onChange={v=>set("ins",Number(v))} type="number"/>
            <Fl label="Other ($)" value={f.other} onChange={v=>set("other",Number(v))} type="number"/>
          </div>
        </Card>
        <div style={{display:"flex",flexDirection:"column",gap:12}}>
          <Card style={{padding:24,border:`2px solid ${col}44`,background:`${col}08`}}>
            <div style={{textAlign:"center",marginBottom:18}}>
              <div style={{fontSize:12,color:C.muted,marginBottom:6}}>NET MARGIN</div>
              <div style={{fontSize:50,fontWeight:900,color:col,lineHeight:1}}>${net.toLocaleString()}</div>
              <div style={{fontSize:22,fontWeight:700,color:col,marginTop:4}}>{pct}%</div>
              <div style={{marginTop:10,padding:"5px 14px",background:`${col}22`,border:`1px solid ${col}44`,borderRadius:20,display:"inline-block",fontSize:12,color:col,fontWeight:700}}>
                {net>=200?"✅ GOOD LOAD":net>=100?"⚠️ MARGINAL":"❌ NOT PROFITABLE"}
              </div>
            </div>
            {[{l:"Shipper Rate",v:`$${Number(f.shipperRate).toLocaleString()}`,c:C.green},{l:"Carrier Cost",v:`-$${Number(f.carrierRate).toLocaleString()}`,c:C.red},{l:"Gross Margin",v:`$${gross.toLocaleString()}`,c:C.gold,b:true},{l:"Expenses",v:`-$${exp.toLocaleString()}`,c:C.orange},{l:"Net Margin",v:`$${net.toLocaleString()}`,c:col,b:true}].map((r,i)=>(
              <div key={i} style={{display:"flex",justifyContent:"space-between",padding:"8px 0",borderBottom:i<4?`1px solid ${C.border}`:"none"}}>
                <span style={{fontSize:12,color:C.muted}}>{r.l}</span>
                <span style={{fontSize:13,color:r.c,fontWeight:r.b?900:600}}>{r.v}</span>
              </div>
            ))}
          </Card>
          <Card style={{padding:16}}>
            <div style={{color:C.muted,fontSize:11,textTransform:"uppercase",letterSpacing:"0.5px",marginBottom:10}}>Benchmarks</div>
            {[{l:"Excellent (15%+)",good:Number(pct)>=15},{l:"Good (10-15%)",good:Number(pct)>=10},{l:"Viable (5-10%)",good:Number(pct)>=5},{l:`Your margin: ${pct}%`,good:Number(pct)>=10,hi:true}].map((r,i)=>(
              <div key={i} style={{display:"flex",justifyContent:"space-between",padding:"6px 0",borderBottom:i<3?`1px solid ${C.border}`:"none"}}>
                <span style={{fontSize:12,color:r.hi?C.text:C.muted,fontWeight:r.hi?700:400}}>{r.l}</span>
                <span style={{fontSize:12,color:r.good?C.green:C.red,fontWeight:700}}>{r.good?"✓":"✗"}</span>
              </div>
            ))}
          </Card>
          <PrimaryBtn onClick={save} style={{width:"100%",justifyContent:"center"}}>💾 Save Calculation</PrimaryBtn>
        </div>
      </div>
      <Card>
        <div style={{padding:"10px 18px",borderBottom:`1px solid ${C.border}`,color:C.muted,fontSize:11,textTransform:"uppercase",letterSpacing:"0.5px"}}>Saved Calculations</div>
        <div style={{display:"grid",gridTemplateColumns:"90px 1fr 80px 80px 70px 70px 70px 70px",padding:"9px 18px",borderBottom:`1px solid ${C.border}`}}>
          {["Load","Route","Shipper","Carrier","Gross","Net","Margin","Date"].map((h,i)=><div key={i} style={{fontSize:10,color:C.muted,textTransform:"uppercase",letterSpacing:"0.5px",fontWeight:700}}>{h}</div>)}
        </div>
        {history.map((h,i)=>{
          const mc=parseFloat(h.pct);
          const hc=mc>=15?C.green:mc>=10?C.gold:mc>=5?C.orange:C.red;
          return(
            <div key={h.id} style={{display:"grid",gridTemplateColumns:"90px 1fr 80px 80px 70px 70px 70px 70px",padding:"11px 18px",alignItems:"center",borderBottom:i<history.length-1?`1px solid ${C.border}`:"none"}}>
              <div style={{color:C.accent,fontSize:12,fontWeight:700}}>{h.load}</div>
              <div style={{color:C.text,fontSize:12}}>{h.route}</div>
              <div style={{color:C.green,fontSize:12,fontWeight:700}}>${h.shipper.toLocaleString()}</div>
              <div style={{color:C.red,fontSize:12}}>${h.carrier.toLocaleString()}</div>
              <div style={{color:C.gold,fontSize:12,fontWeight:700}}>${h.gross}</div>
              <div style={{color:hc,fontSize:12,fontWeight:700}}>${h.net}</div>
              <div style={{color:hc,fontSize:12,fontWeight:900}}>{h.pct}</div>
              <div style={{color:C.muted,fontSize:11}}>{h.date}</div>
            </div>
          );
        })}
      </Card>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════
   AI SALES AGENTS — HUMAN WRITING ENGINE
══════════════════════════════════════════════════════════ */

const AI_MSGS = {
  alex:{
    cold:[(n,c)=>`Hey ${n}! 👋 Saw ${c} on LinkedIn and had to reach out — your growth story is seriously impressive. We move a ton of freight on TX→CA and I'm pretty sure we could save you real money. Who handles your shipping right now?`,(n,c)=>`${n}! Quick one — we specialize in FTL for companies like ${c} and I think there's a great fit here. Open to a 10 min call this week?`,(n,c)=>`Hey ${n}, Alex here from FreightCRM. Came across ${c} while researching TX manufacturers. We've got killer rates on your lanes right now — worth a quick chat?`],
    followup:[(n)=>`Hey ${n}! Just checking back in — no worries if timing's been off, totally get it 😅 Still think we could save you some serious cash on freight. Worth 5 mins?`,(n)=>`${n}! Not trying to be annoying lol but I genuinely think we can help. Our rates on your lanes are ~15% below market. Worth a look?`,(n)=>`Hey! Last try, promise 😂 If freight's not a priority right now totally fine. Just drop me a note if timing changes. Take care!`],
    rate:[(n)=>`Ok so real talk ${n} — looking at our carrier network right now and I can get you $1,850 on that lane. Honestly one of our best rates. What's your current broker charging?`,(n)=>`${n} between us — I've got a carrier running that exact lane every Tuesday who needs loads. Passing the savings to you. We're talking $200-300 cheaper per load 👀`],
    objection:[(n)=>`Fair enough ${n} — $200 is real money! Here's the thing: how many times has your current broker left you scrambling last minute? We've never missed a pickup in 3 years. What's the cost of ONE missed load vs $200 extra? Happy to do a trial load — let the service speak.`,(n)=>`Ok ok I hear you ${n}. What if we do a trial load, see how it goes, then lock in rates based on volume? Confident once you see how smooth we run it, price won't be a question.`],
    close:[(n,c)=>`${n} this is AWESOME!! Sending the agreement right now 🎉 Ops team will be in touch tomorrow. SO pumped to work with ${c}! 🚛`,(n)=>`YES!! Welcome to the family ${n}! Agreement is on its way. Seriously stoked — you're gonna love our team 🙌`],
  },
  sara:{
    cold:[(n,c)=>`Hi ${n}! Hope your week's going well 😊 I'm Sara from FreightCRM — I work with logistics teams and would love to learn how ${c} handles freight. Do you have 10 minutes sometime?`,(n,c)=>`Hey ${n}! I came across ${c} and was genuinely impressed by what you all are doing. Mind if I ask — what's your biggest headache with freight right now?`],
    followup:[(n)=>`Hi ${n}! Just following up on my note 😊 I know your inbox is probably overflowing — mine always is 😅 No pressure at all, just let me know if you'd like to chat!`,(n)=>`Hey ${n}! Checking in — did you get a chance to look at what I sent? I just put together a rate comparison for your main lanes that I think you'll find really interesting. Want me to send it?`],
    proposal:[(n)=>`${n}! Ok so I've been putting something special together and I'm honestly really excited 🙌 I've got a proposal that I think is going to blow your current broker out of the water. Quick call to walk through it?`],
    objection:[(n)=>`I totally hear you ${n}! Price is always the thing, right? Here's what I can do — start with 6 loads and I'll go down another $75/load AND throw in dedicated tracking. Once you see how we operate, this becomes a no-brainer. Can we try one load to start?`],
    close:[(n,c)=>`YES ${n} this literally made my whole week!! 🎉 Agreement going to your inbox RIGHT NOW. I'll personally be your point of contact — reach me anytime, seriously even weekends 😊 Welcome welcome welcome!!`,(n)=>`OH this is the best news! Thank you so much for trusting us ${n} — we are going to take such good care of you 💙 Sending everything over now!`],
    nurture:[(n,c)=>`${n}! Just thinking about our last conversation and wanted to check in 😊 How did Q1 go for ${c}? I have some news on capacity for your lanes that I think you'll love 👀`],
  },
  mike:{
    cold:[(n,c)=>`Hey ${n}, Mike from FreightCRM. Quick question — looking for carriers in Southeast right now? Just vetted 3 new ones with great safety ratings on your lanes. Happy to share details.`,(n,c)=>`Hi ${n}, I'll cut to the chase — need flatbed capacity TX→CA next week. I see ${c} runs that corridor. Availability and rate?`],
    followup:[(n)=>`Hey ${n}, following up from last week. Still have that capacity need on TX→CA. Running loads that direction?`],
    rate:[(n)=>`${n} what rate works for you? Give me a number and I'll see what I can do.`],
    close:[(n)=>`Perfect ${n}, let's do it. Sending rate confirmation now. Looking forward to working together.`],
    objection:[(n)=>`Understood ${n}. What number would make this work on your end?`],
  },
  dana:{
    cold:[(n,c)=>`Hi ${n}! Dana here 😊 So I noticed ${c} is shipping partial loads — which is totally fine! — but I think we could save you money by consolidating. Pretty simple change. Want me to run the numbers?`,(n,c)=>`Hey ${n}! Quick question about your LTL freight — are you getting volume discounts? We've been helping companies save 20-30% on partial loads. Worth a look?`],
    followup:[(n)=>`Hi ${n}! Just checking in from last week 😊 Did you get a chance to look at the LTL options? I think there's real savings there.`],
    close:[(n)=>`${n} amazing!! So excited to help you save on those partial loads 🎉 Let me get the paperwork started!`],
    objection:[(n)=>`I totally get that ${n} — change is always a bit daunting! What if we just start with one consolidation and see what happens? Worst case you're exactly where you are now 😊`],
  },
};

const getAIMsg=(agentId,type,contactName,company)=>{
  const first=contactName?.split(" ")[0]||"there";
  const co=company||"your company";
  const pool=AI_MSGS[agentId]?.[type]||AI_MSGS[agentId]?.cold||AI_MSGS.alex.cold;
  const fn=pool[Math.floor(Math.random()*pool.length)];
  return typeof fn==="function"?fn(first,co):fn;
};

const AI_AGENTS_DATA=[
  {id:"alex",name:"Alex Rivera",role:"Outbound Hunter",color:"#00c2ff",status:"Active",loadsBooked:14,leadsFound:87,convRate:"16%",todayFound:12,dailyGoal:20,trainingLevel:84,style:"Casual & direct. Humor, emoji, abbreviations. Feels like texting a friend who knows freight.",sample:'Hey Ron! 👋 Saw TechParts on LinkedIn — your expansion story is seriously impressive. Quick question: who handles your shipping right now?',task:"DMing 8 manufacturers on LinkedIn..."},
  {id:"sara",name:"Sara Chen",role:"Relationship Manager",color:"#a78bfa",status:"Active",loadsBooked:22,leadsFound:45,convRate:"31%",todayFound:8,dailyGoal:15,trainingLevel:91,style:"Warm & empathetic. Exclamation marks, emoji, personal. Like a colleague you really like.",sample:"Hi! Hope your week's going well 😊 I was thinking about you — how did that big shipment go? Also I have exciting news...",task:"Following up with GlobalTech — warming up nicely..."},
  {id:"mike",name:"Mike Torres",role:"Carrier Scout",color:"#2dd4bf",status:"Active",loadsBooked:31,leadsFound:63,convRate:"24%",todayFound:7,dailyGoal:10,trainingLevel:78,style:"Professional but human. Gets to the point. Straight-talking colleague.",sample:"Hey, Mike from FreightCRM. I'll cut to the chase — need flatbed TX→CA next week. You run that lane. Interested?",task:"Vetting 3 new carriers in Southeast..."},
  {id:"dana",name:"Dana Kim",role:"LTL Specialist",color:"#f0b429",status:"Paused",loadsBooked:8,leadsFound:34,convRate:"18%",todayFound:0,dailyGoal:12,trainingLevel:72,style:"Friendly & detail-oriented. Explains clearly. Like a knowledgeable friend.",sample:"Hi! So I noticed you're shipping partial loads — totally fine! — but I think we could save you money. Want me to run the numbers?",task:"Paused — waiting for territory assignment."},
];

const AI_LEADS_DATA=[
  {id:1,agentId:"alex",company:"TechParts USA",contact:"Ron Mitchell",title:"VP Operations",volume:"20 loads/mo",location:"Dallas TX",stage:"contact",score:82,notes:"Opened 3 emails. Replied once about lanes."},
  {id:2,agentId:"sara",company:"BuildRight LLC",contact:"James Ford",title:"COO",volume:"15 loads/mo",location:"Houston TX",stage:"proposal",score:91,notes:"Ready to sign. $1,750 rate negotiated."},
  {id:3,agentId:"alex",company:"SunFarm Produce",contact:"Lisa Huang",title:"Logistics Mgr",volume:"8 loads/mo",location:"Fresno CA",stage:"qualified",score:74,notes:"Interested in reefer. Budget confirmed."},
  {id:4,agentId:"sara",company:"RetailFlow Inc",contact:"Sandra Ortiz",title:"Dir. Logistics",volume:"30 loads/mo",location:"Atlanta GA",stage:"proposal",score:94,notes:"Referral from Jake. Proposal sent."},
  {id:5,agentId:"mike",company:"SpeedHaul Carriers",contact:"Derek Bass",title:"Dispatch Mgr",volume:"50 trucks",location:"Phoenix AZ",stage:"qualified",score:88,notes:"Passed compliance. Southwest coverage."},
];

const AI_INIT_CONVOS={
  1:[{id:1,from:"agent",name:"Alex",text:"Hey Ron! 👋 Saw TechParts on LinkedIn and had to reach out — your expansion story is seriously impressive. We move a ton of freight on TX→Midwest and I'm pretty sure we could save you real money. Who handles your shipping right now?",time:"Mon 9:14 AM"},{id:2,from:"lead",name:"Ron",text:"Hi Alex, we use a broker but always open to better rates. What lanes do you cover?",time:"Mon 9:32 AM"},{id:3,from:"agent",name:"Alex",text:"We're strong on TX→Midwest, TX→CA, and Southeast. Real talk — for manufacturing freight we typically come in 12-18% below market. What's your current rate on Dallas→Chicago? (no pressure, just curious 😅)",time:"Mon 9:35 AM"},{id:4,from:"lead",name:"Ron",text:"Around $2,200/load. We run about 5 loads a week on that lane.",time:"Mon 10:02 AM"},{id:5,from:"agent",name:"Alex",text:"Ok so that's ~$550K/year on that lane alone 👀 I'm confident we can get you under $1,950. Worth a 15 min call this week just to see the numbers? Worst case you confirm your broker's giving you a good deal lol",time:"Mon 10:05 AM"}],
  2:[{id:1,from:"agent",name:"Sara",text:"Hi James! Hope Q1 treated you well 😊 I've been putting something special together for BuildRight and I'm honestly really excited. Did a deep dive on your Houston→Southeast lanes and the numbers are... kind of wild. Can we do a quick call?",time:"Tue 2:00 PM"},{id:2,from:"lead",name:"James",text:"Sure. What rates are you thinking? Current broker has us at $1,800 Houston to Miami.",time:"Tue 2:45 PM"},{id:3,from:"agent",name:"Sara",text:"Ok I love that you're direct, me too! I can do $1,750 on that lane at 8 loads/month minimum. That's $50 less per load = $400/month = $4,800/year just on Miami. AND I'll throw in dedicated tracking and my personal number. No call centers, ever. Does that work? 🙌",time:"Tue 2:48 PM"},{id:4,from:"lead",name:"James",text:"That works. Send the agreement and we'll sign this week.",time:"Tue 3:15 PM"},{id:5,from:"agent",name:"Sara",text:"YES!! James this literally made my whole week 🎉 Agreement going to j.ford@buildright.com RIGHT NOW! Onboarding team (Tom and Maria, both amazing) will reach out tomorrow. So SO excited to work with BuildRight! 😊",time:"Tue 3:17 PM"}],
  4:[{id:1,from:"agent",name:"Sara",text:"Hi Sandra! 😊 Jake Morrison mentioned you — he had nothing but great things to say about RetailFlow. I'd love to learn about your freight setup. Is this a good time?",time:"Wed 10:00 AM"},{id:2,from:"lead",name:"Sandra",text:"Yes hi! We ship about 30 loads a month, mainly dry van Midwest and Southeast.",time:"Wed 10:22 AM"},{id:3,from:"agent",name:"Sara",text:"30 loads is great! Atlanta→Chicago at $1,650, Atlanta→Dallas at $1,900. That's 10-15% below what most brokers charge right now. Want me to put together a full rate sheet?",time:"Wed 10:25 AM"},{id:4,from:"lead",name:"Sandra",text:"Yes please. We're looking to switch by May 1.",time:"Wed 10:40 AM"}],
};

const AI_LESSONS=[
  {id:1,icon:"❄️",title:"Opening a cold conversation",time:"2 min",scenario:"New lead: Tom Bradley, VP at SteelWorks USA, Houston. Ships 20 loads/month TX→CA. First contact.",robot:"Hello Tom Bradley. I am reaching out to inform you that FreightCRM offers freight brokerage services. We have carriers available on the TX to CA lane. Would you like to schedule a meeting to discuss your logistics requirements?",human:"Hey Tom! 👋 Saw SteelWorks on LinkedIn and couldn't help myself — we move a ton of steel-related freight on TX→CA and I think we could do something cool together. Quick question: who's handling your freight right now?",why:"The human version uses a personal opener, references their specific business, sounds genuinely excited (not scripted), and asks just ONE easy question. No pitch. It feels like a real person reached out, not a sales bot."},
  {id:2,icon:"👻",title:"Following up after no reply",time:"2 min",scenario:"5 days since first email to Lisa Huang at FreshFarm. No reply. She opened it twice.",robot:"Dear Lisa Huang, I am following up on my previous email regarding freight brokerage services. I would like to schedule a call at your earliest convenience.",human:"Hey Lisa! Not trying to be a pest lol but I saw you opened my message a couple times — figured timing might have been off 😅 No worries if it's not the right time — just reply 'not now' and I'll circle back in Q3. But if reefer capacity from Fresno is still a thing, I've got something good for you 👀",why:"Acknowledges the awkwardness with humor. Gives them an easy out (which paradoxically increases replies). References specific context. Creates curiosity without desperation. Gets 3x more replies than the corporate version."},
  {id:3,icon:"💰",title:"Handling a price objection",time:"3 min",scenario:"Derek says: 'Your rate is $200 more than our current broker.'",robot:"I understand your concern regarding pricing. However, FreightCRM offers competitive rates with value-added services including real-time tracking and 24/7 support which justify the price difference.",human:"Fair enough Derek — $200 is real money! Here's the thing: how many times has your current broker left you scrambling last minute? We've never missed a pickup in 3 years. What's the cost of ONE missed load vs $200 extra? Happy to do a trial load — let the service speak for itself.",why:"Validates the objection first (never argue). Reframes around pain (missed pickups). Uses a rhetorical question to make them think. Offers a low-risk trial instead of pushing for commitment."},
  {id:4,icon:"🌱",title:"Nurturing a warm lead",time:"2 min",scenario:"Sandra at RetailFlow opened your proposal 4 days ago. No reply. She seemed very interested.",robot:"Dear Sandra, I am following up on the proposal I sent. Please let me know if you have any questions or require additional information. I look forward to your response.",human:"Hey Sandra! 😊 Hope you had a good week! Did the proposal make sense? Happy to walk through any of it. Also totally random but I saw RetailFlow mentioned in a trade article yesterday — congrats on the Atlanta expansion! That's actually exactly why I think the timing on this could be really good for you 👀",why:"Feels like a real check-in, not a sales follow-up. Shows genuine research on the company. Connects news to why timing is right — without being pushy. Makes Sandra feel like a person, not a lead."},
  {id:5,icon:"🤝",title:"Closing the deal",time:"2 min",scenario:"James from BuildRight agrees to your rate and says he'll sign this week.",robot:"Thank you for your decision James. I will send the agreement to your email. Our team will contact you to begin the onboarding process. We appreciate your business.",human:"YES!! Ok James this literally made my whole week 🎉 Agreement going to j.ford@buildright.com RIGHT NOW — sending as we speak! Our onboarding team (Tom and Maria, both super helpful) will reach out tomorrow morning. So SO excited to work with BuildRight! You're going to love us 😊",why:"Genuine excitement is contagious and confirms they made the right choice. Mentions specific names (makes it personal). 'Sending as we speak' = no delays. Warmth that builds loyalty from day one."},
];

function AILessonView({lesson,onBack}){
  const [choice,setChoice]=useState(null);
  return(
    <div>
      <button onClick={onBack} style={{background:"none",border:"none",color:C.muted,cursor:"pointer",fontSize:13,marginBottom:20,display:"flex",alignItems:"center",gap:6,fontFamily:"inherit"}}>← Back to lessons</button>
      <div style={{color:C.text,fontWeight:800,fontSize:18,marginBottom:4}}>{lesson.icon} {lesson.title}</div>
      <div style={{padding:"12px 16px",background:`${C.gold}0d`,border:`1px solid ${C.gold}22`,borderRadius:10,marginBottom:24,fontSize:13,color:C.muted,lineHeight:1.6}}><strong style={{color:C.gold}}>📋 Scenario: </strong>{lesson.scenario}</div>
      <div style={{color:C.muted,fontSize:11,textTransform:"uppercase",letterSpacing:"0.5px",marginBottom:12}}>Which message would YOU send?</div>
      {[{key:"robot",label:"Option A — Corporate Style",text:lesson.robot,good:false},{key:"human",label:"Option B — Human Style",text:lesson.human,good:true}].map(opt=>(
        <div key={opt.key} onClick={()=>!choice&&setChoice(opt.key)} style={{padding:18,borderRadius:12,marginBottom:12,border:`2px solid ${choice===opt.key?opt.good?C.green:C.red:choice&&opt.good?C.green:C.border}`,background:choice===opt.key?opt.good?`${C.green}08`:`${C.red}08`:choice&&opt.good?`${C.green}05`:"rgba(255,255,255,0.02)",cursor:choice?"default":"pointer",transition:"all 0.2s"}}>
          <div style={{display:"flex",justifyContent:"space-between",marginBottom:10}}>
            <span style={{fontSize:12,fontWeight:700,color:choice?opt.good?C.green:opt.key===choice?C.red:C.muted:C.muted}}>{opt.label}</span>
            {choice&&<span style={{fontSize:18}}>{opt.good?"✅":"❌"}</span>}
          </div>
          <div style={{fontSize:13,color:C.text,lineHeight:1.7}}>{opt.text}</div>
        </div>
      ))}
      {choice&&(
        <div style={{padding:20,background:`${C.green}0d`,border:`1px solid ${C.green}22`,borderRadius:12}}>
          <div style={{color:C.green,fontWeight:800,fontSize:15,marginBottom:10}}>{choice==="human"?"🎉 Correct! Here's why:":"💡 Option B was better. Here's why:"}</div>
          <div style={{fontSize:13,color:C.muted,lineHeight:1.8,marginBottom:16}}>{lesson.why}</div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
            <div style={{padding:"12px 14px",background:`${C.red}0a`,border:`1px solid ${C.red}22`,borderRadius:9}}>
              <div style={{fontSize:11,color:C.red,fontWeight:700,marginBottom:8}}>❌ Corporate says...</div>
              {["'I am reaching out to inform you'","'At your earliest convenience'","Long formal sentences","No personality, no context"].map((t,i)=><div key={i} style={{fontSize:12,color:C.muted,marginBottom:4,textDecoration:"line-through"}}>• {t}</div>)}
            </div>
            <div style={{padding:"12px 14px",background:`${C.green}0a`,border:`1px solid ${C.green}22`,borderRadius:9}}>
              <div style={{fontSize:11,color:C.green,fontWeight:700,marginBottom:8}}>✅ Human says...</div>
              {["'Hey! Just saw you on...'","'Quick 10 min call this week?'","Short, punchy, conversational","Emoji, humor, specific context"].map((t,i)=><div key={i} style={{fontSize:12,color:C.text,marginBottom:4}}>• {t}</div>)}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function AIAgentsPage(){
  const [agents,setAgents]=useState(AI_AGENTS_DATA);
  const [leads]=useState(AI_LEADS_DATA);
  const [convos,setConvos]=useState(AI_INIT_CONVOS);
  const [selAgent,setSelAgent]=useState(AI_AGENTS_DATA[0]);
  const [selLead,setSelLead]=useState(null);
  const [agentTab,setAgentTab]=useState("agents");
  const [trainTab,setTrainTab]=useState("lessons");
  const [selLesson,setSelLesson]=useState(null);
  const [input,setInput]=useState("");
  const [typing,setTyping]=useState(false);
  const [showCreate,setShowCreate]=useState(false);
  const [newA,setNewA]=useState({name:"",role:"Outbound Hunter",focus:"Shippers"});
  const [liveLog,setLiveLog]=useState([
    {id:1,text:"Alex AI sent cold DM to SteelWorks Manufacturing, Houston TX",color:"#00c2ff",time:"just now"},
    {id:2,text:"Sara AI moved BuildRight LLC to Proposal stage 🎉",color:"#a78bfa",time:"2 min ago"},
    {id:3,text:"Mike AI verified SpeedHaul Carriers — passed compliance",color:"#2dd4bf",time:"4 min ago"},
    {id:4,text:"Alex AI followed up with SunFarm Produce — 3rd touch",color:"#00c2ff",time:"6 min ago"},
  ]);
  const [pulse,setPulse]=useState(false);
  const bottomRef=useRef();
  const inputRef=useRef();

  useEffect(()=>{const t=setInterval(()=>setPulse(p=>!p),2000);return()=>clearInterval(t);},[]);

  useEffect(()=>{
    const evs=[
      {text:"Alex AI found new lead: Pacific Logistics LLC, Los Angeles CA",color:"#00c2ff"},
      {text:"Sara AI scheduled call with RetailFlow for Thursday 2pm 📅",color:"#a78bfa"},
      {text:"Alex AI sent rate quote to TechParts USA ($1,950/load)",color:"#00c2ff"},
      {text:"Mike AI negotiated $2.05/mi with new carrier — Southwest",color:"#2dd4bf"},
      {text:"Sara AI sent warm check-in to 4 leads — 2 replied! 🎯",color:"#a78bfa"},
      {text:"Alex AI cold emailed 12 TX manufacturers — 28% open rate",color:"#00c2ff"},
      {text:"Mike AI completed compliance check on 3 new carriers ✅",color:"#2dd4bf"},
      {text:"Dana AI found LTL consolidation opportunity — saving $340",color:"#f0b429"},
    ];
    const t=setInterval(()=>{const ev=evs[Math.floor(Math.random()*evs.length)];setLiveLog(prev=>[{id:Date.now(),...ev,time:"just now"},...prev.slice(0,9)]);},6000);
    return()=>clearInterval(t);
  },[]);

  useEffect(()=>{bottomRef.current?.scrollIntoView({behavior:"smooth"});},[convos,typing,selLead]);

  const toggleAgent=id=>setAgents(prev=>prev.map(a=>a.id===id?{...a,status:a.status==="Active"?"Paused":"Active"}:a));
  const curAgent=selLead?agents.find(a=>a.id===selLead.agentId)||selAgent:selAgent;
  const agentMsgs=selLead?(convos[selLead.id]||[]):[];
  const stageColor={prospect:C.muted,contact:C.accent,qualified:C.purple,proposal:C.gold};
  const totalLeads=agents.reduce((s,a)=>s+a.leadsFound,0);
  const totalBooked=agents.reduce((s,a)=>s+a.loadsBooked,0);

  const sendMsg=msg=>{
    if(!msg.trim()||!selLead)return;
    const ag=agents.find(a=>a.id===selLead.agentId);
    setConvos(prev=>({...prev,[selLead.id]:[...(prev[selLead.id]||[]),{id:Date.now(),from:"agent",name:ag?.name.split(" ")[0]||"Agent",text:msg,time:"Now"}]}));
    setInput("");setTyping(true);
    setTimeout(()=>{
      setTyping(false);
      const rs=["Got it, let me check with my team.","That sounds reasonable — can you send more details?","We'd need to see the rate sheet first.","Actually that's better than what we're paying.","Let me think and get back to you.","Yeah a call works. How's Thursday at 2pm?","Hmm interesting. What's included in that rate?","Ok send the paperwork — sounds good!"];
      setConvos(prev=>({...prev,[selLead.id]:[...(prev[selLead.id]||[]),{id:Date.now()+1,from:"lead",name:selLead.contact.split(" ")[0],text:rs[Math.floor(Math.random()*rs.length)],time:"Now"}]}));
    },1800+Math.random()*2500);
  };

  const QUICK_BTNS=[{label:"☕ Casual follow-up",type:"followup"},{label:"💰 Rate quote",type:"rate"},{label:"😅 After no reply",type:"followup"},{label:"🤝 Handle objection",type:"objection"},{label:"🎉 Close deal!",type:"close"},{label:"❄️ Cold opener",type:"cold"}];

  return(
    <div>
      <style>{`@keyframes agblink{0%,100%{opacity:1}50%{opacity:0.2}}`}</style>
      {/* Header */}
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:16}}>
        <div>
          <h2 style={{color:C.text,fontSize:20,fontWeight:900,margin:"0 0 3px"}}>🤖 AI Sales Agents</h2>
          <p style={{color:C.muted,margin:0,fontSize:12}}>Agents trained to write like humans · find leads · close deals 24/7</p>
        </div>
        <div style={{display:"flex",gap:10,alignItems:"center"}}>
          <div style={{padding:"7px 14px",background:`${C.green}15`,border:`1px solid ${C.green}33`,borderRadius:8,fontSize:12,color:C.green,fontWeight:700}}>🟢 {agents.filter(a=>a.status==="Active").length} running</div>
          <PrimaryBtn onClick={()=>setShowCreate(true)}>+ New Agent</PrimaryBtn>
        </div>
      </div>

      {/* Live ticker */}
      <div style={{padding:"8px 14px",background:C.dim,borderRadius:9,marginBottom:16,display:"flex",gap:8,alignItems:"center"}}>
        <span style={{fontSize:10,color:C.muted,flexShrink:0,textTransform:"uppercase",letterSpacing:"0.5px"}}>⚡ Live:</span>
        <div style={{fontSize:11,color:liveLog[0]?.color||C.accent,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{liveLog[0]?.text}</div>
        <span style={{fontSize:10,color:C.muted,flexShrink:0,marginLeft:"auto"}}>{liveLog[0]?.time}</span>
      </div>

      {/* KPIs */}
      <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:12,marginBottom:18}}>
        {[{l:"Leads Found",v:totalLeads,c:C.accent,e:"🔍"},{l:"Loads Booked",v:totalBooked,c:C.green,e:"🚛"},{l:"Active Convos",v:leads.length,c:C.purple,e:"💬"},{l:"Pipeline",v:"$128K/mo",c:C.gold,e:"💰"}].map((k,i)=>(
          <Card key={i} style={{padding:"14px 16px"}}><div style={{fontSize:18,marginBottom:6}}>{k.e}</div><div style={{fontSize:24,fontWeight:900,color:k.c}}>{k.v}</div><div style={{fontSize:11,color:C.muted,marginTop:2}}>{k.l}</div></Card>
        ))}
      </div>

      {/* Tabs */}
      <div style={{display:"flex",gap:0,marginBottom:18,background:C.surface,borderRadius:10,padding:4,width:"fit-content"}}>
        {[{k:"agents",l:"🤖 Agents"},{k:"conversations",l:"💬 Conversations"},{k:"training",l:"🎓 Training"},{k:"activity",l:"⚡ Activity"}].map(t=>(
          <button key={t.k} onClick={()=>setAgentTab(t.k)} style={{padding:"7px 16px",borderRadius:8,border:"none",background:agentTab===t.k?C.card:"transparent",color:agentTab===t.k?C.text:C.muted,fontSize:12,cursor:"pointer",fontFamily:"inherit",fontWeight:agentTab===t.k?700:400}}>{t.l}</button>
        ))}
      </div>

      {/* AGENTS TAB */}
      {agentTab==="agents"&&(
        <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(270px,1fr))",gap:14}}>
          {agents.map(a=>(
            <Card key={a.id} style={{padding:20,cursor:"pointer",border:`1px solid ${selAgent?.id===a.id?a.color:C.border}`,background:selAgent?.id===a.id?`${a.color}08`:C.card,transition:"all 0.2s",position:"relative",overflow:"hidden"}} onClick={()=>setSelAgent(a)}>
              <div style={{position:"absolute",top:-20,right:-20,width:80,height:80,borderRadius:"50%",background:a.color,opacity:0.06}}/>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:12}}>
                <div style={{display:"flex",gap:10,alignItems:"center"}}>
                  <div style={{width:44,height:44,borderRadius:12,background:`${a.color}18`,border:`2px solid ${a.color}44`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:18,position:"relative",flexShrink:0}}>
                    🤖{a.status==="Active"&&<div style={{position:"absolute",bottom:0,right:0,width:11,height:11,borderRadius:"50%",background:C.green,border:`2px solid ${C.card}`,boxShadow:`0 0 ${pulse?8:3}px ${C.green}`,transition:"box-shadow 0.5s"}}/>}
                  </div>
                  <div><div style={{color:C.text,fontWeight:800,fontSize:13}}>{a.name}</div><div style={{color:a.color,fontSize:11,fontWeight:600}}>{a.role}</div></div>
                </div>
                <Badge label={a.status}/>
              </div>
              <div style={{padding:"8px 10px",background:"rgba(255,255,255,0.03)",borderRadius:8,marginBottom:10,fontSize:11,color:C.muted,fontStyle:"italic",lineHeight:1.5,borderLeft:`3px solid ${a.color}55`}}>"{a.sample.slice(0,85)}..."</div>
              <div style={{marginBottom:10}}>
                <div style={{display:"flex",justifyContent:"space-between",marginBottom:4}}><span style={{fontSize:11,color:C.muted}}>Human Score</span><span style={{fontSize:11,color:a.color,fontWeight:700}}>{a.trainingLevel}%</span></div>
                <div style={{height:5,background:C.dim,borderRadius:3}}><div style={{width:`${a.trainingLevel}%`,height:"100%",background:a.color,borderRadius:3}}/></div>
              </div>
              <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:6,marginBottom:10}}>
                {[{l:"Leads",v:a.leadsFound,c:a.color},{l:"Booked",v:a.loadsBooked,c:C.green},{l:"Conv.",v:a.convRate,c:C.gold}].map((s,i)=>(
                  <div key={i} style={{textAlign:"center",padding:"7px 4px",background:"rgba(255,255,255,0.03)",borderRadius:7}}>
                    <div style={{fontSize:16,fontWeight:900,color:s.c}}>{s.v}</div>
                    <div style={{fontSize:10,color:C.muted}}>{s.l}</div>
                  </div>
                ))}
              </div>
              {a.status==="Active"&&<div style={{fontSize:10,color:a.color,marginBottom:10,padding:"5px 9px",background:`${a.color}0d`,borderRadius:6,display:"flex",gap:5,alignItems:"center"}}><span style={{animation:"agblink 1.5s infinite"}}>●</span>{a.task}</div>}
              <button onClick={e=>{e.stopPropagation();toggleAgent(a.id);}} style={{width:"100%",padding:"7px",borderRadius:8,border:`1px solid ${a.status==="Active"?C.orange:C.green}44`,background:`${a.status==="Active"?C.orange:C.green}15`,color:a.status==="Active"?C.orange:C.green,cursor:"pointer",fontSize:12,fontWeight:700,fontFamily:"inherit"}}>
                {a.status==="Active"?"⏸ Pause Agent":"▶ Activate Agent"}
              </button>
            </Card>
          ))}
        </div>
      )}

      {/* CONVERSATIONS TAB */}
      {agentTab==="conversations"&&(
        <div style={{display:"grid",gridTemplateColumns:"250px 1fr",gap:14,height:560}}>
          <div style={{background:C.surface,border:`1px solid ${C.border}`,borderRadius:13,overflow:"hidden",display:"flex",flexDirection:"column"}}>
            <div style={{padding:"10px 14px",borderBottom:`1px solid ${C.border}`,fontSize:11,color:C.muted,fontWeight:700,textTransform:"uppercase",letterSpacing:"0.5px"}}>Active Leads</div>
            <div style={{overflowY:"auto",flex:1}}>
              {leads.map(lead=>{
                const ag=agents.find(a=>a.id===lead.agentId);
                const lastMsg=(convos[lead.id]||[]).slice(-1)[0];
                const isSel=selLead?.id===lead.id;
                return(
                  <div key={lead.id} onClick={()=>setSelLead(lead)} style={{padding:"11px 14px",borderBottom:`1px solid ${C.border}`,background:isSel?`${ag?.color||C.accent}12`:"transparent",cursor:"pointer",borderLeft:`3px solid ${isSel?ag?.color||C.accent:"transparent"}`,transition:"all 0.15s"}}>
                    <div style={{display:"flex",justifyContent:"space-between",marginBottom:3}}>
                      <div style={{color:C.text,fontSize:12,fontWeight:700,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{lead.contact.split(" ")[0]}</div>
                      <Badge label={lead.stage} color={stageColor[lead.stage]}/>
                    </div>
                    <div style={{color:C.muted,fontSize:11,marginBottom:2}}>{lead.company}</div>
                    {lastMsg&&<div style={{fontSize:10,color:C.muted,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{lastMsg.from==="agent"?"🤖":"👤"} {lastMsg.text.slice(0,40)}...</div>}
                    <div style={{fontSize:10,color:ag?.color||C.accent,marginTop:3,fontWeight:600}}>via {ag?.name.split(" ")[0]||"AI"} AI</div>
                  </div>
                );
              })}
            </div>
          </div>

          {selLead?(
            <div style={{display:"flex",flexDirection:"column",background:C.card,border:`1px solid ${C.border}`,borderRadius:13,overflow:"hidden"}}>
              <div style={{padding:"12px 16px",borderBottom:`1px solid ${C.border}`,display:"flex",gap:10,alignItems:"center",flexShrink:0}}>
                <div style={{width:36,height:36,borderRadius:10,background:`${curAgent.color}22`,color:curAgent.color,display:"flex",alignItems:"center",justifyContent:"center",fontSize:13,fontWeight:800,flexShrink:0}}>{selLead.contact.split(" ").map(n=>n[0]).join("")}</div>
                <div style={{flex:1}}>
                  <div style={{color:C.text,fontWeight:700,fontSize:13}}>{selLead.contact} <span style={{color:C.muted,fontWeight:400}}>· {selLead.company}</span></div>
                  <div style={{color:C.muted,fontSize:11}}>{selLead.title} · Score: <span style={{color:selLead.score>=85?C.green:selLead.score>=70?C.gold:C.orange,fontWeight:700}}>{selLead.score}</span></div>
                </div>
                <div style={{display:"flex",gap:5,alignItems:"center"}}>
                  <div style={{width:6,height:6,borderRadius:"50%",background:curAgent.color}}/>
                  <span style={{fontSize:11,color:curAgent.color,fontWeight:600}}>{curAgent.name.split(" ")[0]} AI</span>
                </div>
              </div>
              <div style={{flex:1,overflowY:"auto",padding:"14px",display:"flex",flexDirection:"column",gap:10}}>
                {agentMsgs.map((msg,i)=>{
                  const isAg=msg.from==="agent";
                  return(
                    <div key={msg.id||i} style={{display:"flex",flexDirection:isAg?"row":"row-reverse",gap:8,alignItems:"flex-end"}}>
                      {isAg&&<div style={{width:28,height:28,borderRadius:8,background:`${curAgent.color}22`,color:curAgent.color,display:"flex",alignItems:"center",justifyContent:"center",fontSize:12,flexShrink:0}}>🤖</div>}
                      <div style={{maxWidth:"70%"}}>
                        <div style={{padding:"9px 13px",borderRadius:isAg?"13px 13px 13px 4px":"13px 13px 4px 13px",background:isAg?"rgba(255,255,255,0.07)":`linear-gradient(135deg,${curAgent.color}cc,${curAgent.color}88)`,color:isAg?C.text:"#000",fontSize:12,lineHeight:1.6}}>{msg.text}</div>
                        <div style={{fontSize:10,color:C.muted,marginTop:3,textAlign:isAg?"left":"right"}}>{isAg?`${msg.name} (AI)`:"Lead"} · {msg.time}</div>
                      </div>
                    </div>
                  );
                })}
                {typing&&(
                  <div style={{display:"flex",gap:8,alignItems:"center"}}>
                    <div style={{width:28,height:28,borderRadius:8,background:"rgba(255,255,255,0.06)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:12}}>👤</div>
                    <div style={{background:"rgba(255,255,255,0.06)",borderRadius:"13px 13px 13px 4px",padding:"10px 14px",display:"flex",gap:4}}>
                      {[0,1,2].map(i=><div key={i} style={{width:6,height:6,borderRadius:"50%",background:C.muted,animation:`agblink 1.2s ease ${i*0.2}s infinite`}}/>)}
                    </div>
                  </div>
                )}
                <div ref={bottomRef}/>
              </div>
              <div style={{padding:"7px 14px",borderTop:`1px solid ${C.border}`,background:"rgba(0,0,0,0.15)"}}>
                <div style={{fontSize:10,color:C.muted,marginBottom:5,textTransform:"uppercase",letterSpacing:"0.5px"}}>✨ AI writes it human-style — click to send:</div>
                <div style={{display:"flex",gap:5,flexWrap:"wrap"}}>
                  {QUICK_BTNS.map(btn=>(
                    <button key={btn.label} onClick={()=>sendMsg(getAIMsg(curAgent.id,btn.type,selLead.contact,selLead.company))} style={{padding:"4px 10px",background:`${curAgent.color}12`,border:`1px solid ${curAgent.color}33`,borderRadius:20,color:curAgent.color,fontSize:10,cursor:"pointer",fontFamily:"inherit"}}>{btn.label}</button>
                  ))}
                </div>
              </div>
              <div style={{padding:"9px 14px 12px",borderTop:`1px solid ${C.border}`,display:"flex",gap:8}}>
                <div style={{flex:1,position:"relative"}}>
                  <textarea ref={inputRef} value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();sendMsg(input);}}}
                    placeholder={`Write as ${curAgent.name.split(" ")[0]}... or click AI quick replies above`}
                    style={{width:"100%",minHeight:40,maxHeight:100,padding:"9px 36px 9px 12px",background:"rgba(255,255,255,0.05)",border:`1px solid ${C.border}`,borderRadius:9,color:C.text,fontSize:12,outline:"none",resize:"none",boxSizing:"border-box",lineHeight:1.5,fontFamily:"inherit"}}/>
                  <button onClick={()=>{const m=getAIMsg(curAgent.id,"cold",selLead.contact,selLead.company);setInput(m);inputRef.current?.focus();}} style={{position:"absolute",right:6,bottom:6,width:24,height:24,borderRadius:6,background:`${curAgent.color}22`,border:"none",color:curAgent.color,cursor:"pointer",fontSize:10,fontWeight:700}} title="✨ AI suggest">✨</button>
                </div>
                <button onClick={()=>sendMsg(input)} disabled={!input.trim()} style={{width:40,height:40,alignSelf:"flex-end",borderRadius:9,background:input.trim()?`linear-gradient(135deg,${curAgent.color},${curAgent.color}88)`:"rgba(255,255,255,0.05)",border:"none",color:input.trim()?"#000":C.muted,cursor:input.trim()?"pointer":"default",fontSize:16,display:"flex",alignItems:"center",justifyContent:"center"}}>➤</button>
              </div>
            </div>
          ):(
            <div style={{display:"flex",alignItems:"center",justifyContent:"center",background:C.card,border:`1px solid ${C.border}`,borderRadius:13}}>
              <div style={{textAlign:"center",color:C.muted}}>
                <div style={{fontSize:36,marginBottom:10}}>💬</div>
                <div style={{fontSize:13}}>Select a lead to view conversation</div>
                <div style={{fontSize:11,marginTop:4}}>Your AI agents are managing all these chats</div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TRAINING TAB */}
      {agentTab==="training"&&(
        <div>
          <div style={{display:"flex",gap:0,marginBottom:18,background:C.surface,borderRadius:10,padding:4,width:"fit-content"}}>
            {[{k:"lessons",l:"📚 Lessons"},{k:"styles",l:"🎭 Agent Voices"},{k:"compare",l:"🔄 Before & After"}].map(t=>(
              <button key={t.k} onClick={()=>{setTrainTab(t.k);setSelLesson(null);}} style={{padding:"7px 14px",borderRadius:8,border:"none",background:trainTab===t.k?C.card:"transparent",color:trainTab===t.k?C.text:C.muted,fontSize:12,cursor:"pointer",fontFamily:"inherit",fontWeight:trainTab===t.k?700:400}}>{t.l}</button>
            ))}
          </div>
          {trainTab==="lessons"&&(selLesson?<AILessonView lesson={selLesson} onBack={()=>setSelLesson(null)}/>:(
            <div>
              <div style={{color:C.text,fontWeight:800,fontSize:17,marginBottom:4}}>🎓 Human Writing Training</div>
              <div style={{color:C.muted,fontSize:13,marginBottom:18,lineHeight:1.6}}>Interactive lessons teaching agents to write like real humans. Human writing converts 3-5x better than corporate speak.</div>
              <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(270px,1fr))",gap:12}}>
                {AI_LESSONS.map((lesson,i)=>{
                  const cols=[C.accent,C.purple,C.teal,C.gold,C.green];
                  return(
                    <div key={lesson.id} onClick={()=>setSelLesson(lesson)} style={{background:C.card,border:`1px solid ${C.border}`,borderRadius:13,padding:20,cursor:"pointer",transition:"all 0.2s"}}
                      onMouseEnter={e=>{e.currentTarget.style.borderColor=cols[i%5]+"55";e.currentTarget.style.transform="translateY(-2px)";}}
                      onMouseLeave={e=>{e.currentTarget.style.borderColor=C.border;e.currentTarget.style.transform="none";}}>
                      <div style={{width:38,height:38,borderRadius:10,background:`${cols[i%5]}22`,color:cols[i%5],display:"flex",alignItems:"center",justifyContent:"center",fontSize:18,marginBottom:10}}>{lesson.icon}</div>
                      <div style={{color:C.text,fontWeight:700,fontSize:14,marginBottom:6}}>{lesson.title}</div>
                      <div style={{color:C.muted,fontSize:12,lineHeight:1.5,marginBottom:12}}>{lesson.scenario.slice(0,75)}...</div>
                      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                        <span style={{fontSize:11,color:cols[i%5],fontWeight:700}}>Start lesson →</span>
                        <span style={{fontSize:10,color:C.muted}}>~{lesson.time}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
          {trainTab==="styles"&&(
            <div>
              <div style={{color:C.text,fontWeight:800,fontSize:17,marginBottom:4}}>🎭 Agent Writing Voices</div>
              <div style={{color:C.muted,fontSize:13,marginBottom:18}}>Each agent has a unique human personality. See how they write differently.</div>
              <div style={{display:"grid",gridTemplateColumns:"repeat(2,1fr)",gap:14}}>
                {agents.map(a=>(
                  <Card key={a.id} style={{padding:20}}>
                    <div style={{display:"flex",gap:10,alignItems:"center",marginBottom:12}}>
                      <div style={{width:40,height:40,borderRadius:11,background:`${a.color}22`,color:a.color,display:"flex",alignItems:"center",justifyContent:"center",fontSize:18}}>🤖</div>
                      <div><div style={{color:C.text,fontWeight:700,fontSize:14}}>{a.name}</div><div style={{color:a.color,fontSize:11}}>{a.role}</div></div>
                    </div>
                    <div style={{padding:"8px 10px",background:`${a.color}0d`,border:`1px solid ${a.color}22`,borderRadius:8,marginBottom:10,fontSize:11,color:C.muted}}><strong style={{color:a.color}}>Style: </strong>{a.style}</div>
                    <div style={{fontSize:10,color:C.muted,textTransform:"uppercase",letterSpacing:"0.5px",marginBottom:6}}>Sample message</div>
                    <div style={{padding:"9px 11px",background:"rgba(255,255,255,0.04)",borderRadius:8,fontSize:12,color:C.text,lineHeight:1.6,fontStyle:"italic",borderLeft:`3px solid ${a.color}`}}>"{a.sample}"</div>
                    <div style={{marginTop:10}}>
                      <div style={{display:"flex",justifyContent:"space-between",marginBottom:4}}><span style={{fontSize:11,color:C.muted}}>Human Score</span><span style={{fontSize:11,color:a.color,fontWeight:700}}>{a.trainingLevel}%</span></div>
                      <div style={{height:5,background:C.dim,borderRadius:3}}><div style={{width:`${a.trainingLevel}%`,height:"100%",background:a.color,borderRadius:3}}/></div>
                    </div>
                  </Card>
                ))}
              </div>
            </div>
          )}
          {trainTab==="compare"&&(
            <div>
              <div style={{color:C.text,fontWeight:800,fontSize:17,marginBottom:4}}>🔄 Before & After</div>
              <div style={{color:C.muted,fontSize:13,marginBottom:18}}>How AI transforms robotic messages into human conversations.</div>
              {[
                {label:"Cold outreach",agent:"Alex",color:C.accent,before:"Hello Ron Mitchell. I am reaching out to inform you that FreightCRM offers freight brokerage services. We have carriers available on the TX to CA lane. Please schedule a call.",after:"Hey Ron! 👋 Saw TechParts on LinkedIn and had to reach out — your expansion story is seriously impressive. We move a ton of freight on your lanes and I'm pretty sure we could save you real money. Who handles your shipping right now?"},
                {label:"Follow-up after silence",agent:"Alex",color:C.accent,before:"Dear Lisa, I am following up on my previous email. Please let me know if you are interested in scheduling a call to discuss freight services at your convenience.",after:"Hey Lisa! Not trying to be a pest lol but I saw you opened my message a couple times 😅 No worries if timing's off — just reply 'not now' and I'll circle back in Q3. But if reefer from Fresno is still a thing, I've got something good for you 👀"},
                {label:"Closing the deal",agent:"Sara",color:C.purple,before:"Thank you James. I will send the agreement to your email address. Our team will contact you to begin the onboarding process. We appreciate your business.",after:"YES!! Ok James this literally made my whole week 🎉 Agreement going to your inbox RIGHT NOW — I'm sending as we speak! Onboarding team (Tom and Maria, both amazing) will reach out tomorrow. So SO excited to work with BuildRight! 😊"},
              ].map((ex,i)=>(
                <Card key={i} style={{padding:20,marginBottom:12}}>
                  <div style={{color:ex.color,fontSize:12,fontWeight:700,textTransform:"uppercase",letterSpacing:"0.5px",marginBottom:12}}>Example: {ex.label} — {ex.agent}</div>
                  <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
                    <div>
                      <div style={{fontSize:11,color:C.red,fontWeight:700,marginBottom:7}}>❌ Robotic (before)</div>
                      <div style={{padding:"11px 13px",background:`${C.red}08`,border:`1px solid ${C.red}22`,borderRadius:9,fontSize:12,color:C.muted,lineHeight:1.7}}>{ex.before}</div>
                    </div>
                    <div>
                      <div style={{fontSize:11,color:C.green,fontWeight:700,marginBottom:7}}>✅ Human (after)</div>
                      <div style={{padding:"11px 13px",background:`${C.green}08`,border:`1px solid ${C.green}22`,borderRadius:9,fontSize:12,color:C.text,lineHeight:1.7}}>{ex.after}</div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ACTIVITY TAB */}
      {agentTab==="activity"&&(
        <div>
          <div style={{color:C.text,fontWeight:800,fontSize:17,marginBottom:4}}>⚡ Live Agent Activity</div>
          <div style={{color:C.muted,fontSize:13,marginBottom:18}}>Real-time feed of what your agents are doing right now.</div>
          <div style={{display:"flex",flexDirection:"column",gap:8}}>
            {liveLog.map((ev,i)=>(
              <Card key={ev.id} style={{padding:"11px 16px",display:"flex",gap:10,alignItems:"center",opacity:Math.max(0.3,1-i*0.08)}}>
                <div style={{width:7,height:7,borderRadius:"50%",background:ev.color,flexShrink:0,boxShadow:`0 0 ${i===0?8:3}px ${ev.color}`}}/>
                <div style={{flex:1,fontSize:13,color:C.text}}>{ev.text}</div>
                <div style={{fontSize:11,color:C.muted,flexShrink:0}}>{ev.time}</div>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Create Agent Modal */}
      {showCreate&&(
        <Modal title="🤖 Create New AI Agent" onClose={()=>setShowCreate(false)} width={460}>
          <div style={{padding:"10px 14px",background:`${C.accent}0d`,border:`1px solid ${C.accent}22`,borderRadius:9,marginBottom:18,fontSize:12,color:C.muted,lineHeight:1.6}}>Your new agent will be trained to write like a human — casual, warm, and effective. It will find leads and manage conversations 24/7.</div>
          <div style={{marginBottom:14}}>
            <label style={{display:"block",color:C.muted,fontSize:11,marginBottom:5,textTransform:"uppercase",letterSpacing:"0.5px"}}>Agent Name</label>
            <input value={newA.name} onChange={e=>setNewA({...newA,name:e.target.value})} placeholder="e.g. Hunter, Max, Tasha..." style={{width:"100%",padding:"10px 13px",background:"rgba(255,255,255,0.05)",border:`1px solid ${C.border}`,borderRadius:8,color:C.text,fontSize:14,outline:"none",fontFamily:"inherit",boxSizing:"border-box"}}/>
          </div>
          <div style={{marginBottom:14}}>
            <label style={{display:"block",color:C.muted,fontSize:11,marginBottom:8,textTransform:"uppercase",letterSpacing:"0.5px"}}>Role</label>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
              {["Outbound Hunter","Relationship Manager","Carrier Scout","LTL Specialist"].map(r=>(
                <button key={r} onClick={()=>setNewA({...newA,role:r})} style={{padding:"9px",borderRadius:9,border:`1px solid ${newA.role===r?C.accent:C.border}`,background:newA.role===r?`${C.accent}15`:"transparent",color:newA.role===r?C.accent:C.muted,cursor:"pointer",fontSize:11,fontFamily:"inherit",fontWeight:newA.role===r?700:400}}>{r}</button>
              ))}
            </div>
          </div>
          <div style={{marginBottom:20}}>
            <label style={{display:"block",color:C.muted,fontSize:11,marginBottom:8,textTransform:"uppercase",letterSpacing:"0.5px"}}>Focus On</label>
            <div style={{display:"flex",gap:8}}>
              {["Shippers","Carriers","Both"].map(f=>(
                <button key={f} onClick={()=>setNewA({...newA,focus:f})} style={{flex:1,padding:"9px",borderRadius:8,border:`1px solid ${newA.focus===f?C.accent:C.border}`,background:newA.focus===f?`${C.accent}15`:"transparent",color:newA.focus===f?C.accent:C.muted,cursor:"pointer",fontSize:12,fontFamily:"inherit",fontWeight:newA.focus===f?700:400}}>{f}</button>
              ))}
            </div>
          </div>
          <PrimaryBtn onClick={()=>{
            if(!newA.name.trim())return;
            const cols=[C.accent,C.purple,C.teal,C.gold,C.green];
            setAgents(prev=>[...prev,{id:`a_${Date.now()}`,name:`${newA.name} AI`,role:newA.role,color:cols[prev.length%cols.length],status:"Active",loadsBooked:0,leadsFound:0,convRate:"—",todayFound:0,dailyGoal:15,trainingLevel:65,style:`New agent — learning human writing patterns for ${newA.focus}.`,sample:`Hey! I'm ${newA.name}, just getting started. Give me a few days and I'll be reaching out to ${newA.focus.toLowerCase()} on your behalf!`,task:`Initializing... analyzing top-performing messages...`}]);
            setShowCreate(false);setNewA({name:"",role:"Outbound Hunter",focus:"Shippers"});setAgentTab("agents");
          }} style={{width:"100%",justifyContent:"center",fontSize:15}}>🚀 Deploy Agent</PrimaryBtn>
        </Modal>
      )}
    </div>
  );
}
